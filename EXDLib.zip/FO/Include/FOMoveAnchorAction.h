//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOMOVEANCHORACTION_H__D800A732_8B72_4986_BDB3_6ED204FA585E__INCLUDED_)
#define AFC_FOMOVEANCHORACTION_H__D800A732_8B72_4986_BDB3_6ED204FA585E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOAction.h"
///////////////////////////////////////////////////////////////////////////////////
// Description: CFOMoveAnchorAction -- action that defined for moving anchor point.
// Author: ucancode.net Software
///////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOMoveAnchorAction class derived from CFOAction
//      F O Move Anchor Action
//===========================================================================

class FO_EXT_CLASS CFOMoveAnchorAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOMoveAnchorAction---F O Move Anchor Action, Specifies a E-XD++ CFOMoveAnchorAction object (Value).
	DECLARE_ACTION(CFOMoveAnchorAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Move Anchor Action, Constructs a CFOMoveAnchorAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	CFOMoveAnchorAction(CFODataModel* pModel,CFODrawShape *pShape,CPoint ptOffset);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Move Anchor Action, Destructor of class CFOMoveAnchorAction
	//		Returns A  value (Object).
	~CFOMoveAnchorAction();

public:

	//
	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOMoveAnchorAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// New offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get New Point, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetNewPoint()			{ return m_ptOffset; }

	// Set new offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Point, Sets a specify value to current class CFOMoveAnchorAction
	// Parameters:
	//		&pt---Specifies A CPoint type value.
	void SetNewPoint(CPoint &pt)	{ m_ptOffset = pt; }

	// Get max position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// pointer to shape
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *m_pShape;	

	// point offset
 
	// Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint	m_ptOffset;
	
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;	// friend class
};

_FOLIB_INLINE void CFOMoveAnchorAction::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFODrawShape *CFOMoveAnchorAction::GetShape()
{
	return m_pShape;
}

///////////////////////////////////////////////////////
// CFOMoveExtAnchorAction -- Move extend anchor position action.

 
//===========================================================================
// Summary:
//     The CFOMoveExtAnchorAction class derived from CFOAction
//      F O Move Extend Anchor Action
//===========================================================================

class FO_EXT_CLASS CFOMoveExtAnchorAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOMoveExtAnchorAction---F O Move Extend Anchor Action, Specifies a E-XD++ CFOMoveExtAnchorAction object (Value).
	DECLARE_ACTION(CFOMoveExtAnchorAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Move Extend Anchor Action, Constructs a CFOMoveExtAnchorAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	CFOMoveExtAnchorAction(CFODataModel* pModel,CFODrawShape *pShape,CPoint ptOffset);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Move Extend Anchor Action, Destructor of class CFOMoveExtAnchorAction
	//		Returns A  value (Object).
	~CFOMoveExtAnchorAction();

public:

	//
	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOMoveExtAnchorAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Get new offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get New Point, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetNewPoint()			{ return m_ptOffset; }

	// Set new offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Point, Sets a specify value to current class CFOMoveExtAnchorAction
	// Parameters:
	//		&pt---Specifies A CPoint type value.
	void SetNewPoint(CPoint &pt)	{ m_ptOffset = pt; }

	// Get max position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// pointer to shape
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *m_pShape;	

	// point offset
 
	// Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint	m_ptOffset;
	
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;	// friend class
};

_FOLIB_INLINE void CFOMoveExtAnchorAction::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFODrawShape *CFOMoveExtAnchorAction::GetShape()
{
	return m_pShape;
}

///////////////////////////////////////////////////////
// CFOMoveThirdAnchorAction -- Move Third anchor position action.

 
//===========================================================================
// Summary:
//     The CFOMoveThirdAnchorAction class derived from CFOAction
//      F O Move Third Anchor Action
//===========================================================================

class FO_EXT_CLASS CFOMoveThirdAnchorAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOMoveThirdAnchorAction---F O Move Third Anchor Action, Specifies a E-XD++ CFOMoveThirdAnchorAction object (Value).
	DECLARE_ACTION(CFOMoveThirdAnchorAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Move Third Anchor Action, Constructs a CFOMoveThirdAnchorAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	CFOMoveThirdAnchorAction(CFODataModel* pModel,CFODrawShape *pShape,CPoint ptOffset);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Move Third Anchor Action, Destructor of class CFOMoveThirdAnchorAction
	//		Returns A  value (Object).
	~CFOMoveThirdAnchorAction();

public:

	//
	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOMoveThirdAnchorAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Get new offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get New Point, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetNewPoint()			{ return m_ptOffset; }

	// Set new offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Point, Sets a specify value to current class CFOMoveThirdAnchorAction
	// Parameters:
	//		&pt---Specifies A CPoint type value.
	void SetNewPoint(CPoint &pt)	{ m_ptOffset = pt; }

	// Get max position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// pointer to shape
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *m_pShape;	

	// point offset
 
	// Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint	m_ptOffset;
	
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;	// friend class
};

_FOLIB_INLINE void CFOMoveThirdAnchorAction::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFODrawShape *CFOMoveThirdAnchorAction::GetShape()
{
	return m_pShape;
}


///////////////////////////////////////////////////////
// CFOMoveFourAnchorAction -- Move the Fourth anchor position action.

 
//===========================================================================
// Summary:
//     The CFOMoveFourAnchorAction class derived from CFOAction
//      F O Move Four Anchor Action
//===========================================================================

class FO_EXT_CLASS CFOMoveFourAnchorAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOMoveFourAnchorAction---F O Move Four Anchor Action, Specifies a E-XD++ CFOMoveFourAnchorAction object (Value).
	DECLARE_ACTION(CFOMoveFourAnchorAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Move Four Anchor Action, Constructs a CFOMoveFourAnchorAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	CFOMoveFourAnchorAction(CFODataModel* pModel,CFODrawShape *pShape,CPoint ptOffset);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Move Four Anchor Action, Destructor of class CFOMoveFourAnchorAction
	//		Returns A  value (Object).
	~CFOMoveFourAnchorAction();

public:

	//
	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOMoveFourAnchorAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Get new offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get New Point, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetNewPoint()			{ return m_ptOffset; }

	// Set new offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Point, Sets a specify value to current class CFOMoveFourAnchorAction
	// Parameters:
	//		&pt---Specifies A CPoint type value.
	void SetNewPoint(CPoint &pt)	{ m_ptOffset = pt; }
	
	// Get max position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// pointer to shape
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *m_pShape;	

	// point offset
 
	// Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint	m_ptOffset;
	
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;	// friend class
};

_FOLIB_INLINE void CFOMoveFourAnchorAction::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFODrawShape *CFOMoveFourAnchorAction::GetShape()
{
	return m_pShape;
}


///////////////////////////////////////////////////////
// CFOMoveFiveAnchorAction -- Move Fifth anchor position action

 
//===========================================================================
// Summary:
//     The CFOMoveFiveAnchorAction class derived from CFOAction
//      F O Move Five Anchor Action
//===========================================================================

class FO_EXT_CLASS CFOMoveFiveAnchorAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOMoveFiveAnchorAction---F O Move Five Anchor Action, Specifies a E-XD++ CFOMoveFiveAnchorAction object (Value).
	DECLARE_ACTION(CFOMoveFiveAnchorAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Move Five Anchor Action, Constructs a CFOMoveFiveAnchorAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	CFOMoveFiveAnchorAction(CFODataModel* pModel,CFODrawShape *pShape,CPoint ptOffset);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Move Five Anchor Action, Destructor of class CFOMoveFiveAnchorAction
	//		Returns A  value (Object).
	~CFOMoveFiveAnchorAction();

public:

	//
	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOMoveFiveAnchorAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Get new offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get New Point, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetNewPoint()			{ return m_ptOffset; }

	// Set new offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Point, Sets a specify value to current class CFOMoveFiveAnchorAction
	// Parameters:
	//		&pt---Specifies A CPoint type value.
	void SetNewPoint(CPoint &pt)	{ m_ptOffset = pt; }

	// Get max position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// pointer to shape
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *m_pShape;	

	// point offset
 
	// Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint	m_ptOffset;
	
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;	// friend class
};

_FOLIB_INLINE void CFOMoveFiveAnchorAction::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFODrawShape *CFOMoveFiveAnchorAction::GetShape()
{
	return m_pShape;
}

///////////////////////////////////////////////////////
// CFOMoveCenterAnchorAction -- Move the center anchor position action.

 
//===========================================================================
// Summary:
//     The CFOMoveCenterAnchorAction class derived from CFOAction
//      F O Move Center Anchor Action
//===========================================================================

class FO_EXT_CLASS CFOMoveCenterAnchorAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOMoveCenterAnchorAction---F O Move Center Anchor Action, Specifies a E-XD++ CFOMoveCenterAnchorAction object (Value).
	DECLARE_ACTION(CFOMoveCenterAnchorAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Move Center Anchor Action, Constructs a CFOMoveCenterAnchorAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	CFOMoveCenterAnchorAction(CFODataModel* pModel,CFODrawShape *pShape,CPoint ptOffset);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Move Center Anchor Action, Destructor of class CFOMoveCenterAnchorAction
	//		Returns A  value (Object).
	~CFOMoveCenterAnchorAction();

public:

	//
	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOMoveCenterAnchorAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Get new offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get New Point, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetNewPoint()			{ return m_ptOffset; }

	// Set new offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Point, Sets a specify value to current class CFOMoveCenterAnchorAction
	// Parameters:
	//		&pt---Specifies A CPoint type value.
	void SetNewPoint(CPoint &pt)	{ m_ptOffset = pt; }
	
	// Get max position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// pointer to shape
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *m_pShape;	

	// point offset
 
	// Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint	m_ptOffset;
	
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;	// friend class
};

_FOLIB_INLINE void CFOMoveCenterAnchorAction::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFODrawShape *CFOMoveCenterAnchorAction::GetShape()
{
	return m_pShape;
}

///////////////////////////////////////////////////////
// CFOMoveTextAnchorAction -- Move text anchor position action.

 
//===========================================================================
// Summary:
//     The CFOMoveTextAnchorAction class derived from CFOAction
//      F O Move Text Anchor Action
//===========================================================================

class FO_EXT_CLASS CFOMoveTextAnchorAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOMoveTextAnchorAction---F O Move Text Anchor Action, Specifies a E-XD++ CFOMoveTextAnchorAction object (Value).
	DECLARE_ACTION(CFOMoveTextAnchorAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Move Text Anchor Action, Constructs a CFOMoveTextAnchorAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	CFOMoveTextAnchorAction(CFODataModel* pModel,CFODrawShape *pShape,CPoint ptOffset);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Move Text Anchor Action, Destructor of class CFOMoveTextAnchorAction
	//		Returns A  value (Object).
	~CFOMoveTextAnchorAction();

public:

	//
	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOMoveTextAnchorAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Get new offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get New Point, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetNewPoint()			{ return m_ptOffset; }

	// Set new offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Point, Sets a specify value to current class CFOMoveTextAnchorAction
	// Parameters:
	//		&pt---Specifies A CPoint type value.
	void SetNewPoint(CPoint &pt)	{ m_ptOffset = pt; }
	
	// Get max position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// pointer to shape
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *m_pShape;	

	// point offset
 
	// Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint	m_ptOffset;
	
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;	// friend class
};

_FOLIB_INLINE void CFOMoveTextAnchorAction::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFODrawShape *CFOMoveTextAnchorAction::GetShape()
{
	return m_pShape;
}


///////////////////////////////////////////////////////
// CFOMoveUserAnchorAction -- Move User Anchor position action.

 
//===========================================================================
// Summary:
//     The CFOMoveUserAnchorAction class derived from CFOAction
//      F O Move User Anchor Action
//===========================================================================

class FO_EXT_CLASS CFOMoveUserAnchorAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOMoveUserAnchorAction---F O Move User Anchor Action, Specifies a E-XD++ CFOMoveUserAnchorAction object (Value).
	DECLARE_ACTION(CFOMoveUserAnchorAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Move User Anchor Action, Constructs a CFOMoveUserAnchorAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	CFOMoveUserAnchorAction(CFODataModel* pModel,CFODrawShape *pShape,const int &nPtIndex, CPoint ptOffset);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Move User Anchor Action, Destructor of class CFOMoveUserAnchorAction
	//		Returns A  value (Object).
	~CFOMoveUserAnchorAction();

public:

	//
	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOMoveUserAnchorAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Get new offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get New Point, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetNewPoint()			{ return m_ptOffset; }

	// Set new offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Point, Sets a specify value to current class CFOMoveUserAnchorAction
	// Parameters:
	//		&pt---Specifies A CPoint type value.
	void SetNewPoint(CPoint &pt)	{ m_ptOffset = pt; }

	// Obtain point index.
	int GetPtIndex() const { return m_nPtIndex; }

	// Set point index.
	void SetPtIndex(const int &nIndex) { m_nPtIndex = nIndex; }
	
	// Get max position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// pointer to shape
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *m_pShape;	

	// point offset
 
	// Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint	m_ptOffset;
	

	// Index of point.
	int		m_nPtIndex;
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;	// friend class
};

_FOLIB_INLINE void CFOMoveUserAnchorAction::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}
	
_FOLIB_INLINE CFODrawShape *CFOMoveUserAnchorAction::GetShape()
{
	return m_pShape;
}

///////////////////////////////////////////////////////
// CFOMoveVisioGeoAction -- Move Visio handle position action.

/////////////////////////////////////////////////////////////////////////////
// Description: CFOMoveVisioGeoAction -- action that change the Geometry of path shape.
// Author: Author
///////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOMoveVisioGeoAction class derived from CFOAction
//      F O Move Microsoft Visio style Geogmetry Action
//===========================================================================

class FO_EXT_CLASS CFOMoveVisioGeoAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOMoveVisioGeoAction---F O Move Microsoft Visio style Geogmetry Action, Specifies a E-XD++ CFOMoveVisioGeoAction object (Value).
	DECLARE_ACTION(CFOMoveVisioGeoAction)
public:
	
	// Constructor.
	// pModel -- pointer of the data model.
	// pShape -- pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Move Microsoft Visio style Geogmetry Action, Constructs a CFOMoveVisioGeoAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	CFOMoveVisioGeoAction(CFODataModel* pModel,CFODrawShape *pShape);
	
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Move Microsoft Visio style Geogmetry Action, Destructor of class CFOMoveVisioGeoAction
	//		Returns A  value (Object).
	~CFOMoveVisioGeoAction();
	
	// Get max position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();
	
	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;
	
	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;
	
	// Get the name of the action
	// strLabel -- label for the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;
	
	// Add new shape to the action.
	// pShape -- pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOMoveVisioGeoAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();
	
public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
protected:
	
	// pointer of the shape
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *		m_pShape;
	
	// pointer of the new geometry data
 
	// New Geogmetry, This member maintains a pointer to the object FOPObjGeoData.  
	FOPObjGeoData*		pNewGeo;
	
	// pointer of the old geometry data.
 
	// Old Geogmetry, This member maintains a pointer to the object FOPObjGeoData.  
	FOPObjGeoData*		pOldGeo;
	
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFOMoveVisioGeoAction::SetShape(CFODrawShape *pShape)
{
	m_pShape = pShape;
	pShape->AddRef();
}

_FOLIB_INLINE CFODrawShape *CFOMoveVisioGeoAction::GetShape()
{
	return m_pShape;
}

///////////////////////////////////////////////////////
// CFOMoveVisioHandleAction -- Move Visio handle position action.

 
//===========================================================================
// Summary:
//     The CFOMoveVisioHandleAction class derived from CFOAction
//      F O Move Microsoft Visio style Handle Action
//===========================================================================

class FO_EXT_CLASS CFOMoveVisioHandleAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOMoveVisioHandleAction---F O Move Microsoft Visio style Handle Action, Specifies a E-XD++ CFOMoveVisioHandleAction object (Value).
	DECLARE_ACTION(CFOMoveVisioHandleAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Move Microsoft Visio style Handle Action, Constructs a CFOMoveVisioHandleAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.  
	//		handle---Specifies A integer value.
	CFOMoveVisioHandleAction(CFODataModel* pModel,CFODrawShape *pShape,CPoint ptOffset, int handle);
	
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Move Microsoft Visio style Handle Action, Destructor of class CFOMoveVisioHandleAction
	//		Returns A  value (Object).
	~CFOMoveVisioHandleAction();
	
public:
	
	//
	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL Execute();
	
	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;
	
	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;
	
	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;
	
	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOMoveVisioHandleAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();
	
	// Get new offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get New Point, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetNewPoint()			{ return m_ptOffset; }
	
	// Set new offset point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Point, Sets a specify value to current class CFOMoveVisioHandleAction
	// Parameters:
	//		&pt---Specifies A CPoint type value.
	void SetNewPoint(CPoint &pt)	{ m_ptOffset = pt; }
	
	// Get visio handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Microsoft Visio style Handle, Returns the specified value.
	//		Returns a int type value.
	int GetVisioHandle()			{ return m_nHandle; }
	
	// Change handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Microsoft Visio style Hanlde, Sets a specify value to current class CFOMoveVisioHandleAction
	// Parameters:
	//		handle---Specifies A integer value.
	void SetVisioHanlde(int handle) { m_nHandle = handle; }
	
	// Get max position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
protected:
	
	// pointer to shape
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *m_pShape;	
	
	// point offset
 
	// Offset, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint	m_ptOffset;
	
 
	// Handle, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nHandle;
	
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;	// friend class
};

_FOLIB_INLINE void CFOMoveVisioHandleAction::SetShape(CFODrawShape *pShape)
{
	if (m_pShape != pShape)
	{
		if (m_pShape != NULL)
		{
			m_pShape->Release();
		}
		
		m_pShape = pShape;
		
		if (m_pShape != NULL)
		{
			m_pShape->AddRef();
		}
	}
}

_FOLIB_INLINE CFODrawShape *CFOMoveVisioHandleAction::GetShape()
{
	return m_pShape;
}

#endif // !defined(AFC_FOMOVEANCHORACTION_H__D800A732_8B72_4986_BDB3_6ED204FA585E__INCLUDED_)
