//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOCOMPOSITESHAPE_H__65309930_0ED0_11D6_A50C_525400EA266C__INCLUDED_)
#define AFC_FOCOMPOSITESHAPE_H__65309930_0ED0_11D6_A50C_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//------------------------------------------------------
// Shape.
//------------------------------------------------------

#include "FOStaticShape.h"
#include "FOEditBoxShape.h"
#include "FOInsideBaseShape.h"
#include "FOPCollect.h"

/////////////////////////////////////////////////////////////////////////////////
//
// CFOCompositeShape -- composite shape, it's ID is: FO_COMP_COMPOSITE 34
//  this class is a very important major class that defined for composite shape.

 
//===========================================================================
// Summary:
//     The CFOCompositeShape class derived from CFODrawPortsShape
//      F O Composite Shape
//===========================================================================

class FO_EXT_CLASS CFOCompositeShape : public CFODrawPortsShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOCompositeShape---F O Composite Shape, Specifies a E-XD++ CFOCompositeShape object (Value).
	DECLARE_SERIAL(CFOCompositeShape);

public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Composite Shape, Constructs a CFOCompositeShape object.
	//		Returns A  value (Object).
	CFOCompositeShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Composite Shape, Constructs a CFOCompositeShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOCompositeShape& src object(Value).
	CFOCompositeShape(const CFOCompositeShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Composite Shape, Destructor of class CFOCompositeShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOCompositeShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOCompositeShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the composite shape from a CRect object.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(CRect &rcPos,CString strCaption = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOCompositeShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the composite shape from a resource id.
	// nID -- resource id.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(UINT nID, const CRect &rcPos, CString strCaption = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOCompositeShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strResFile---Resource File, Specifies A CString type value.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the composite shape from a resource id.
	// strFile -- resource file.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void Create(const CString &strResFile, const CRect &rcPos, CString strCaption = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOCompositeShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strResFile---Resource File, Specifies A CString type value.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the composite shape from a resource id.
	// strFile -- resource file.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	virtual void CreateFromTemplate(const CString &strResFile, const CRect &rcPos, CString strCaption = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	// Create this composite shape with auto size.
	// nID -- resource id.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create With Automatic, You construct a CFOCompositeShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	virtual void CreateWithAuto(UINT nID, const CRect &rcPos, CString strCaption = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	// Create this composite shape with auto size.
	// nID -- resource id.
	// rcPos -- position of shape.
	// strCaption -- caption of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create With Automatic, You construct a CFOCompositeShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strResFile---Resource File, Specifies A CString type value.  
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	virtual void CreateWithAuto(const CString &strResFile, const CRect &rcPos, CString strCaption = _T(""));
    
	//-----------------------------------------------------------------------
	// Summary:
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOCompositeShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOCompositeShape& src object(Value).
	CFOCompositeShape& operator=(const CFOCompositeShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;


	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFOCompositeShape* CloneFrom(const int &nIndexNum);

	// Correct all shapes with it's position.
	void CorrectAllShapes(CFODrawShapeList *pListShape, const FOPRect &rcOld);

	// Clone composite shape's contexts.
	virtual CFOCompositeShape *CloneContext(CFOCompositeShape *pComp);

public:

	
	// Update area of shape.
	// pArea -- pointer of area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pArea);

	// Compute current area.
	// pArea -- area pointer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Extend Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void  ExtGeometryUpdated(CFOArea* pArea);
	
	// Load components from resource file.
	// nID -- Resource id.
	// lpszType -- resource type name,must the same as the resource ID's resource type name.
	// bAdd -- add to the list of the shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load From Resource, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lpszType---lpszType, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		bAdd---bAdd, Specifies A Boolean value.
	BOOL LoadFromResource(UINT nID, LPCTSTR lpszType = _T("CompsRes"),BOOL bAdd = FALSE);

	// Load components from file.
	// lpszResName -- resource name.
	// bAdd -- add to the list of the shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load From File, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszResName---Resource Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		bAdd---bAdd, Specifies A Boolean value.
	BOOL LoadFromFile(LPCTSTR lpszResName,BOOL bAdd = FALSE);

	// Load components from file.
	// lpszResName -- resource name.
	// bAdd -- add to the list of the shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load From File, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszResName---Resource Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		bAdd---bAdd, Specifies A Boolean value.
	BOOL LoadFromTemplateFile(LPCTSTR lpszResName,BOOL bAdd = FALSE);

	// Load toolbox item data to this composite shape.
	// lpszResName -- file name of the composite shapes.
	// bAdd -- add to the list of the shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Tool Box Data File, Call this function to read a specified number of bytes from the archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszResName---Resource Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		bAdd---bAdd, Specifies A Boolean value.
	BOOL LoadToolBoxDataFile(LPCTSTR lpszResName,BOOL bAdd = FALSE);

	// Make object by resource.
	// lpszResName -- resource name.
	// lpszType -- resource type.
	// bAdd -- add to the list of the shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Make Object By Resource, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszResName---Resource Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		lpszType---lpszType, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		bAdd---bAdd, Specifies A Boolean value.
	BOOL MakeObjectByResource(LPCTSTR lpszResName, LPCTSTR lpszType,BOOL bAdd = FALSE);

	// Add text shape to the composite shape.
	// strName -- name of the static shape.
	// strCaption -- caption of the static shape.
	// rcPos -- position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Text, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOStaticShape ,or NULL if the call failed  
	// Parameters:
	//		strName---strName, Specifies A CString type value.  
	//		strCaption---strCaption, Specifies A CString type value.  
	//		rcPos---rcPos, Specifies A CRect type value.
	virtual CFOStaticShape *AddText(const CString &strName, const CString &strCaption, const CRect &rcPos);

	// Hit test text children shape, for label editing.
	// ptHit -- logical hit point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Label, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOStaticShape ,or NULL if the call failed  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	virtual CFOStaticShape *HitTestLabel(const CPoint &ptHit);

	// Hit test child shape, return the pointer of the shape.
	// ptHit -- hit test point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Child, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	virtual CFODrawShape *HitTestChild(const CPoint &ptHit);

	// Hit test edit box.
	// pt -- hit test point. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Edit Box, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPEFormBaseShape ,or NULL if the call failed  
	// Parameters:
	//		pt---Specifies A CPoint type value.
	virtual CFOPEFormBaseShape *HitTestEditBox(const CPoint& pt);

	// Hit test inside box.
	// pt -- hit test point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test  Box, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPEFormBaseShape ,or NULL if the call failed  
	// Parameters:
	//		pt---Specifies A CPoint type value.
	virtual CFOPEFormBaseShape *HitTestCtrlBox(const CPoint& pt);

	// Get first hit text shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get First Edit Label, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOStaticShape ,or NULL if the call failed
	virtual CFOStaticShape *GetFirstEditLabel();

	// Find text shape, if there is an exist shape within the composite shape, returns TRUE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Text Component, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL FindTextComp();

	// Is all text shapes
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is All Text Component, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsAllTextComp();

	// Rebuild all shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rebuild Shapes, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RebuildShapes();

	// Is only one label shape within the composite shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Only One Label, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL IsOnlyOneLabel();

	// Get rotate handle location.
	// ptHandle -- pointer of handle that generated.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.
	virtual BOOL GetRotateSpotLocation(CPoint &ptHandle);

	// Get current select shapes position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Bound Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect   GetTotalBoundRect();

	// Obtain all points position.
	CRect GetCurRect();

	// Get current select shapes position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Snap Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect   GetTotalSnapRect();

	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		aPoly---aPoly, Specifies a FOPSimpleCompositePolygon& aPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& aPoly) const;

	// Do convert shape to poly or path shape.
	// After you call this method,you must call pObj->Release();
	// bBezier -- if you want to convert it to bezier shape,this will be TRUE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert To Path Object, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bBezier---&bBezier, Specifies A Boolean value.
	virtual CFODrawShape* DoConvertToPathObj(CDC *pDC,const BOOL &bBezier);

	// Do convert shape to poly or path shape,it will keep all the children shapes.
	// After you call this method,you must call pObj->Release();
	// bBezier -- if you want to convert it to bezier shape,this will be TRUE.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Convert To Path Object New, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bBezier---&bBezier, Specifies A Boolean value.
	virtual CFODrawShape* DoConvertToPathObjNew(CDC *pDC,const BOOL &bBezier);

	// Change the pointer of the data model
	// pNewModel -- pointer of new model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Model, Sets a specify value to current class CFOCompositeShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pNewModel---New Model, A pointer to the CFODataModel or NULL if the call failed.
	virtual void SetModel(CFODataModel* pNewModel);

	// Is all of it's children shapes are path shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is All Path Shape, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllPathShape();

	// Get the bounding position of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bound Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetBoundRect() const;

	// Hit test label pos.
	// ptHit -- hit test point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Label Text Position, Determines if the mouse has been clicked on a component.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptHit---ptHit, Specifies A CPoint type value.
	virtual BOOL HitLabelTextPos(const CPoint& ptHit);

	// Obtain the true children areas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get True Childs Area, Returns the specified value.
	//		Returns A E-XD++ CFOArea value (Object).
	CFOArea GetTrueChildsArea();

	// Recalc font point size.
	// pDC -- pointer of the DC
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Update Font, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void DoUpdateFont(CDC* pDC);

	// Is shape within the composite
	// pShape -- pointer of shape for checking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Shape Within, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual BOOL IsShapeWithin(CFODrawShape* pShape) const;

	// Hit test connect point,if hitted,return the hit connect port,else return NULL.
	// point -- log point.
	// bUseExt -- it is true, it will check with more large area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape,or NULL if the call failed  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		&bUseExt---Use Extend, Specifies A Boolean value.
	virtual CFOPortShape* HitTest(const CPoint& point,const BOOL &bUseExt = TRUE);

	// Generate default label position.
	// rcPos -- Position that for generate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Default Label Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies a const FOPRect &rcPos object(Value).
	virtual void GenDefaultLabelPos(const FOPRect &rcPos);

	// Current value change event.
	// dValue -- current value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Current Value Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).
	virtual void DoCurrentValueChange(const double &dValue);
	
	// Called when a property is changed.
	// nPropId - property ID value.
	// prop -- property object
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Property Change, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		prop---A pointer to the CFOBaseProperties or NULL if the call failed.
	virtual void OnPropertyChange(const int &nPropId, CFOBaseProperties* prop);

	// Do something when switch to design or undesign mode.
	virtual void DoModelSwitch(const BOOL &bDesign);
	
	// Is all ports linked.
	BOOL IsAllPortsLinked();
	
	// Obtain the input port from index.
	virtual CFOPortShape* InPort(const int& nIndex);
	
	// Obtain the output port by index.
	virtual CFOPortShape* OutPort(const int& nIndex);
	
	// Obtain the input port.
	virtual CFOPortShape *GetIn();
	
	// Obtain the output.
	virtual CFOPortShape *GetOut();
	
	// Obtain the total of input ports.
	virtual int GetTotalIn();
	
	// Obtain the total of output ports
	virtual int GetTotalOut();
	
	// Obtain input value.
	virtual double InValue(const int &nIndex);
	
	// Change input value.
	virtual void SetInVal(const double &dValue);
	
	// Change input value by index.
	virtual void SetInVal2(const int &nIndex, const double &dValue);
	
	// Change Output value.
	virtual void SetOutVal(const double &dValue);
	
	// Change output value by index
	virtual void SetOutVal2(const int &nIndex, const double &dValue);


public:
	// Obtain all the ports within this composite shape.
	// listPorts - list of port shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Ports, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&listPorts---&listPorts, Specifies a E-XD++ CFODrawShapeList &listPorts object (Value).
	virtual void GetAllPorts(CFODrawShapeList &listPorts);

	// Hit test connect point,if hitted, return the hit connect port,else return NULL.
	// ptHit -- log point.
	// nExpand -- expand value of the point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Port, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape,or NULL if the call failed  
	// Parameters:
	//		ptHit---ptHit, Specifies A CPoint type value.  
	//		nExpand---nExpand, Specifies A integer value.
	virtual CFOPortShape* HitTestPort(const CPoint& ptHit, int nExpand = 0) const;

	// Generate all ports index
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Ports Indexes, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void GenPortsIndexs();

	// Get the Count of ports within the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Ports Count, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetPortsCount();

	// Get all the children shape's count + the count of all ports.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Shapes Count In Depth, Returns the specified value.
	//		Returns a int type value.
	int	GetAllShapesCountInDepth();

public:

	// Change Index For Link value.
	// nNewIdx -- new index id.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Index For Link, Sets a specify value to current class CFOCompositeShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nNewIdx---New Idx, Specifies A integer value.
	virtual void SetIndexForLink(int &nNewIdx );

	// build Index for properties, it is used for loading or saving data from file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Index For Property, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void BuildIndexForProp();


	// build Index for properties, it is used for loading or saving data from file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build Index For Property, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void BuildIndexForPropSimple();

	
	// Add all shapes to the prepare list.
	// lShape -- shape container
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add To Prepare, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*lShape---*lShape, A pointer to the FOPContainer  or NULL if the call failed.
	virtual void AddToPrepare(FOPContainer *lShape);

	// Add all link shapes to the prepare list.
	// m_LinkList -- list of link shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add To Links, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&m_LinkList---Link List, Specifies a E-XD++ CFODrawShapeSet &m_LinkList object (Value).
	virtual void AddToLinks(CFODrawShapeSet &m_LinkList);

	// Add all link shapes to prepared shapes list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add To Links Depth, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&m_LinkList---Link List, Specifies a E-XD++ CFODrawShapeList &m_LinkList object (Value).
	virtual void AddToLinksDepth(CFODrawShapeList &m_LinkList);

	
	// Find shape within, it is exist, it will return TRUE.
	// pFind -- pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Search Shape With In, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pFind---*pFind, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual BOOL SearchShapeWithIn(CFODrawShape *pFind);

	// Find all the shapes with a specify layer id.
	// pShapesList -- list shapes.
	// nID -- layer ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shapes With Layer I D, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShapesList---Shapes List, A pointer to the CFODrawShapeList  or NULL if the call failed.  
	//		&nID---I D, Specifies a const FOPLayerID &nID object(Value).
	virtual void FindShapesWithLayerID(CFODrawShapeList *pShapesList,const FOPLayerID &nID);

	// Find shape by ID.
	CFODrawShape *FindByID(const int &nID);

	// Gen hit rectangle.
	// ptPoint -- point for hitting.
	// nCol -- expand width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Generate Hit Rect2, .
	//		Returns a CRect type value.  
	// Parameters:
	//		&ptPoint---&ptPoint, Specifies A CPoint type value.  
	//		&nCol---&nCol, Specifies A integer value.
	CRect FOPGenHitRect2(const CPoint &ptPoint,const int &nCol = 4);

	// Hit composite
	// pHitComp -- hit composite shape.
	// point -- hit testing point.
	// rcHittest -- hit testing rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O Do Hit Composite2, .
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		*pHitComp---Hit Component, A pointer to the CFOCompositeShape  or NULL if the call failed.  
	//		&point---Specifies A CPoint type value.  
	//		&rcHittest---&rcHittest, Specifies A CRect type value.
	CFODrawShape * FODoHitComposite2(CFOCompositeShape *pHitComp, const CPoint &point, const CRect &rcHittest);

	// Obtain the true center for rotating.
	// dCenterX -- x value.
	// dCenterY -- y value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Center, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&dCenterX---Center X, Specifies a double &dCenterX object(Value).  
	//		&dCenterY---Center Y, Specifies a double &dCenterY object(Value).
	virtual void GetRotateCenter(double &dCenterX, double &dCenterY) const;

	// Obtain the true center point for rotating.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Center2, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CPoint type value.
	virtual CPoint GetRotateCenter2() const;

	// Obtain all selected shapes with it's children.
	void GetAllChildSelectedShapes(CFODrawShapeList *pList);

	// Change select mode
	virtual void SetSelectedMode(const BOOL &bSelect);

	// Set in focus.
	virtual void SetFocusMode(const BOOL &bFocus);

	// Get the plus spots of the control handles,override this method to calc the new position of the handle.
	// lstHandle -- list of handles
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Center Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetRotateCenterSpotLocation(CFOPHandleList& lstHandle);

	// Set matrix change data.
	// pMat -- pointer of matrix data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Matrix Data, Sets a specify value to current class CFOCompositeShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pMat---pMat, A pointer to the CFOMatrix or NULL if the call failed.
	virtual void SetMatrixData(CFOMatrix* pMat);

	// Get plus spots with location.
	// lstHandle -- list of handles.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Plus Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetPlusSpotLocation(CFOPHandleList& lstHandle);

	// Calculate text line array.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Text Array, You construct a CFOCompositeShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		strText---strText, Specifies A CString type value.  
	//		rcBox---rcBox, Specifies A CRect type value.  
	//		arLines---arLines, Specifies A CString type value.
	virtual int CreateTextArray(CDC* pDC, CString strText,
		CRect rcBox,CStringArray& arLines);

	// Calculate the label start position.
	// pDC -- pointer of the DC.
	// bFullSize -- using full size or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Label Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bFullSize---Full Size, Specifies A Boolean value.
	virtual CRect CalcLabelPosition(CDC *pDC,BOOL &bFullSize) const;

	// Get text box size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Text Size, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CSize type value.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rcPos---rcPos, Specifies A CRect type value.  
	//		strText---strText, Specifies A CString type value.
	virtual CSize GetTextSize(CDC* pDC,CRect rcPos,CString strText, const BOOL &bNeedFont = TRUE);

	// Obtain saved rotating angle.
	int	GetSaveRotateAngle() const;
	FOPRect GetUnRotateRect();
	void UpdateClone();
	// Get format type of drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Draw Format Type, Returns the specified value.
	//		Returns a UINT type value.
	UINT GetDrawFormatType();

	// Set allow hit children shape or not.
	// bAllow -- allow or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Allow Hit Child, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&bAllow---&bAllow, Specifies A Boolean value.
	void SetAllowHitChild(const BOOL &bAllow);

	// Do state change event.
	// strState -- state text that changed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do State Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strState---&strState, Specifies A CString type value.
	virtual void DoStateChange(const CString &strState);
	
	// Reset all the data of handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset Handle Data X, Called this function to empty a previously initialized CFOCompositeShape object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ResetHandleDataX();

	// Save current data, it is used for multiple states mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Current Data, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void SaveCurrentData();
	
	// Get the rotating angle,override this method to drawing new rotating angle text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate Angle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int	GetRotateAngle() const;

	// Index of children shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Index Of, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		*obj---A pointer to the CFODrawShape  or NULL if the call failed.
	virtual int IndexOf(CFODrawShape *obj);

	// Reset all saving data.
	virtual void ResetSaveData();

public:

	// Define for text.
	
	// Set Group Text Horz Alignment
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Text Horizontal Alignment, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&nT---&nT, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void	SetGroupTextHorzAlignment(const UINT &nT);

	// Set Group Text Vertical Alignment
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Text Vertical Alignment, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&nT---&nT, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void	SetGroupTextVertAlignment(const UINT &nT);


	// Set Group Multi_Line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Multiple Line, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&bMulti---&bMulti, Specifies A Boolean value.
	void	SetGroupMultiLine(const BOOL &bMulti);


	// Set Group Object Caption
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Object Caption, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&str---Specifies A CString type value.
	void	SetGroupObjectCaption(const CString &str);

	// Get max rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxRect();

	// Get maximize position of track line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Track Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetTrackPosition();

	// Update current area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Extend Update Component, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void  ExtUpdateComp();
	
	// Generate the labeling center pos.
	virtual CPoint GenLabelCenter() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Get Rotate pos Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHandle---&ptHandle, Specifies A CPoint type value.
	virtual BOOL GetRotatePos(const CRect &rcPos, CPoint &ptHandle);

public:

	// Put group property value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Put Group Property Value, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nPropId---Property Id, Specifies A integer value.  
	//		&Value---&Value, Specifies a const FO_VALUE &Value object(Value).
	virtual void PutGroupPropValue(
		// Specify the ID of property.
		const int &nPropId,
		// Specify the value of property.
		const FO_VALUE &Value
		);

	// Get group property value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Group Property Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&Value---&Value, Specifies a FO_VALUE &Value object(Value).  
	//		&nPropId---Property Id, Specifies A integer value.
	virtual BOOL GetGroupPropValue(
		// Return value.
		FO_VALUE &Value,
		// Specify the ID of property.
		const int &nPropId
		);

	virtual CRect GetTrackLinePoints(CPoint &pt1,CPoint &pt2,CPoint &pt3,CPoint &pt4);

	// Set Group Object Name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Object Name, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&str---Specifies A CString type value.
	void	SetGroupObjectName(const CString &str);

	// Set Group Visible
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Visible, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&bV---&bV, Specifies A Boolean value.
	void	SetGroupVisible(const BOOL &bV);
	
	// Set Group Disabled
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Tab Order Protect, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&bD---&bD, Specifies A Boolean value.
	void	SetGroupTabOrderProtect(const BOOL &bD);

	// Set Group Flat
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Flat, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&bF---&bF, Specifies A Boolean value.
	void	SetGroupFlat(const BOOL &bF);

	// Lock Shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Lock Group Shape, .
	// Parameters:
	//		&bL---&bL, Specifies A Boolean value.
	void	LockGroupShape(const BOOL &bL);

	// Reset shape reload state.
	void ResetReloadState();

public:

	// Define for line.

	// Set Group Line Width
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Line Width, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&nWidth---&nWidth, Specifies A integer value.
	void	SetGroupLineWidth(const int &nWidth);

	// Set Group Line Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Line Color, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void	SetGroupLineColor(const COLORREF &crColor);

	// Null pen.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Null Pen, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&bNull---&bNull, Specifies A Boolean value.
	void	SetGroupNullPen(const BOOL &bNull);

	// Set pen style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Pen Style, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&nPenStyle---Pen Style, Specifies A integer value.
	void	SetGroupPenStyle(const int &nPenStyle);

	// Add svg text
	virtual void		  SVG_AddText(CString &outputStringL);

	// Events.
	BOOL HandleDragLButtonDown(const CPoint &point);
	BOOL HandleDragLButtonUp(const CPoint &point);
	BOOL HandlDragMouseMove(const CPoint &point);

	// Events.
	BOOL HandleTwoButton(const CPoint &point);
	BOOL HandleTwoStatus(const CPoint &point);
	BOOL DoButtonMouseMove(const CPoint &point);
	BOOL DoMMoveStatus(const CPoint &point);
	BOOL DoButtonLButtonUp(const CPoint &point);
	BOOL DoStatusLButtonUp(const CPoint &point);

	// Change current value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Simple Value, Sets a specify value to current class CFOPGaugeCircularShape
	// Parameters:
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).
	virtual void SetSimpleValue(const double &dValue);
	

public:
	//Define for font.
	// Set Group Face Name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Face Name, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		lpszFaceName---Face Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	void	SetGroupFaceName(LPCTSTR lpszFaceName);

	// Set font point size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Point Size, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&nPointSize---Point Size, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void	SetGroupPointSize(const int &nPointSize, CDC* pDC = NULL);

	// Set font height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Height, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&nHeight---&nHeight, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void	SetGroupHeight(const int &nHeight, CDC* pDC = NULL);

	// Set font color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Font Color, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void	SetGroupFontColor(const COLORREF &crColor);

	// Set font bold.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Weight, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&nWeight---&nWeight, Specifies A integer value.
	void	SetGroupWeight(const int &nWeight);

	// Set font italic.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Italic, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&bItalic---&bItalic, Specifies A Boolean value.
	void	SetGroupItalic(const BOOL &bItalic);

	// Set font underline.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Underline, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&bUnderline---&bUnderline, Specifies A Boolean value.
	void	SetGroupUnderline(const BOOL &bUnderline);

	// Set font strikeout mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Strikeout, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&bStrikeout---&bStrikeout, Specifies A Boolean value.
	void	SetGroupStrikeout(const BOOL &bStrikeout);

public:
	// Define for brush.

	// Set Group  Background Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Background Color, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&crBkColor---Background Color, Specifies A 32-bit COLORREF value used as a color value.
	void	SetGroupBkColor(const COLORREF &crBkColor);

	// Set Group transparent mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Transparent, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&bTransparent---&bTransparent, Specifies A Boolean value.
	void	SetGroupTransparent(const BOOL &bTransparent);

	// Set Group brush type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Brush Type, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	void	SetGroupBrushType(const int &nType);
	
	// Set Group brush hatch type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Brush Hatch, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&nHatch---&nHatch, Specifies A integer value.
	void	SetGroupBrushHatch(const int &nHatch);


	// Set Group pattern color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Pattern Color, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&cr---Specifies A 32-bit COLORREF value used as a color value.
	void	SetGroupPatternColor(const COLORREF &cr);

	// Set Group user data to the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Item Data, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		pData---pData, A pointer to the CObject or NULL if the call failed.
	void SetGroupItemData(CObject* pData);

	// Allow label select.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Allow Label Select, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllowLabelSelect() const;

	// Set label with allow select mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Allow Label Select, .
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void AllowLabelSelect(const BOOL &bEnable);

	// Is hit label locked.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Hit Label Locked, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsHitLabelLocked() const { return m_bLockHitLabel; }

	// Set hit label locked.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Lock Hit Label, .
	// Parameters:
	//		&bLock---&bLock, Specifies A Boolean value.
	void LockHitLabel(const BOOL &bLock) { m_bLockHitLabel = bLock; }

	// Is hit label visible.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Hit Label Visible, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsHitLabelVisible() const;

	// Set hit label visible.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Hit Label Visible, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&bVisible---&bVisible, Specifies A Boolean value.
	void SetHitLabelVisible(const BOOL &bVisible);

	// Update property cache.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Cache Properties, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void CacheProperties();

	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();
 
	// Do cycle animate event.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Cycle Animate, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL DoCycleAnimate();

	// Reset the composite shape's rectangle with children's snap rectangle.
	void ResetCurrentShape(const BOOL &bUpdate = TRUE);

	// update data loading
	virtual void UpdateSaveLoading();

public:

	// Set wnd handle.
	// pCanvas -- pointer of canvas.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Parent Window, Sets a specify value to current class CFOCompositeShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pCanvas---*pCanvas, A pointer to the CFOPCanvasCore  or NULL if the call failed.
	virtual void SetParentWnd(CFOPCanvasCore *pCanvas);

	// Set the truely properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Bulleted Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnBulletedProperties();

	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnTextEditProperties();

	// Set the line properties.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Line Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnLineEditProperties();

	// Set the fill properties.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fill Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnFillEditProperties();

	// Set the shadow properties.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Shadow Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnShadowEditProperties();

	// Set the event properties.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Event Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnEventProperties();

	// Set the truely properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Custom Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnCustomProperties();

	// WM_CHAR message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Char, Handle WM_CHAR message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);

	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 

	// WM_LBUTTONDBLCLK message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDblClk(UINT nFlags, CPoint point);

	virtual BOOL DoPreDraw(CDC *pDC);

	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);

	// WM_RBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnRButtonDown(UINT nFlags, CPoint point); 

	// WM_RBUTTONDBLCLK message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Double click Clk, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnRButtonDblClk(UINT nFlags, CPoint point);

	// WM_RBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Up, Called when the user releases the right mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnRButtonUp(UINT nFlags, CPoint point);

	// WM_MOUSEMOVE message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Move, Called when the mouse cursor moves.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnMouseMove(UINT nFlags, CPoint point);

	// Get max rectangle of all link shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Links Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect			GetMaxLinksRect();

	// Cancel mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cancel Mode, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnCancelMode();

	// Allow hit child.
	virtual BOOL IsAllowHitChild();

public:

	// Define for shadow brush.
	
	// Set shadow color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Shadow Color, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void		SetGroupShadowColor(const COLORREF &crColor);

	// Set shadow pattern color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Shadow Pattern Color, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void		SetGroupShadowPatternColor(const COLORREF &crColor);

	// Set Shadow offset x.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Shadow Offset X, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&offset---Specifies A integer value.
	void		SetGroupShadowOffsetX(const int &offset);

	
	// Set Shadow offset y.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Shadow Offset Y, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&offset---Specifies A integer value.
	void		SetGroupShadowOffsetY(const int &offset);

	// Set shadow brush type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Shadow Brush Type, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&nType---&nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void		SetGroupShadowBrushType(const UINT &nType);

	// Set shadow brush hatch.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Shadow Brush Hatch, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&nHatch---&nHatch, Specifies A integer value.
	void		SetGroupShadowBrushHatch(const int &nHatch);

	// Set shadow.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Shadow, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&bHas---&bHas, Specifies A Boolean value.
	void		SetGroupShadow(const BOOL &bHas);
	
	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Current Value, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).
	void		SetGroupCurValue(const double &dValue);

	// Do state change event.
	// strState -- current selected state text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Handle Value Change, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strState---&strState, Specifies A CString type value.
	virtual void HandleValueChange(const CString &strState);

	// Change minimize value of the range,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Minimize Value, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&nMin---&nMin, Specifies a const double &nMin object(Value).
	void		SetGroupMinValue(const double &nMin);

	// Change Maximize value of the range,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Maximize Value, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&nMax---&nMax, Specifies a const double &nMax object(Value).
	void		SetGroupMaxValue(const double &nMax);

	
	// Remove all connect ports on the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All Ports, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveAllPorts();

public:
	// Define for bulleted.
	// Set bulleted color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Bulleted Color, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void SetGroupBulletedColor(const COLORREF &crColor);

	// Set bulleted type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Group Bulleted Type, Sets a specify value to current class CFOCompositeShape
	// Parameters:
	//		&nType---&nType, Specifies A integer value.
	void SetGroupBulletedType(const int &nType);

	// Set modified flags
	virtual void SetModified();

	// Is modified.
	BOOL IsModified() const;

public:

	// Find port  by it's name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Port Name, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed  
	// Parameters:
	//		list---Specifies a const CFODrawShapeList& list object(Value).  
	//		&strName---&strName, Specifies A CString type value.
	virtual CFOPortShape *FindPortName(
		// Specifies the list of shapes to find.
		const CFODrawShapeList& list,
		// Specifies the name of port to find
		const CString &strName
		);

	// Find port by it's key value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Port By Key1, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed  
	// Parameters:
	//		list---Specifies a const CFODrawShapeList& list object(Value).  
	//		&strKey---&strKey, Specifies A CString type value.
	virtual CFOPortShape *FindPortByKey1(
		// Specifies the list of shapes to find.
		const CFODrawShapeList& list,
		// Specifies the key of port to find
		const CString &strKey
		);

	// Find port by it's ID value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Port By Id, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape ,or NULL if the call failed  
	// Parameters:
	//		list---Specifies a const CFODrawShapeList& list object(Value).  
	//		&nId---&nId, Specifies A integer value.
	virtual CFOPortShape *FindPortById(
		// Specifies the list of shapes to find.
		const CFODrawShapeList& list,
		// Specifies the id of port to find
		const int &nId
		);

	// Get all ports of the list shapes, it will check all of it's children shape with all depths.
	// pLstPorts -- list of the ports.
	// list -- list of the shapes for searching.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Search All Ports, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pLstPorts---Lst Ports, A pointer to the CFODrawShapeList  or NULL if the call failed.  
	//		&list---Specifies a const CFODrawShapeList &list object(Value).
	virtual void SearchAllPorts(CFODrawShapeList *pLstPorts,const CFODrawShapeList &list);

	// Rebuild all the links, it is called at last when loading data from file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rebuild Full Link, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		aShapes---aShapes, Specifies a FOPContainer aShapes object(Value).  
	//		list---Specifies a const CFODrawShapeSet& list object(Value).
	virtual void RebuildFullLink(const FOPContainer &aShapes,const CFODrawShapeSet& list);

	// Check all property indexes, and reset it, it is used for shape saving.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset All Property Index, Called this function to empty a previously initialized CFOCompositeShape object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ResetAllPropIndex();

	// Check all links, and reset link shape's name for saving.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset Link Names, Called this function to empty a previously initialized CFOCompositeShape object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		list---Specifies a const CFODrawShapeList& list object(Value).  
	//		&bNeedProp---Need Property, Specifies A Boolean value.
	virtual void ResetLinkNames(const CFODrawShapeList& list, const BOOL &bNeedProp = TRUE);

	// Reset all the children link shape's name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Reset Child Link Names, Called this function to empty a previously initialized CFOCompositeShape object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ResetChildLinkNames();

	// Serializes the data, it only serialize the data of all children shapes, it is used for toolbox item only.
	// this is not the saving method of composite shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize Child Shapes, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).  
	//		&nVersion---&nVersion, Specifies A integer value.
	virtual void SerializeSubShapes(CArchive &ar, const int &nVersion);

	// Serializes the data, this is the sid file saving method.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize Sid file Data, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void SerializeSidData(CArchive &ar);

	// Serializes the data, this is the teamplate file saving method.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize Sid file Data, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void SerializeTemplateData(CArchive &ar);

	// Serializes the data, it is used for drag and drop only (From the toolbox window at left side).
	// 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize Ole Drag Data, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void SerializeOleDragData(CArchive &ar);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);

	// Serialize simple cache mode
	virtual void SerializeShareMode(CArchive &ar);
	
	// Save document.
	// lpszPathName -- full file path name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	// lpszPathName -- full file path name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

	//Draw flat status.

	// Draws custom tracker.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Frees GDI objects and restores the state of the device context.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation
	
	// Draws the truely shape.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Draws the flat status of the shape.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	// pDC -- pointer of DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Drawing Dot track border line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw Dot Border, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void DrawDotBorder(CDC* pDC);

	// Do scale and move.
	virtual void DoResizeAndMove(const FOPPoint &ptOri, double dXScale, double dYScale, const FOPPoint &ptOffset);

	// Scale shape.
	// fX -- x scale of shape.
	// fY -- y scale of shape.
	// fOX -- x origin of shape.
	// fOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void ScaleShape(double dX, double dY, double dOX, double dOY);

	// Scale track shape.
	// Define for track line.
	// dX -- x track scale of shape.
	// dY -- y track scale of shape.
	// dOX -- x track origin of shape.
	// dOY -- y track origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Track Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dfX---dfX, Specifies a double dfX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void ScaleTrackShape(double dfX, double dY, double dOX, double dOY);

	// Scales the shape about its center to the size specified. 
	// rcSave -- saving bounding rectangle.
	// ptOffset -- point offset point.
	// handle -- control handle of shape,it should be the following enum value:
	// enum FO_CONTROL_HANDLE
	// {
	// 	TopLeft = 0,				// 1.Top left handle.
	// 	TopMiddle,					// 2.Top middle handle.		
	// 	TopRight,					// 3.Top right handle.        1*********2*********3
	// 	SideRight,					// 4.Right side handle.       *					  *
	// 	BottomRight,				// 5.Bottom right handle	  *					  *
	// 	BottomMiddle,				// 6.Bottom middle handle	  8			9		  4				
	// 	BottomLeft,					// 7.Bottom left handle		  *					  *
	// 	SideLeft,					// 8.Side left handle.		  *					  *
	// 	        					// 9.Center handle.			  7*********6*********5
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Microsoft Visio style Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcSave---&rcSave, Specifies a const FOPRect &rcSave object(Value).  
	//		pMat---pMat, A pointer to the CFOMatrix or NULL if the call failed.  
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.  
	//		handle---Specifies A integer value.
	virtual void ScaleVisioShape(const FOPRect &rcSave, CFOMatrix* pMat, const CPoint &ptOffset, int handle);
	
	
	// Scale shape.
	// Define for track line.
	// rcSave -- saving bounding rectangle.
	// ptOffset -- point offset point.
	// handle -- control handle of shape,it should be the following enum value:
	// enum FO_CONTROL_HANDLE
	// {
	// 	TopLeft = 0,				// 1.Top left handle.
	// 	TopMiddle,					// 2.Top middle handle.		
	// 	TopRight,					// 3.Top right handle.        1*********2*********3
	// 	SideRight,					// 4.Right side handle.       *					  *
	// 	BottomRight,				// 5.Bottom right handle	  *					  *
	// 	BottomMiddle,				// 6.Bottom middle handle	  8			9		  4				
	// 	BottomLeft,					// 7.Bottom left handle		  *					  *
	// 	SideLeft,					// 8.Side left handle.		  *					  *
	// 	        					// 9.Center handle.			  7*********6*********5
	// };
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Microsoft Visio style Track Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcSave---&rcSave, Specifies a const FOPRect &rcSave object(Value).  
	//		pMat---pMat, A pointer to the CFOMatrix or NULL if the call failed.  
	//		&ptOffset---&ptOffset, Specifies A CPoint type value.  
	//		handle---Specifies A integer value.
	virtual void ScaleVisioTrackShape(const FOPRect &rcSave, CFOMatrix* pMat, const CPoint &ptOffset, int handle);

	// Rotate shape.
	// nAngle -- rotate angle(0-3600).
	// dOX -- x origin of shape.
	// dOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateShape(double nAngle, double dOX, double dOY);

	// Rotate shape.
	// Define for track line.
	// nAngle -- rotate angle(0-3600).
	// dOX -- x origin of shape.
	// dOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Track Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies a double nAngle object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void RotateTrackShape(double nAngle, double dOX, double dOY);

	// Position shape.
	// rcNewPos -- new position of this shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Position Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcNewPos---New Position, Specifies A CRect type value.
	virtual void PositionShape(const CRect &rcNewPos);

	// Position shape to a new place.
	// rcOld -- old position.
	// rcNewPos -- new position of this shape.
	//
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re Position Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcOld---&rcOld, Specifies a const FOPRect &rcOld object(Value).  
	//		&rcNewPos---New Position, Specifies a const FOPRect &rcNewPos object(Value).
	virtual void RePositionShape(const FOPRect &rcOld, const FOPRect &rcNewPos);

	// Set dimension of group shape.
	// newW -- new width.
	// newH -- new height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Dimensions, Sets a specify value to current class CFOCompositeShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		newW---newW, Specifies A integer value.  
	//		newH---newH, Specifies A integer value.
	virtual void SetDimensions( int newW, int newH );

	// Change width of shape.
	// newW -- new width.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set W, Sets a specify value to current class CFOCompositeShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		newW---newW, Specifies A integer value.
	virtual void SetW( int newW );

	// Change height of shape.
	// newH -- new height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set H, Sets a specify value to current class CFOCompositeShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		newH---newH, Specifies A integer value.
	virtual void SetH( int newH );

	// Chagne x of shape
	// newX -- new x origin.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set X, Sets a specify value to current class CFOCompositeShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		newX---newX, Specifies A integer value.
	virtual void SetX( int newX );

	// Change y of shape
	// newY -- new y origin
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Y, Sets a specify value to current class CFOCompositeShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		newY---newY, Specifies A integer value.
	virtual void SetY( int newY );

	// Move shape to.
	// newX -- new top left corner point's x value.
	// newY -- new top left corner point's y value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move To, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		newX---newX, Specifies A integer value.  
	//		newY---newY, Specifies A integer value.
	virtual void MoveTo( int newX, int newY );
	
	// Move shape's center to a new position.
	// newCenterX -- new center point's x value.
	// newCenterY -- new center point's y value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move Center To, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		newCenterX---Center X, Specifies A integer value.  
	//		newCenterY---Center Y, Specifies A integer value.
	virtual void MoveCenterTo( int newCenterX, int newCenterY );

	// Change the matrix data.
	// Mat -- new matrix data for applying.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Apply Abs Matrix Data, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&Mat---&Mat, Specifies a const CFOMatrix &Mat object(Value).
	virtual void ApplyAbsMatrixData(const CFOMatrix &Mat);

	// Offset a spot.
	// Offset a specify point.
	// nIndex -- the spot index.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL OffsetPoint(int nIndex, CPoint ptOffset);

	// Offset all points, call this method to moving the shape.
	// ptOffset -- offset value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Offset All Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual void OffsetAllPoints(CPoint ptOffset);

	// Offset all track points.
	// ptOffset -- offset point value.
	// ptScroll -- currently not used.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset All Points, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptOffset---ptOffset, Specifies A CPoint type value.  
	//		ptScroll---ptScroll, Specifies A CPoint type value.
	virtual void TrackOffsetAllPoints(CPoint ptOffset,CPoint ptScroll);

	// Update the points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Update Points, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void TrackUpdatePoints();

	// Offset current track points.
	// nOffsetX -- x offset value.
	// nOffsetY -- y offset value.
	// ptScroll -- currently not used.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Track Offset Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.  
	//		ptOffset---ptOffset, Specifies A CPoint type value.
	virtual BOOL TrackOffsetPoint(int nIndex, CPoint ptOffset);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Mirror, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rRef1---rRef1, Specifies A CPoint type value.  
	//		rRef2---rRef2, Specifies A CPoint type value.
	// Mirror with point ref1 and ref2.
	// rRef1 -- mirror reference line's start point.
	// rRef2 -- mirror reference line's end point.
	virtual void Mirror(const CPoint& rRef1, const CPoint& rRef2);

	// Mirror tack with point ref1 and ref2.
	// rRef1 -- mirror reference line's start point.
	// rRef2 -- mirror reference line's end point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Mirror Track, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rRef1---rRef1, Specifies A CPoint type value.  
	//		rRef2---rRef2, Specifies A CPoint type value.
	virtual void MirrorTrack(const CPoint& rRef1, const CPoint& rRef2);

	// skewing shape X coordinates by angle.
	// nAngle -- Skew angle(0-360).
	// fOX -- x origin of shape.
	// fOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Skew X Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies A integer value.  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void SkewXShape(int nAngle, double dOX, double dOY);

	// skewing shape Y coordinates by angle.
	// nAngle -- Skew angle(0-360).
	// fOX -- x origin of shape.
	// fOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Skew Y Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies A integer value.  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void SkewYShape(int nAngle, double dOX, double dOY);

	// skewing track shape X coordinates by angle.
	// nAngle -- Skew angle(0-360).
	// fOX -- x origin of shape.
	// fOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Skew Track X Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies A integer value.  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void SkewTrackXShape(int nAngle, double dOX, double dOY);

	// skewing track shape Y coordinates by angle.
	// nAngle -- Skew angle(0-360).
	// fOX -- x origin of shape.
	// fOY -- y origin of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Skew Track Y Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nAngle---nAngle, Specifies A integer value.  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void SkewTrackYShape(int nAngle, double dOX, double dOY);

	// Update current shape's position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Position, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void UpdatePosition();

	// Truly update
	void NewUpdate();

	// Update current area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Component, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void  UpdateComp();

	// Reset update flags.
	virtual void UpdateHardWay();

	// Change the layer ID of the shape.
	// nLayer -- layer ID.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Layer, Sets a specify value to current class CFOCompositeShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nLayer---nLayer, Specifies a FOPLayerID nLayer object(Value).
	virtual void   SetLayer(FOPLayerID nLayer);

	// Do sub menu change, this method is designed for quick menu event only. Handle this 
	// virtual method to handle your own control.
	// nMenuItem -- menu item index.
	// strState -- state string text for changing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Child Menu Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nMenuItem---Menu Item, Specifies A integer value.  
	//		&strState---&strState, Specifies A CString type value.
	virtual void DoSubMenuChange(const int &nMenuItem, const CString &strState);

	// Correct all the position of shapes.
	void CorrectAllChildPosition();

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
public:
	// Export to SVG
	virtual void ExportToSVG(CStdioFile*);

public:
	// get shape list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Component List, Returns the specified value.
	//		Returns a pointer to the object CFODrawShapeList ,or NULL if the call failed
	CFODrawShapeList *GetCompList() { return &m_GroupList; }
	
	// get shape count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Component Count, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int GetCompCount()	{ return m_GroupList.GetCount(); }

	// Get first child.
	// pos -- position of the first children shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get First Child, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&pos---Specifies A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.
	CFODrawShape *GetFirstChild(POSITION &pos);

	// Get next child by a specify pos.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Next Child, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&pos---Specifies A POSITION value used to denote the position of an element in a collection; used by MFC collection classes.
	CFODrawShape *GetNextChild(POSITION &pos);

	// add shape
	// pShape -- pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void AddShape(CFODrawShape *pShape);

	// add shape
	// pShape -- pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void AddShapeNoUpdate(CFODrawShape *pShape);

	// add a list of shapes.
	// m_list -- list of shapes that will be added.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&m_list---Specifies a E-XD++ CFODrawShapeList &m_list object (Value).
	virtual void AddShapes(CFODrawShapeList &m_list);

	// add shape list
	// m_list -- list of shapes that will be added.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&m_list---Specifies a E-XD++ CFODrawShapeSet &m_list object (Value).
	virtual void AddShapes(CFODrawShapeSet &m_list);

	// add shape at header of list.
	// pShape -- pointer of shape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape At Header, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void AddShapeAtHeader(CFODrawShape *pShape);

	// Add a component before an existed object
	// pShape -- pointer of shape that to be added.
	// pBefore -- pointer of shape before
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape Before, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		pBefore---pBefore, A pointer to the CFODrawShape or NULL if the call failed.
	virtual void AddShapeBefore(CFODrawShape *pShape, CFODrawShape* pBefore);

	// Replace a child shape.
	// pShape -- pointer of shape.
	// pReplace -- pointer of shape that need to be placed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Replace Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		pReplace---pReplace, A pointer to the CFODrawShape or NULL if the call failed.  
	//		bSameSize---Same Size, Specifies A Boolean value.
	virtual void ReplaceShape(CFODrawShape *pShape, CFODrawShape* pReplace, BOOL bSameSize = TRUE);

	// Add a component before an existed object
	// pShape -- shape that is added.
	// pAfter -- shape that searched.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape After, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		pAfter---pAfter, A pointer to the CFODrawShape or NULL if the call failed.
	virtual void AddShapeAfter(CFODrawShape *pShape, CFODrawShape* pAfter);

	// add shapes list at header
	// m_list -- list of shapes that will be added.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes At Header, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&m_list---Specifies a E-XD++ CFODrawShapeList &m_list object (Value).
	virtual void AddShapesAtHeader(CFODrawShapeList &m_list);

	// remove shape
	// pShape -- pointer of shape that will be removed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Shape, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void RemoveShape(CFODrawShape *pShape);

	// remove shape at
	// nIndexRemove -- index of shape that will be removed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Shape, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&nIndexRemove---Index Remove, Specifies A integer value.
	virtual BOOL RemoveShape(const int &nIndexRemove);

	// remove shape list
	// m_list -- list that contains all the shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Shapes, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&m_list---Specifies a E-XD++ CFODrawShapeList &m_list object (Value).
	virtual void RemoveShapes(CFODrawShapeList &m_list);

	// remove all shapes
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All Shapes, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveAllShapes();

	// Obtain all the shapes in all depth.
	// m_list -- list that contains all the shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get All Shapes In Depth, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&m_list---Specifies a E-XD++ CFODrawShapeList &m_list object (Value).
	virtual void GetAllShapesInDepth(CFODrawShapeList &m_list);

	// Find the 0-based index in group list of a shape pointer.
	// pShape -- pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape Index, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	int GetShapeIndex(CFODrawShape *pShape);

	// Find the 0-based index in group list of a shape pointer.
	// nIndex -- index of checking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape At, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.
	CFODrawShape * GetShapeAt(const int &nIndex);

	// Find shape after.
	// pShape -- pointer of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape After, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	CFODrawShape* FindShapeAfter(CFODrawShape *pShape);

	// Find shape with name.
	// strName -- name that searched.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape With Name, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&strName---&strName, Specifies A CString type value.
	CFODrawShape *FindShapeWithName(const CString &strName);

	// Find shape with name, it will search all the children in all depths.
	// strName -- name that searched.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape With Name In All Depth, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&strName---&strName, Specifies A CString type value.
	CFODrawShape *FindShapeWithNameInAllDepth(const CString &strName);


	// Find shape with key value.
	// strKey -- key that searched.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape With Key1, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&strKey---&strKey, Specifies A CString type value.
	CFODrawShape *FindShapeWithKey1(const CString &strKey);
	
	// Find shape with key value, it will search all the children in all depths.
	// strKey -- key that searched.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape With Key1 In All Depth, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&strKey---&strKey, Specifies A CString type value.
	CFODrawShape *FindShapeWithKey1InAllDepth(const CString &strKey);


	// Find shape with key value.
	// strKey -- key that searched.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape With Key2, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&strKey---&strKey, Specifies A CString type value.
	CFODrawShape *FindShapeWithKey2(const CString &strKey);
	
	// Find shape with key value, it will search all the children in all depths.
	// strKey -- key that searched.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape With Key2 In All Depth, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&strKey---&strKey, Specifies A CString type value.
	CFODrawShape *FindShapeWithKey2InAllDepth(const CString &strKey);


	// Find shape with key value.
	// strKey -- key that searched.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape With Key3, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&strKey---&strKey, Specifies A CString type value.
	CFODrawShape *FindShapeWithKey3(const CString &strKey);
	
	// Find shape with key value, it will search all the children in all depths.
	// strKey -- key that searched.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape With Key3 In All Depth, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&strKey---&strKey, Specifies A CString type value.
	CFODrawShape *FindShapeWithKey3InAllDepth(const CString &strKey);


	// Find shape with caption, it will search all the children in one depths.
	// strCaption -- caption that searched.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape With Caption, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&strCaption---&strCaption, Specifies A CString type value.
	CFODrawShape *FindShapeWithCaption(const CString &strCaption);

	// Find shape with caption, it will search all the children in all depths.
	// strCaption -- caption that searched.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Shape With Caption In All Depth, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&strCaption---&strCaption, Specifies A CString type value.
	CFODrawShape *FindShapeWithCaptionInAllDepth(const CString &strCaption);

	// Get nearest shape's point,this is used to connect line to line,when you moving near a shape,it will glue to its
	// control handle point or the shapes vector points.
	// ptHit -- HitTest logical point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Nearest Point Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&m_TempSet---Temp Set, Specifies a E-XD++ CFODrawShapeSet &m_TempSet object (Value).  
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void	GetNearestPtShape(CFODrawShapeSet &m_TempSet,const CPoint &ptHit,CFODrawShape *pShape = NULL);

	// Get nearest shape's point,this is used to connect line to line,when you moving near a shape,it will glue to its
	// control handle point or the shapes vector points.
	// ptHit -- HitTest logical point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Nearest Point Shape Extend, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&m_TempSet---Temp Set, Specifies a E-XD++ CFODrawShapeSet &m_TempSet object (Value).  
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		&nSpotIndex---Spot Index, Specifies A integer value.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void	GetNearestPtShapeExt(CFODrawShapeSet &m_TempSet,const CPoint &ptHit,int &nSpotIndex,
		CFODrawShape *pShape = NULL);

	// Pick nearest point,this is used for glue mode,when you moving near a shape,it will glue to its
	// control handle point or the shapes vector points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Nearest Point, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&m_TempList---Temp List, Specifies a E-XD++ CFODrawShapeSet &m_TempList object (Value).  
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		dSpace---dSpace, Specifies A integer value.
	virtual void			PickNearestPoint(CFODrawShapeSet &m_TempList,
		// Mouse hit point.
		const CPoint &ptHit,const int& dSpace);

	// used to snap link to nearest port,when create or moving linkline,this method will be called for hit testing
	
	//-----------------------------------------------------------------------
	// Summary:
	// Pick Nearest Port, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&m_TempList---Temp List, Specifies a E-XD++ CFODrawShapeSet &m_TempList object (Value).  
	//		ptPoint---ptPoint, Specifies A CPoint type value.  
	//		nRadius---nRadius, Specifies A integer value.
	virtual void	PickNearestPort(CFODrawShapeSet &m_TempList,
		// Mouse hit point.
		CPoint ptPoint, 
		// Within radius.
		int nRadius  = 20
		);

	// Remove all links that connect to this shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove All Links, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void RemoveAllLinks();

	// Remove a list of connect ports from the shape.
	// m_list -- connect ports to be removed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Ports, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&m_list---Specifies a const CFOPortShapeList &m_list object(Value).
	virtual void RemovePorts(const CFOPortShapeList &m_list);

	// Get specify connect port by scale x and scale y.
	// dXScale -- x scale value.
	// dYScale -- y scale value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Port, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape,or NULL if the call failed  
	// Parameters:
	//		dXScale---X Scale, Specifies a double dXScale object(Value).  
	//		dYScale---Y Scale, Specifies a double dYScale object(Value).
	virtual CFOPortShape* FindPort(double dXScale,double dYScale);

	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Value, Sets a specify value to current class CFOCompositeShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetCurrentValue(const double &nValue);

protected:
		// Do state change event.
	// strState -- state string text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Handle State Change, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strState---&strState, Specifies A CString type value.
	virtual void HandleStateChange(const CString &strState);
	
	
	// Do image animate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Animate, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL DoAnimate();

	// Current timer ID
	
	// Timer I D, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nTimerID;

	// Current frame
	
	// Frame, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT				m_nFrame;

public:
	
	// Is position correct.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Position Correct, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL PositionCorrect();
	
	// Do show timer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Timer, Called after each interval specified in SetTimer.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nTimerID---Timer I D, Specifies A integer value.
	virtual void OnTimer( UINT_PTR nTimerID );
	
	// Start timer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Start Timer, Do a event. 
	
	void DoStartTimer();
	
	// Set timer speed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Timer Speed, Sets a specify value to current class CFOUpRightLinkShape
	// Parameters:
	//		&nNewSpeed---New Speed, Specifies A integer value.
	void SetTimerSpeed(const int &nNewSpeed);

	// Get value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Second Value, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double			GetSecondValue() { return m_dSecondValue; }
	
	// Change current setting value,this is defined for value choice control such as CFOProgressCtrlShape
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Second Value, Sets a specify value to current class CFOPLiquidLineShape
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nValue---&nValue, Specifies a const double &nValue object(Value).
	virtual void		SetSecondValue(const double &nValue);

	// Obtain quick total.
	int GetQuickTotal(int &nTotalAll);

public:
	// Current timer speed, default is 400
	
	// Timer Speed, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int					m_nTimerSpeed;
	
	// The second start value.
	
	// Second Value, This member specify double object.  
	double				m_dSecondValue;

	// nTotal shapes.
	int					m_nTotalShapes;

	// Need to reload.
	BOOL				m_bNeedReload;

	// Used count.
	int					m_nUsedCount;

protected:

	
	// object of class
	BOOL				m_bAllowHitDepth;
 
	// Group List, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList	m_GroupList;		

	// Value change mode.
	BOOL				m_bValueChange;

	// Lock hit test label.
 
	// Lock Hit Label, This member sets TRUE if it is right.  
	BOOL				m_bLockHitLabel;
	
	// Mouse pressed.
 
	// Pressed, This member sets TRUE if it is right.  
	BOOL				m_bPressed;
	
	// Mouse lbutton down.
 
	// Mouse Down, This member sets TRUE if it is right.  
	BOOL				m_bMouseDown;
	
	// Mouse can press.
 
	// Can Press, This member sets TRUE if it is right.  
	BOOL				m_bCanPress;

	// Size of text label.
 
	// Sav Label, This member sets a CSize value.  
	CSize				m_szSavLabel;

};

#endif // !defined(AFC_FOCOMPOSITESHAPE_H__65309930_0ED0_11D6_A50C_525400EA266C__INCLUDED_)
