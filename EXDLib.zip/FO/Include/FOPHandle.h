//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPHANDLE_H__8DEF6EE5_95CB_4391_8598_CCA8063CE327__INCLUDED_)
#define AFX_FOPHANDLE_H__8DEF6EE5_95CB_4391_8598_CCA8063CE327__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPHandle.h : header file
//

enum FOPHdlKind
{
	SPOT_MOVE = 0,		// Moving
	SPOT_UPLFT,		// Up left
	SPOT_UPPER,		// Upper
	SPOT_UPRGT,		// Up right
	SPOT_LEFT,		// Left
	SPOT_RIGHT,		// Right
	SPOT_LWLFT,		// Lower left
	SPOT_LOWER,		// Lower
	SPOT_LWRGT,		// Lower right
	SPOT_POLY,		// Polygon,close bezier
	SPOT_REF1,		// Ref1
	SPOT_REF2,		// Ref2
	SPOT_MIRX,		// Mirx
	SPOT_GLUE,		// GluePoint
	SPOT_ANCHOR,	// Anchor point
	SPOT_2_ANCHOR,	// Anchor point
	SPOT_3_ANCHOR,	// Anchor point
	SPOT_4_ANCHOR,	// Anchor point
	SPOT_5_ANCHOR,	// Anchor point
	SPOT_LABEL_ANCHOR,	// Label Anchor point
	SPOT_ROTATE,		// Rotate handle
	SPOT_VISIO_TOPLEFT,		// Visio style handle
	SPOT_VISIO_TOPCENTER,	// Visio style handle
	SPOT_VISIO_TOPRIGHT,	// Visio style handle
	SPOT_VISIO_RIGHTCENTER,	// Visio style handle
	SPOT_VISIO_BOTTOMRIGHT,	// Visio style handle
	SPOT_VISIO_BOTTOMCENTER,// Visio style handle
	SPOT_VISIO_BOTTOMLEFT,	// Visio style handle
	SPOT_VISIO_LEFTCENTER,	// Visio style handle
	SPOT_USER_ANCHOR		// User anchor. Must set SetPointNum
};

/////////////////////////////////////////////////////////////////////////////
// CFOPHandle object -- it is defined for shape draging handle.

class CFODrawShape;
 
//===========================================================================
// Summary:
//      To use a CFOPHandle object, just call the constructor.
//      F O P Handle
//===========================================================================

class FO_EXT_CLASS CFOPHandle
{
public:

	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Handle, Constructs a CFOPHandle object.
	//		Returns A  value (Object).
	CFOPHandle();

	// Copy constructor. 
	// rPnt -- point of handle.
	// eNewKind -- spot style
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Handle, Constructs a CFOPHandle object.
	//		Returns A  value (Object).  
	// Parameters:
	//		rPnt---rPnt, Specifies A integer value.  
	//		eNewKind---New Kind, Specifies a FOPHdlKind eNewKind = SPOT_MOVE object(Value).
	CFOPHandle(const FOPPoint& rPnt, FOPHdlKind eNewKind = SPOT_MOVE);
	
	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Handle, Destructor of class CFOPHandle
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPHandle();
	
	// Copy constructor. 
	// source -- target object
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Handle, Constructs a CFOPHandle object.
	//		Returns A  value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPHandle& source object(Value).
	CFOPHandle(const CFOPHandle& source);
	
	// Assignment operator.
	// source -- target object
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPHandle& value (Object).  
	// Parameters:
	//		source---Specifies a const CFOPHandle& source object(Value).
	CFOPHandle& operator=(const CFOPHandle& source);

	// == operator.
	// rCmp -- compare object
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rCmp---rCmp, Specifies a const CFOPHandle& rCmp object(Value).
	BOOL operator==(const CFOPHandle& rCmp) const;

	// != operator.
	// rCmp -- compare object
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rCmp---rCmp, Specifies a const CFOPHandle& rCmp object(Value).
	BOOL operator!=(const CFOPHandle& rCmp) const;

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Draw, Draws current object to the specify device.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		szHdl---szHdl, Specifies a const FOPSize& szHdl object(Value).  
	//		&nState---&nState, Specifies A integer value.
	// Draw the object.
	// pDC -- pointer of DC.
	// szHdl -- size of handle.
	// nState -- state 1 -- normal,state 2 -- mirror,state 3 - shear.
	virtual void Draw(CDC *pDC,const FOPSize& szHdl,const int &nState = 1);

	// Get handle kind.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Kind, Returns the specified value.
	//		Returns A FOPHdlKind value (Object).
	FOPHdlKind GetKind() const		{	return m_nStyle;	}

	// Is corner handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Corner Handle, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsCornerHdl() const		{	return m_nStyle == SPOT_UPLFT || m_nStyle == SPOT_UPRGT || 
		m_nStyle == SPOT_LWLFT || m_nStyle == SPOT_LWRGT;	}

	// Is vertex handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Vertex Handle, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsVertexHdl() const		{	return m_nStyle == SPOT_UPPER || m_nStyle == SPOT_LOWER || 
		m_nStyle == SPOT_LEFT || m_nStyle == SPOT_RIGHT;	}

	// Set polygon number.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Polygon Number, Sets a specify value to current class CFOPHandle
	// Parameters:
	//		nNum---nNum, Specifies A integer value.
	void SetPolyNum(int nNum)	{	m_nNubPolygon = nNum;	}

	// Get polygon number
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Polygon Number, Returns the specified value.
	//		Returns a int type value.
	int GetPolyNum() const		{	return m_nNubPolygon;	}

	// Set point number
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Point Number, Sets a specify value to current class CFOPHandle
	// Parameters:
	//		nNum---nNum, Specifies A integer value.
	void SetPointNum(int nNum)	{	m_nNumPoints = nNum;	}

	// Get point number.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point Number, Returns the specified value.
	//		Returns a int type value.
	int GetPointNum() const		{	return m_nNumPoints;	}

	// Set plus handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Plus Handle, Sets a specify value to current class CFOPHandle
	// Parameters:
	//		bOn---bOn, Specifies A Boolean value.
	void SetPlusHdl(BOOL bOn)		{	m_bPlusHandle = bOn;	}

	// Is plus handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Plus Handle, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsPlusHdl() const			{	return m_bPlusHandle;	}

	// Is handle selected.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Selected, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsSelected() const			{	return m_bSelected;	}

	// Set selected.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Selected, Sets a specify value to current class CFOPHandle
	// Parameters:
	//		bJa---bJa, Specifies A Boolean value.
	void SetSelected(BOOL bJa = TRUE);

	// Get object pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Object, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	CFODrawShape* GetObj() const	{	return m_pShape;	}

	// Set object pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Object, Sets a specify value to current class CFOPHandle
	// Parameters:
	//		pNewObj---New Object, A pointer to the CFODrawShape or NULL if the call failed.
	void SetObj(CFODrawShape* pNewObj);

	// Change handle pos.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Position, Sets a specify value to current class CFOPHandle
	// Parameters:
	//		rPnt---rPnt, Specifies A integer value.
	void SetPos(const FOPPoint& rPnt);

	// Get handle point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Position, Returns the specified value.
	//		Returns a CPoint type value.
	const CPoint& GetPos() const	{	return m_ptPosition;	}

	// Is hit.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Hit, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		rPnt---rPnt, Specifies A integer value.  
	//		szHdl---szHdl, Specifies a const FOPSize& szHdl object(Value).
	virtual BOOL IsHit(const FOPPoint& rPnt, const FOPSize& szHdl) const;

	// Is It Lock
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Lock, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsLock() const		{ return m_bLock; }

	// Lock handle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Lock, Sets a specify value to current class CFOPHandle
	// Parameters:
	//		&bL---&bL, Specifies A Boolean value.
	void		SetLock(const BOOL &bL) { m_bLock = bL; }

public:
	

	// Position of handle.
	FOPRect			m_rcHit;
 
	// Position, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPPoint		m_ptPosition;

	// Pointer of object.
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape*	m_pShape;

	// Number of the polygon.
 
	// Nub Polygon, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nNubPolygon;

	// Number of the points.
 
	// Number Points, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nNumPoints;

	// Is it selected.
 
	// Selected, This member sets TRUE if it is right.  
	BOOL			m_bSelected;

	// Is is plus handle.
 
	// Plus Handle, This member sets TRUE if it is right.  
	BOOL			m_bPlusHandle;

	// Is is locked.
 
	// Lock, This member sets TRUE if it is right.  
	BOOL			m_bLock;

	// Style of handle.
 
	// Style, This member specify FOPHdlKind object.  
	FOPHdlKind		m_nStyle;

	// Is control handle.
 
	// Is , This member sets TRUE if it is right.  
	BOOL			m_bIsControl;

	// Number of line.
 
	// Lines, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nLines;

	// Line first point.
 
	// First, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPPoint		m_ptFirst;

	// Line second point
 
	// Second, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPPoint		m_ptSecond;

 
	// Cursor Id, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nCursorId;
};


/////////////////////////////////////////////////////////////////////////////
// CFOPHandle list -- list of shape's drag control handle.

 
//===========================================================================
// Summary:
//      To use a CFOPHandleList object, just call the constructor.
//      F O P Handle List
//===========================================================================

class FO_EXT_CLASS CFOPHandleList
{
protected:
	// List of the handles
 
	// Handles, This member specify FOPContainer object.  
	FOPContainer			m_listHandles;

	// Size of the handle
 
	// Handle Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						m_nHandleSize;

public:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Handle List, Constructs a CFOPHandleList object.
	//		Returns A  value (Object).
	CFOPHandleList();

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Handle List, Destructor of class CFOPHandleList
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPHandleList();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear, Remove the specify data from the list.

	// Clear all the data within the list
	void Clear();

	void CloneFrom(CFOPHandleList &list);


	// Remove all;
	void RemoveAll();

	// Obtain the handle count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Handle Count, Returns the specified value.
	//		Returns a int type value.
	int    GetHandleCount() const                       { return m_listHandles.Count(); }

	// Obtain handle at a specify index
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Handle, Returns the specified value.
	//		Returns a pointer to the object CFOPHandle,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	CFOPHandle*  GetHandle(int nIndex) const            { return (CFOPHandle*)(m_listHandles.GetObject(nIndex)); }

	// Obtain handle's index within the list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Handle Index, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		pHandle---pHandle, A pointer to the const CFOPHandle or NULL if the call failed.
	int    GetHandleIndex(const CFOPHandle* pHandle) const;

	// Change handle size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Handle Size, Sets a specify value to current class CFOPHandleList
	// Parameters:
	//		nSize---nSize, Specifies A integer value.
	void     SetHandleSize(int nSize);

	// Obtain handle's size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Handle Size, Returns the specified value.
	//		Returns a int type value.
	int      GetHandleSize() const                      { return m_nHandleSize; }
	
	// Add new handle to the list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Handle, Adds an object to the specify list.
	// Parameters:
	//		pHandle---pHandle, A pointer to the CFOPHandle or NULL if the call failed.  
	//		bAtHead---At Head, Specifies A Boolean value.
	void    AddHandle(CFOPHandle* pHandle, BOOL bAtHead = FALSE);

	// Remove handle from the list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Handle, Call this function to remove a specify value from the specify object.
	//		Returns a pointer to the object CFOPHandle,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	CFOPHandle* RemoveHandle(int nIndex);

	// Hit test
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	//		Returns a pointer to the object CFOPHandle,or NULL if the call failed  
	// Parameters:
	//		ptPnt---ptPnt, Specifies A integer value.  
	//		bReverse---bReverse, Specifies A Boolean value.  
	//		bFindNext---Find Next, Specifies A Boolean value.  
	//		pHdlPrev---Handle Previous, A pointer to the CFOPHandle or NULL if the call failed.
	CFOPHandle* HitTest(const FOPPoint& ptPnt, BOOL bReverse = FALSE,
		BOOL bFindNext = FALSE, CFOPHandle* pHdlPrev = NULL) const;

	// Obtain handle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Handle, Returns the specified value.
	//		Returns a pointer to the object CFOPHandle,or NULL if the call failed  
	// Parameters:
	//		nType---nType, Specifies a FOPHdlKind nType object(Value).
	CFOPHandle* GetHandle(FOPHdlKind nType) const;
};

/////////////////////////////////////////////////////////////////////////////
// CFOPSelectHandleItem -- quick choose handle item, mostly, it is the item that showing at the below of shape.

 
//===========================================================================
// Summary:
//      To use a CFOPSelectHandleItem object, just call the constructor.
//      F O P Select Handle Item
//===========================================================================

class FO_EXT_CLASS CFOPSelectHandleItem
{
public:

	// Constructor
	// nType -- type of selection handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Select Handle Item, Constructs a CFOPSelectHandleItem object.
	//		Returns A  value (Object).  
	// Parameters:
	//		&nType---&nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	CFOPSelectHandleItem(const UINT &nType);

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Select Handle Item, Destructor of class CFOPSelectHandleItem
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPSelectHandleItem();

	// Hit Test
	// point -- point for hitting.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual BOOL HitTest(CPoint point);

	// Creates GDI objects and sets up the device context for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draw
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&pt---Specifies A CPoint type value.
	virtual void OnDraw(CDC *pDC,const CPoint &pt);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);

	// Set Rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Rectangle, Sets a specify value to current class CFOPSelectHandleItem
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.
	void	SetItemRect(const CRect &rcPos)			{ m_rcPosition = rcPos; }

	// Get Rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect	GetItemRect() const;

	// Obtain the button type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Type, Returns the specified value.
	//		Returns a UINT type value.
	UINT GetType() const { return m_nType; }

	// Change the button type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Type, Sets a specify value to current class CFOPSelectHandleItem
	// Parameters:
	//		&nType---&nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void SetType(const UINT &nType) { m_nType = nType; }

protected:

	// Position of the cell.
 
	// Position, This member sets a CRect value.  
	CRect		m_rcPosition;

	// Type of the button item.
 
	// Type, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT		m_nType;
};

/////////////////////////////////////////////////////////////////////////////
// CFOPSelectHandleItem list -- list of quick selection handle.

 
//===========================================================================
// Summary:
//      To use a CFOPSelectHandleList object, just call the constructor.
//      F O P Select Handle List
//===========================================================================

class FO_EXT_CLASS CFOPSelectHandleList
{
protected:
	// List of the handles
 
	// Handles, This member specify FOPContainer object.  
	FOPContainer			m_listHandles;

public:
	// Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Select Handle List, Constructs a CFOPSelectHandleList object.
	//		Returns A  value (Object).
	CFOPSelectHandleList();

	// Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Select Handle List, Destructor of class CFOPSelectHandleList
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPSelectHandleList();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear, Remove the specify data from the list.

	// Clear all the data within the list
	void Clear();

	// Obtain the handle count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Handle Count, Returns the specified value.
	//		Returns a int type value.
	int    GetHandleCount() const                       { return m_listHandles.Count(); }

	// Obtain handle at a specify index
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Handle, Returns the specified value.
	//		Returns a pointer to the object CFOPSelectHandleItem,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	CFOPSelectHandleItem*  GetHandle(int nIndex) const            { return (CFOPSelectHandleItem*)(m_listHandles.GetObject(nIndex)); }

	// Add new handle to the list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Handle, Adds an object to the specify list.
	// Parameters:
	//		pHandle---pHandle, A pointer to the CFOPSelectHandleItem or NULL if the call failed.  
	//		bAtHead---At Head, Specifies A Boolean value.
	void    AddHandle(CFOPSelectHandleItem* pHandle, BOOL bAtHead = FALSE);

	// Remove handle from the list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Handle, Call this function to remove a specify value from the specify object.
	//		Returns a pointer to the object CFOPSelectHandleItem,or NULL if the call failed  
	// Parameters:
	//		nIndex---nIndex, Specifies A integer value.
	CFOPSelectHandleItem* RemoveHandle(int nIndex);

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPHANDLE_H__8DEF6EE5_95CB_4391_8598_CCA8063CE327__INCLUDED_)
