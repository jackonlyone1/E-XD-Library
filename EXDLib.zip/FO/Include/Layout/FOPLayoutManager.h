//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOPLAYOUTMANAGER_H__2CEBA05C_C37D_4FC2_A7B9_D19FBD455627__INCLUDED_)
#define FO_FOPLAYOUTMANAGER_H__2CEBA05C_C37D_4FC2_A7B9_D19FBD455627__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOCompList.h"
#include "FODrawShape.h"

const int c_nDEFAULT_OFFSET = 10;
class CFODataModel;

///////////////////////////////////////////////////////////////////////
// CFOPLayoutManager, this is the base class of graph layout, it should be called like
// the following codes:
// 	CFOPVertLayout layout;
// 	layout.Initialize(GetCurrentModel(), *GetCurrentModel()->GetShapes());
// 	layout.DoLayout();

 
//===========================================================================
// Summary:
//     The CFOPLayoutManager class derived from CObject
//      F O P Layout Manager
//===========================================================================

class FO_EXT_CLASS CFOPLayoutManager : public CObject  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPLayoutManager---F O P Layout Manager, Specifies a E-XD++ CFOPLayoutManager object (Value).
	DECLARE_SERIAL(CFOPLayoutManager);
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Layout Manager, Constructs a CFOPLayoutManager object.
	//		Returns A  value (Object).
	CFOPLayoutManager();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Layout Manager, Destructor of class CFOPLayoutManager
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPLayoutManager();

public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initialize, Call Initialize after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFODataModel  or NULL if the call failed.  
	//		list---Specifies a E-XD++ CFODrawShapeList& list object (Value).
	// Initialize layout manager
	virtual void Initialize(CFODataModel *pModel, CFODrawShapeList& list);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Initialize, Call Initialize after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFODataModel  or NULL if the call failed.  
	//		list---Specifies a E-XD++ CFODrawShapeSet& list object (Value).
	// Initialize layout manager
	virtual void Initialize(CFODataModel *pModel, CFODrawShapeSet& list);

	// Layout method
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Layout, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoLayout();

	// Is shape movable or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Moved, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pNode---*pNode, A pointer to the CFODrawShape  or NULL if the call failed.
	BOOL IsMoved(CFODrawShape *pNode);

	// Obtain horizontal space.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Horizontal Space, Returns the specified value.
	//		Returns a float value.
	float GetHorzSpace() const { return m_nHorzSpace; }

	// Change horizontal space.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Horizontal Space, Sets a specify value to current class CFOPLayoutManager
	// Parameters:
	//		&nSpace---&nSpace, Specifies A float value.
	void SetHorzSpace(const float &nSpace) { m_nHorzSpace = nSpace; }


	// Obtain vertical space.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Vertical Space, Returns the specified value.
	//		Returns a float value.
	float GetVertSpace() const { return m_nVertSpace; }

	// Change vertical space.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Vertical Space, Sets a specify value to current class CFOPLayoutManager
	// Parameters:
	//		&nSpace---&nSpace, Specifies A float value.
	void SetVertSpace(const float &nSpace) { m_nVertSpace = nSpace; }

	// Obtain the pointer of data model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Model, Returns the specified value.
	//		Returns a pointer to the object CFODataModel,or NULL if the call failed
	CFODataModel* GetModel() { return m_pModel; }

	// Update progress bar's information with the following method
	// nCurPos -- value from 0 - 100
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Progress, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nCurPos---Current Position, Specifies A integer value.
	virtual void UpdateProgress(const int &nCurPos);

	// Enable undo support or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Undo Support, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bEnable---&bEnable, Specifies A Boolean value.
	void EnableUndoSupport(const BOOL &bEnable) { m_bWithUndo = bEnable; }

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Random, .
	//		Returns A double value (Object).  
	// Parameters:
	//		(*fun)(double)---A pointer to the double ( or NULL if the call failed.  
	//		xmin---Specifies a double xmin = 0 object(Value).  
	//		xmax---Specifies a double xmax = 1 object(Value).
	// Generate random value, it will between minimize and maximize.
	double Random(double (*fun)(double), double xmin = 0, double xmax = 1);

public:

	// list of nodes
 
	// Nodes, This member specify E-XD++ CFODrawShapeSet object.  
	CFODrawShapeSet	m_Nodes;

	// List of links.
 
	// Links, This member specify E-XD++ CFODrawShapeSet object.  
	CFODrawShapeSet m_Links;

	// Initial or not.
 
	// Inited, This member sets TRUE if it is right.  
	BOOL			m_bInited;

	// Vertical Space
 
	// Vertical Space, This member specify The float keyword designates a 32-bit floating-point number.  
	float			m_nVertSpace;

	// Horizontal space
 
	// Horizontal Space, This member specify The float keyword designates a 32-bit floating-point number.  
	float			m_nHorzSpace;

	// X border
 
	// X Border, This member specify The float keyword designates a 32-bit floating-point number.  
	float			m_fXBorder;

	// Y border
 
	// Y Border, This member specify The float keyword designates a 32-bit floating-point number.  
	float			m_fYBorder;

	// The most height.
 
	// Y Highest, This member specify The float keyword designates a 32-bit floating-point number.  
	float			m_fYHighest;

	// Data model pointer.
 
	// Model, This member maintains a pointer to the object CFODataModel.  
	CFODataModel	*m_pModel;

	// Need undo support or not.
 
	// With Undo, This member sets TRUE if it is right.  
	BOOL			m_bWithUndo;

};

///////////////////////////////////////////////////////
// CFOPShapeSet -- set of shapes.

 
//===========================================================================
// Summary:
//     The CFOPShapeSet class derived from CObject
//      F O P Shape Set
//===========================================================================

class FO_EXT_CLASS CFOPShapeSet : public CObject  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPShapeSet---F O P Shape Set, Specifies a E-XD++ CFOPShapeSet object (Value).
	DECLARE_SERIAL(CFOPShapeSet);
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Shape Set, Constructs a CFOPShapeSet object.
	//		Returns A  value (Object).
	CFOPShapeSet();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Shape Set, Destructor of class CFOPShapeSet
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPShapeSet();

public:

	//The list of Form.
 
	// Shape Set, This member specify E-XD++ CFODrawShapeSet object.  
	CFODrawShapeSet	m_ShapeSet;

};

#endif // !defined(FO_FOPLAYOUTMANAGER_H__2CEBA05C_C37D_4FC2_A7B9_D19FBD455627__INCLUDED_)
