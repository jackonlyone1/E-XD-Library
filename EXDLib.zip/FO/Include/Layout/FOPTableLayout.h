//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOPTABLELAYOUT_H__350F393E_E791_46C7_A58A_C41668752A72__INCLUDED_)
#define FO_FOPTABLELAYOUT_H__350F393E_E791_46C7_A58A_C41668752A72__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOPLayoutManager.h"
#include "FODrawPortsShape.h"

enum FOPCellSizeMode
{
	foEqualToMaxNode = 0,
	foMinimalTable,
	foMinimal
};

enum FOPOrientation
{		
	// Horizontal.
	foHorizontal,
		
	// Vertical.
	foVertical
};

//////////////////////////////////////////////////////////////////////
// CFOPTableLayout -- table layout.

 
//===========================================================================
// Summary:
//     The CFOPTableLayout class derived from CFOPLayoutManager
//      F O P Table Layout
//===========================================================================

class FO_EXT_CLASS CFOPTableLayout : public CFOPLayoutManager  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPTableLayout---F O P Table Layout, Specifies a E-XD++ CFOPTableLayout object (Value).
	DECLARE_SERIAL(CFOPTableLayout);
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Table Layout, Constructs a CFOPTableLayout object.
	//		Returns A  value (Object).
	CFOPTableLayout();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Table Layout, Constructs a CFOPTableLayout object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPTableLayout& src object(Value).
	CFOPTableLayout(const CFOPTableLayout& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Table Layout, Destructor of class CFOPTableLayout
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPTableLayout();

public:
	
	// Layout method
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Layout, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoLayout();

	// Obtain the size of cells.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cell Size, Returns the specified value.
	//		Returns A FOPSize value (Object).  
	// Parameters:
	//		list---Specifies a E-XD++ CFODrawShapeSet& list object (Value).
	FOPSize GetCellSize(CFODrawShapeSet& list);

	// Obtain count of cell that should show.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Cell Count, Returns the specified value.
	//		Returns A FOPSize value (Object).  
	// Parameters:
	//		&szCellSize---Cell Size, Specifies a const FOPSize &szCellSize object(Value).
	FOPSize GetCellCount( const FOPSize &szCellSize );

	// Obtain max dimension.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Dimension, Returns the specified value.
	// Parameters:
	//		&lstNodes---&lstNodes, Specifies a E-XD++ CFODrawShapeSet &lstNodes object (Value).  
	//		CArray<float---Array<float, Specifies A CArray array.  
	//		&lstDimensionColumns---Dimension Columns, Specifies A float value.  
	//		CArray<float---Array<float, Specifies A CArray array.  
	//		&lstDimensionRows---Dimension Rows, Specifies A float value.  
	//		&szCellCount---Cell Count, Specifies a FOPSize &szCellCount object(Value).
	void GetMaxDimension( CFODrawShapeSet &lstNodes, CArray<float, float> &lstDimensionColumns, 
		CArray<float, float> &lstDimensionRows, FOPSize &szCellCount );

	// Minimal layout.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Minimal Layout, .
	// Parameters:
	//		&lstNodes---&lstNodes, Specifies a E-XD++ CFODrawShapeSet &lstNodes object (Value).
	void MinimalLayout(CFODrawShapeSet &lstNodes);

	// Minimal table layout
	
	//-----------------------------------------------------------------------
	// Summary:
	// Minimal Table Layout, .
	// Parameters:
	//		&lstNodes---&lstNodes, Specifies a E-XD++ CFODrawShapeSet &lstNodes object (Value).
	void MinimalTableLayout(CFODrawShapeSet &lstNodes);

	// Equal to max layout
	
	//-----------------------------------------------------------------------
	// Summary:
	// Equal To Maximize Layout, .
	// Parameters:
	//		&lstNodes---&lstNodes, Specifies a E-XD++ CFODrawShapeSet &lstNodes object (Value).
	void EqualToMaxLayout(CFODrawShapeSet &lstNodes);

	// Ignore node.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Ignore Node, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual BOOL IgnoreNode(CFODrawShape *pShape);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	// Max size for layout.
 
	// Maximize Size, This member specify FOPSize object.  
	FOPSize			m_szMaxSize;

	// Maximize cell count.
 
	// Maximize Cell Count, This member specify FOPSize object.  
	FOPSize			m_szMaxCellCount;

	// Orientation
 
	// This member specify FOPOrientation object.  
	FOPOrientation	m_orientation;

	// Size mode
 
	// Size Mode, This member specify FOPCellSizeMode object.  
	FOPCellSizeMode	m_cellSizeMode;
};

///////////////////////////////////////////////////////////////////////
// CFOPLayeredLayout -- layered layout

 
//===========================================================================
// Summary:
//     The CFOPLayeredLayout class derived from CFOPLayoutManager
//      F O P Layered Layout
//===========================================================================

class FO_EXT_CLASS CFOPLayeredLayout : public CFOPLayoutManager  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPLayeredLayout---F O P Layered Layout, Specifies a E-XD++ CFOPLayeredLayout object (Value).
	DECLARE_SERIAL(CFOPLayeredLayout);
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Layered Layout, Constructs a CFOPLayeredLayout object.
	//		Returns A  value (Object).
	CFOPLayeredLayout();
	
	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Layered Layout, Destructor of class CFOPLayeredLayout
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPLayeredLayout();
	
	// Layout method
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Layout New, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nDir---&nDir, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&nSearchLayer---Search Layer, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&nSearchPath---Search Path, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		&nLayerSpace---Layer Space, Specifies A integer value.  
	//		&nColumnSpace---Column Space, Specifies A integer value.  
	//		&nRunTimes---Run Times, Specifies A integer value.  
	//		&bAdvLayout---Advance Layout, Specifies A Boolean value.
	virtual void DoLayoutNew(const UINT &nDir = FOP_LAYOUT_DOWN, 
		const UINT &nSearchLayer = FOP_LAYER_SEARCH1, 
		const UINT &nSearchPath = FOP_PATH_DEPTH3,  
		const int &nLayerSpace = 60,
		const int &nColumnSpace = 30,
		const int &nRunTimes = 3,
		const BOOL &bAdvLayout = FALSE);
	
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initialize, Call Initialize after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFODataModel  or NULL if the call failed.  
	//		list---Specifies a E-XD++ CFODrawShapeList& list object (Value).
	// Initialize layout manager
	virtual void	Initialize(CFODataModel *pModel, CFODrawShapeList& list);
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initialize, Call Initialize after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFODataModel  or NULL if the call failed.  
	//		list---Specifies a E-XD++ CFODrawShapeSet& list object (Value).
	// Initialize layout manager
	virtual void	Initialize(CFODataModel *pModel, CFODrawShapeSet& list);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);
	
	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);
	
public:
	
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
};

#endif // !defined(FO_FOPTABLELAYOUT_H__350F393E_E791_46C7_A58A_C41668752A72__INCLUDED_)
