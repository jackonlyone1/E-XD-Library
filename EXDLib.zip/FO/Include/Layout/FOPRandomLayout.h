//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOPRANDOMLAYOUT_H__E64BD9F8_6D83_40E5_AC87_AC43A7EF06D4__INCLUDED_)
#define FO_FOPRANDOMLAYOUT_H__E64BD9F8_6D83_40E5_AC87_AC43A7EF06D4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOPLayoutManager.h"
#include "FOLinkShape.h"
#include "FODrawPortsShape.h"

////////////////////////////////////////////////////////////////////////////////
// CFOPRandomLayout -- random layout.

 
//===========================================================================
// Summary:
//     The CFOPRandomLayout class derived from CFOPLayoutManager
//      F O P Random Layout
//===========================================================================

class FO_EXT_CLASS CFOPRandomLayout : public CFOPLayoutManager  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPRandomLayout---F O P Random Layout, Specifies a E-XD++ CFOPRandomLayout object (Value).
	DECLARE_SERIAL(CFOPRandomLayout);
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Random Layout, Constructs a CFOPRandomLayout object.
	//		Returns A  value (Object).
	CFOPRandomLayout();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Random Layout, Destructor of class CFOPRandomLayout
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPRandomLayout();

	// Layout method
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Layout, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoLayout();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	// Maximize x value
 
	// This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			maxx;

	// Maximize y value
 
	// This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			maxy;

	// Minimize x value.
 
	// This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			minx;

	// Minimize y value.
 
	// This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			miny;
};

//////////////////////////////////////////////////////////////////////////////////
// CFOPHorzLayout this class is designed for horizontal tree layout.

class CFODirectActionMacro;
 
//===========================================================================
// Summary:
//     The CFOPHorzLayout class derived from CFOPLayoutManager
//      F O P Horizontal Layout
//===========================================================================

class FO_EXT_CLASS CFOPHorzLayout : public CFOPLayoutManager  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPHorzLayout---F O P Horizontal Layout, Specifies a E-XD++ CFOPHorzLayout object (Value).
	DECLARE_SERIAL(CFOPHorzLayout);
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Horizontal Layout, Constructs a CFOPHorzLayout object.
	//		Returns A  value (Object).  
	// Parameters:
	//		&bReverse---&bReverse, Specifies A Boolean value.
	CFOPHorzLayout(const bool &bReverse = false);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Horizontal Layout, Destructor of class CFOPHorzLayout
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPHorzLayout();

	// Layout method, call Initialize before this method is called.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Layout, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoLayout();

	// Find root within the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Root, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFODrawPortsShape,or NULL if the call failed
	CFODrawPortsShape* FindRoot();

	// Layout horizontal tree style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Layout Tree H, .
	//		Returns a float value.  
	// Parameters:
	//		node---A pointer to the CFODrawPortsShape or NULL if the call failed.  
	//		oldx---Specifies A float value.  
	//		oldy---Specifies A float value.  
	//		*pAction---*pAction, A pointer to the CFODirectActionMacro  or NULL if the call failed.
	float LayoutTreeH(CFODrawPortsShape* node, float oldx, float oldy, CFODirectActionMacro *pAction);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:

	// Layer space.
 
	// Layer Space, This member specify The float keyword designates a 32-bit floating-point number.  
	float		m_nLayerSpace;
	
	// Space between nodes.
 
	// Node Space, This member specify The float keyword designates a 32-bit floating-point number.  
    float		m_nNodeSpace;
	
	// Origin of layout diagram.
 
	// Origin, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    CPoint		m_ptOrigin;
	
	// Reverse or not.
 
	// Reverse, Specify A Boolean value.  
	bool		m_bReverse;
};

////////////////////////////////////////////////////////////////////
// CFOPVertLayout, this class is designed for vertical tree layout.

 
//===========================================================================
// Summary:
//     The CFOPVertLayout class derived from CFOPLayoutManager
//      F O P Vertical Layout
//===========================================================================

class FO_EXT_CLASS CFOPVertLayout : public CFOPLayoutManager  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPVertLayout---F O P Vertical Layout, Specifies a E-XD++ CFOPVertLayout object (Value).
	DECLARE_SERIAL(CFOPVertLayout);
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Vertical Layout, Constructs a CFOPVertLayout object.
	//		Returns A  value (Object).  
	// Parameters:
	//		&bReverse---&bReverse, Specifies A Boolean value.
	CFOPVertLayout(const bool &bReverse = false);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Vertical Layout, Destructor of class CFOPVertLayout
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPVertLayout();

	// Layout method, call Initialize before this method is called.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Layout, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoLayout();

	// Find root within the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Root, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFODrawPortsShape,or NULL if the call failed
	CFODrawPortsShape* FindRoot();

	// Layout horizontal tree style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Layout Tree V, .
	//		Returns a float value.  
	// Parameters:
	//		node---A pointer to the CFODrawPortsShape or NULL if the call failed.  
	//		oldx---Specifies A float value.  
	//		oldy---Specifies A float value.  
	//		*pAction---*pAction, A pointer to the CFODirectActionMacro  or NULL if the call failed.
	float LayoutTreeV(CFODrawPortsShape* node, float oldx, float oldy, CFODirectActionMacro *pAction);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

public:

	// Layer space.
 
	// Layer Space, This member specify The float keyword designates a 32-bit floating-point number.  
	float		m_nLayerSpace;

	// Space between nodes.
 
	// Node Space, This member specify The float keyword designates a 32-bit floating-point number.  
    float		m_nNodeSpace;

	// Origin of layout diagram.
 
	// Origin, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    CPoint		m_ptOrigin;

	// Reverse or not.
 
	// Reverse, Specify A Boolean value.  
	bool		m_bReverse;
};


#endif // !defined(FO_FOPRANDOMLAYOUT_H__E64BD9F8_6D83_40E5_AC87_AC43A7EF06D4__INCLUDED_)
