//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOFormSizeAction.h: interface for the CFOFormSizeAction class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOFORMSIZEACTION_H__5D3EDD1C_F259_11DD_A433_525400EA266C__INCLUDED_)
#define AFX_FOFORMSIZEACTION_H__5D3EDD1C_F259_11DD_A433_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOAction.h"

//////////////////////////////////////////////////////////////////////////////////
// CFOFormSizeAction -- action that defined to change the size of canvas.

 
//===========================================================================
// Summary:
//     The CFOFormSizeAction class derived from CFOAction
//      F O Form Size Action
//===========================================================================

class FO_EXT_CLASS CFOFormSizeAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOFormSizeAction---F O Form Size Action, Specifies a E-XD++ CFOFormSizeAction object (Value).
	DECLARE_ACTION(CFOFormSizeAction)
public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Form Size Action, Constructs a CFOFormSizeAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.  
	//		rcNew---rcNew, Specifies A CRect type value.
	CFOFormSizeAction(CFODataModel* pModel,CRect rcNew);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Form Size Action, Destructor of class CFOFormSizeAction
	//		Returns A  value (Object).
	~CFOFormSizeAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;


	// Get the current position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Position, Returns the specified value.
	//		Returns a CRect type value.
	CRect GetCurrentPos()			{ return m_rcNew; }

	// Set the position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Current Position, Sets a specify value to current class CFOFormSizeAction
	// Parameters:
	//		rcPos---rcPos, Specifies A CRect type value.
	void SetCurrentPos(CRect rcPos) { m_rcNew = rcPos; }

protected:
	// Background shape.
 
	// New rect.
 
	// New, This member sets a CRect value.  
	CRect			m_rcNew;   

	// Old rect.
 
	// Old, This member sets a CRect value.  
	CRect			m_rcOld;   
 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

#endif // !defined(AFX_FOFORMSIZEACTION_H__5D3EDD1C_F259_11DD_A433_525400EA266C__INCLUDED_)
