//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOPSUBGRAPHSHAPE_H__D43D636F_1F9C_4D03_B7E3_2E2CAD06B1F9__INCLUDED_)
#define FO_FOPSUBGRAPHSHAPE_H__D43D636F_1F9C_4D03_B7E3_2E2CAD06B1F9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOCompositeShape.h"

////////////////////////////////////////////////////////////////////////
//------------------------------------------------------
// Description: CFOPSubGraphShape -- sub - graph shape, with this shape,
//				you can collect or expand all the children shapes by click
//				a cross button at top left corner.
//				ID: FOP_COMP_SUBGRAPH 220
// Author: Author.
//------------------------------------------------------

const COLORREF crDefaultSubTitleBar = RGB(211,211,241);

 
//===========================================================================
// Summary:
//     The CFOPSubGraphShape class derived from CFOCompositeShape
//      F O P Child Graph Shape
//===========================================================================

class FO_EXT_CLASS CFOPSubGraphShape : public CFOCompositeShape  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPSubGraphShape---F O P Child Graph Shape, Specifies a E-XD++ CFOPSubGraphShape object (Value).
	DECLARE_SERIAL(CFOPSubGraphShape);
public:

	//-----------------------------------------------------------------------
	// Summary:
	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Child Graph Shape, Constructs a CFOPSubGraphShape object.
	//		Returns A  value (Object).
	CFOPSubGraphShape();

	//-----------------------------------------------------------------------
	// Summary:
	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Child Graph Shape, Constructs a CFOPSubGraphShape object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPSubGraphShape& src object(Value).
	CFOPSubGraphShape(const CFOPSubGraphShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Child Graph Shape, Destructor of class CFOPSubGraphShape
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPSubGraphShape();

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOPSubGraphShape object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		strCaption---strCaption, Specifies A CString type value.
	// Creates the sub shape from a CRect object.
	// rcPos -- position of the shape.
	// strCaption -- caption of the shape
	virtual void Create(CRect &rcPos, CString strCaption = _T(""));

	//-----------------------------------------------------------------------
	// Summary:
	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOPSubGraphShape& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOPSubGraphShape& src object(Value).
	CFOPSubGraphShape& operator=(const CFOPSubGraphShape& src);

	//-----------------------------------------------------------------------
	// Summary:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFODrawShape* Copy() const;

	//-----------------------------------------------------------------------
	// Summary:
	//Generate Shape Area
	// pRgn -- pointer of the area
	
	//-----------------------------------------------------------------------
	// Summary:
	// Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pRgn---pRgn, A pointer to the CFOArea or NULL if the call failed.
	virtual void GeometryUpdated(CFOArea* pRgn);

	//-----------------------------------------------------------------------
	// Summary:
	// Update parent area.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Main Area, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void UpdateMainArea();
	// Calc simple polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Imp Calculate X Polygon, .
	//		Returns A FOPSimplePolygon value (Object).  
	// Parameters:
	//		rRect1---rRect1, Specifies a const FOPRect& rRect1 object(Value).  
	//		nRad1---nRad1, Specifies A 32-bit long signed integer.
	FOPSimplePolygon ImpCalcXPoly(const FOPRect& rRect1, long nRad1) const;
	
public:
	// Export to SVG
	virtual void ExportToSVG(CStdioFile*);
	
	// Obtain the composite of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path Simple Polygon, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rPoly---rPoly, Specifies a FOPSimpleCompositePolygon& rPoly object(Value).
	virtual void GetPathSimplePolygon(FOPSimpleCompositePolygon& rPoly) const;

	// Add svg text
	virtual void		  SVG_AddText(CString &outputStringL);

public:

	// Calc the label start position.
	// pDC -- pointer of the DC.
	// bFullSize -- using full size or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Label Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&bFullSize---Full Size, Specifies A Boolean value.
	virtual CRect CalcLabelPosition(CDC *pDC,BOOL &bFullSize) const;

public:
	
	// WM_LBUTTONDOWN message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonDown(UINT nFlags, CPoint point); 

	// WM_LBUTTONUP message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	virtual void OnLButtonUp(UINT nFlags, CPoint point);

	CFODrawShape * FO_FODoHitComposite2(CFOPSubGraphShape *pHitComp, const CPoint &point, const CRect &rcHittest);

	// Return Expand value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Expand, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetExpand() const { return m_bExpand;}

	// Change Expand value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Expand, Sets a specify value to current class CFOPSubGraphShape
	// Parameters:
	//		&bValue---&bValue, Specifies A Boolean value.
	void SetExpand( const BOOL &bValue ) {m_bExpand = bValue; }

	// Return SaveExpandRect value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Save Expand Scale X, Returns the specified value.
	//		Returns A double value (Object).
	double GetSaveExpandScaleX() const { return m_dCollectScaleX;}

	// Change SaveExpandRect value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Save Expand Scale X, Sets a specify value to current class CFOPSubGraphShape
	// Parameters:
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).
	void SetSaveExpandScaleX( const double &dValue ) {m_dCollectScaleX = dValue; }

	// Return SaveExpandRect value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Save Expand Scale Y, Returns the specified value.
	//		Returns A double value (Object).
	double GetSaveExpandScaleY() const { return m_dCollectScaleY;}
	
	// Change SaveExpandRect value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Save Expand Scale Y, Sets a specify value to current class CFOPSubGraphShape
	// Parameters:
	//		&dValue---&dValue, Specifies a const double &dValue object(Value).
	void SetSaveExpandScaleY( const double &dValue ) {m_dCollectScaleY = dValue; }

	// Compute the Collect size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compute Collect Position, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect ComputeCollectPosition();

	// Compute expand scale.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compute Collect Scale X, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A double value (Object).
	virtual double ComputeCollectScaleX();

	// Get plus spots
	// lstHandle -- list of handles.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Plus Spot Location, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lstHandle---lstHandle, Specifies a E-XD++ CFOPHandleList& lstHandle object (Value).
	virtual void GetPlusSpotLocation(CFOPHandleList& lstHandle);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Expand, .
	// This member function is also a virtual function, you can Override it if you need,
	// Expand.
	virtual void Expand();

	BOOL FOPIsRectWithin1(CRect rcSmall, CRect rcLarge);
	BOOL FOPPtInSpecifyRect1(CPoint point, CRect rect);
	void FO_GetShapesIn2(CFOPSubGraphShape *pChildComp);

	// Implementation
	// Change the matrix data.
	// Mat -- new matrix data for applying.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Apply Abs Matrix Data, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&Mat---&Mat, Specifies a const CFOMatrix &Mat object(Value).
	virtual void ApplyAbsMatrixData(const CFOMatrix &Mat);

	// Expand.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Expand New, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ExpandNew();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Collect, .
	// This member function is also a virtual function, you can Override it if you need,
	// Collect
	virtual void Collect();

	// Collect
	
	//-----------------------------------------------------------------------
	// Summary:
	// Collect New, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void CollectNew();

	// Expand all the children sub-graphs
	
	//-----------------------------------------------------------------------
	// Summary:
	// Expand All, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ExpandAll();

	// Collect all the child shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Collect All, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void CollectAll();

	// Obtain the parent sub-graph
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Parent Child Graph, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFOPSubGraphShape ,or NULL if the call failed
	CFOPSubGraphShape *FindParentSubGraph();

	// Is width and height locked.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Resize Protect, Determines if the given value is correct or exist.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL		IsResizeProtect() const;

	// Update current shape's position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Position, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void UpdatePosition();

	// Get not consider children state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Not Consider Children, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetNotConsiderChildren() const;

	// Enable not consider child's position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Not Consider Child, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bConsider---&bConsider, Specifies A Boolean value.
	void EnableNotConsiderChild(const BOOL &bConsider);

	// Do sub menu change.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Child Menu Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&nMenuItem---Menu Item, Specifies A integer value.  
	//		&strState---&strState, Specifies A CString type value.
	virtual void DoSubMenuChange(const int &nMenuItem, const CString &strState);

	// Get not all contained link shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Not All Contained Shapes, Returns the specified value.
	// Parameters:
	//		*pList---*pList, A pointer to the CFODrawShapeSet  or NULL if the call failed.
	void GetNotAllContainedShapes(CFODrawShapeSet *pList);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	// Compute current area.
	// pArea -- area pointer
	
	//-----------------------------------------------------------------------
	// Summary:
	// Extend Geometry Updated, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pArea---pArea, A pointer to the CFOArea or NULL if the call failed.
	virtual void  ExtGeometryUpdated(CFOArea* pArea);
	
	// Do scale and move.
	virtual void DoResizeAndMove(const FOPPoint &ptOri, double dXScale, double dYScale, const FOPPoint &ptOffset);

public:

	//Draw flat status.

	// Draws custom tracker.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Track Custom, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawTrackCustom(CDC *pDC);

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	// Draws the truely shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw(CDC *pDC);

	// Draws the flat status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Flat, Draws the flat status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawFlat(CDC *pDC);

	// Draws shadow of shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Shadow, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawShadow(CDC *pDC);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw3d, Draws the 3d status of the shape.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDraw3d(CDC *pDC);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);
	// Implementation

	// Drawing expand button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Expand Button, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	virtual void OnDrawExpandButton(CDC *pDC);

	// Hit test text.
	// ptHit -- logical hit point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Label, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOStaticShape ,or NULL if the call failed  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	virtual CFOStaticShape *HitTestLabel(const CPoint &ptHit);

	// Hit test child shape,return the pointer of the shape.
	// ptHit -- hit test point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Child, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	virtual CFODrawShape *HitTestChild(const CPoint &ptHit);

	// Hit test edit box.
	// pt -- hit test point. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Edit Box, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPEFormBaseShape ,or NULL if the call failed  
	// Parameters:
	//		pt---Specifies A CPoint type value.
	virtual CFOPEFormBaseShape *HitTestEditBox(const CPoint& pt);

	// Hit test inside box.
	// pt -- hit test point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test  Box, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPEFormBaseShape ,or NULL if the call failed  
	// Parameters:
	//		pt---Specifies A CPoint type value.
	virtual CFOPEFormBaseShape *HitTestCtrlBox(const CPoint& pt);

	// Hit test expand button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Expand Click Button, Determines if the mouse has been clicked on a component.
	//		Returns a pointer to the object CFOPSubGraphShape,or NULL if the call failed  
	// Parameters:
	//		pt---Specifies A CPoint type value.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	CFOPSubGraphShape* HitExpandClickButton(const CPoint& pt,UINT nFlags);

	// Hit test connect point,if it is hitted,return the hit connect port,else return NULL.
	// point -- log point.
	// bUseExt -- use a more big hit space
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape,or NULL if the call failed  
	// Parameters:
	//		point---Specifies A CPoint type value.  
	//		&bUseExt---Use Extend, Specifies A Boolean value.
	virtual CFOPortShape* HitTest(const CPoint& point,const BOOL &bUseExt = TRUE);

	// Hit test connect point,if it is hitted,return the hit connect port,else return NULL.
	// ptHit -- log point.
	// nExpand -- expand value of the point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Port, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPortShape,or NULL if the call failed  
	// Parameters:
	//		ptHit---ptHit, Specifies A CPoint type value.  
	//		nExpand---nExpand, Specifies A integer value.
	virtual CFOPortShape* HitTestPort(const CPoint& ptHit, int nExpand = 0) const;

	// Hit test child shape,return the pointer of the shape.
	// ptHit -- hit test point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Expand Button New, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	virtual BOOL HitTestExpandButtonNew(const CPoint &ptHit);

	// Get Shapes Within Rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shapes Within Rectangle, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		&rect---Specifies A CRect type value.  
	//		bFullSelect---Full Select, Specifies A Boolean value.  
	//		bSelectWithIn---Select With In, Specifies A Boolean value.
	virtual int		GetShapesWithinRect(
		// List of shapes.
		CFODrawShapeList* pShapeList, 
		// A specify rectangle.
		const CRect &rect,
		// Full select.
		BOOL bFullSelect,
		// Select within
		BOOL bSelectWithIn
		);

	//Get Shapes Within ellipse
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shapes Within Ellipse, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		pShapeList---Shape List, A pointer to the CFODrawShapeList or NULL if the call failed.  
	//		&rcEllipse---&rcEllipse, Specifies A CRect type value.  
	//		bFullSelect---Full Select, Specifies A Boolean value.  
	//		bSelectWithIn---Select With In, Specifies A Boolean value.
	virtual int		GetShapesWithinEllipse(
		// List of shapes.
		CFODrawShapeList* pShapeList, 
		// A specify rectangle for ellipse
		const CRect &rcEllipse,
		// Full select.
		BOOL bFullSelect,
		// Select within
		BOOL bSelectWithIn
		);

	// Obtain the rectangle within any sub graph shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get With In Child Graph, Returns the specified value.
	//		Returns a pointer to the object CFOPSubGraphShape ,or NULL if the call failed  
	// Parameters:
	//		&rcCheck---&rcCheck, Specifies A CRect type value.
	virtual CFOPSubGraphShape *GetWithInSubGraph(const CRect &rcCheck);

	// Scale shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dX---dX, Specifies a double dX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void ScaleShape(double dX, double dY, double dOX, double dOY);

	// Scale shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale Track Shape, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dfX---dfX, Specifies a double dfX object(Value).  
	//		dY---dY, Specifies a double dY object(Value).  
	//		dOX---O X, Specifies a double dOX object(Value).  
	//		dOY---O Y, Specifies a double dOY object(Value).
	virtual void ScaleTrackShape(double dfX, double dY, double dOX, double dOY);

	// Is scale all.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Scale All, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsScaleAll() const;

	// Enable scale all or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Scale All, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bScaleAll---Scale All, Specifies A Boolean value.
	void EnableScaleAll(const BOOL &bScaleAll);

	// Search and add new property object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Add Custom Property, Search and add new property object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoAddCustProp();

	// Save all expands
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save All Expands, Call this function to save the specify data to a file.

	void SaveAllExpands();

	// Restore all expands.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Restore All Expands, .

	void RestoreAllExpands();

	// Save all expands
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save All Expands2, Call this function to save the specify data to a file.

	void SaveAllExpands2();
	
	// Restore all expands.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Restore All Expands2, .

	void RestoreAllExpands2();
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

 
	// Save Expand, This member sets TRUE if it is right.  
	BOOL							  m_bSaveExpand;
protected:

	// Expand value.
 
	// Expand, This member sets TRUE if it is right.  
	BOOL                              m_bExpand;

	// Save Expand Rect X value.
 
	// Collect Scale X, This member specify double object.  
	double                            m_dCollectScaleX;

	// Save Expand Rect Y value.
 
	// Collect Scale Y, This member specify double object.  
	double                            m_dCollectScaleY;

	// save width.
 
	// Save Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int								  m_nSaveWidth;

	// save height
 
	// Save Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int								  m_nSaveHeight;

	// Save expand button rectange.
 
	// Expand Button, This member sets a CRect value.  
	CRect							  m_rcExpandButton;

};


#endif // !defined(FO_FOPSUBGRAPHSHAPE_H__D43D636F_1F9C_4D03_B7E3_2E2CAD06B1F9__INCLUDED_)
