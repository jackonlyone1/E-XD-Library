//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOTOOLBOXPAGE_H__BC45D795_E140_11D5_A4B1_525400EA266C__INCLUDED_)
#define AFX_FOTOOLBOXPAGE_H__BC45D795_E140_11D5_A4B1_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOToolBoxPage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOToolBoxPage window

#include <math.h>

enum FOMouseState
{
		LButtonDown		= 0x01,
		RButtonDown		= 0x02,
		BeFocus			= 0x04,
		OutFocus		= 0x08
};

#include "FOToolBoxItem.h"

const int		fo_DefaultItemFontSize	= 12;
const COLORREF	fo_DefaultItemFontColor = RGB(0,0,0);
const COLORREF	fo_DefaultPageBackColor = RGB(116,194,172);

/////////////////////////////////////////////////////////////////////////////
// CFOToolBoxPage class,this class is drived from CObject,it is used as the page of the 
// Toolbox page wnd.
//

 
//===========================================================================
// Summary:
//     The CFOToolBoxPage class derived from CObject
//      F O Tool Box Page
//===========================================================================

class FO_EXT_CLASS CFOToolBoxPage : public CObject  
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOToolBoxPage---F O Tool Box Page, Specifies a E-XD++ CFOToolBoxPage object (Value).
	DECLARE_SERIAL(CFOToolBoxPage);

public:

	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Tool Box Page, Constructs a CFOToolBoxPage object.
	//		Returns A  value (Object).
	CFOToolBoxPage();

	// Copy constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Tool Box Page, Constructs a CFOToolBoxPage object.
	//		Returns A  value (Object).  
	// Parameters:
	//		src---Specifies a const CFOToolBoxPage& src object(Value).
	CFOToolBoxPage(const CFOToolBoxPage& src);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Tool Box Page, Destructor of class CFOToolBoxPage
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOToolBoxPage();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Create, You construct a CFOToolBoxPage object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	// Creates the toolbox page object.
	// strLabel -- label of the page.
	virtual void Create(CString &strLabel);

	// Initi the data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Initial Page, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoInitPage();

	// Set or get modified flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Modified, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL	IsModified() { return bModified; }

	// Set modified.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Modify Flag, Sets a specify value to current class CFOToolBoxPage
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bModify---bModify, Specifies A Boolean value.
	virtual void SetModifyFlag(BOOL bModify = TRUE);

	// Obtain the modified flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Modify Flag, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetModifyFlag() const { return bModified; }

public:
	// Get toolbox item list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item List, Returns the specified value.
	//		Returns a pointer to the object CFOToolBoxItemSet ,or NULL if the call failed
	CFOToolBoxItemSet *GetItemList()		{ return &m_ItemList; }

	// Clear all data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear All, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ClearAll();

	// Delete its own.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Myself, .
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ReleaseMyself();

	// Clear image cache data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear Cache Data, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void ClearCacheData();

	// Find item with type.
	CFOToolBoxItem *FindItemWithType(const int &nType);

	// Find item with name.
	CFOToolBoxItem *FindItemWithName(const CString &strName);

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A E-XD++ CFOToolBoxPage& value (Object).  
	// Parameters:
	//		src---Specifies a const CFOToolBoxPage& src object(Value).
	CFOToolBoxPage& operator=(const CFOToolBoxPage& src);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Copy, Create a duplicate copy of this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOToolBoxPage,or NULL if the call failed
	// Creates a copy of this shape.
	virtual CFOToolBoxPage* Copy() const;

public:

	// Change font height with specify view type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change View Page Font, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nViewType---View Type, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual void ChangeViewPageFont(UINT nViewType);

public:

	// Get title position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Title Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetTitlePosition() const;

	// Change title position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Title Position, Sets a specify value to current class CFOToolBoxPage
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rc---Specifies A CRect type value.
	virtual void  SetTitlePosition( const CRect& rc );

	// Get page position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetPagePosition() const;

	// Change page position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Position, Sets a specify value to current class CFOToolBoxPage
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rc---Specifies A CRect type value.
	virtual void  SetPagePosition( const CRect& rc );

public:

	/*************************************************************************
	|*
	|* Below are the setting properties for the title bar of the page.
	|*
	\************************************************************************/

	// Get brush type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush Type, Returns the specified value.
	//		Returns a int type value.
	int			GetBrushType() const;

	// Chagne brush type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Brush Type, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&nStyle---&nStyle, Specifies A integer value.
	void		SetBrushType(const int &nStyle);

	// Get brush hatch type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush Hatch, Returns the specified value.
	//		Returns a int type value.
	int			GetBrushHatch() const;

	// Change brush hatch type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Brush Hatch, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&nHatch---&nHatch, Specifies A integer value.
	void		SetBrushHatch(const int &nHatch);

	// Get background color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Background Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetBkColor() const;

	// Change background color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Background Color, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&crBkColor---Background Color, Specifies A 32-bit COLORREF value used as a color value.
	void		SetBkColor(const COLORREF &crBkColor);

	// Get transparent mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Transparent, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetTransparent() const;

	// Change transparent mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Transparent, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&bTransparent---&bTransparent, Specifies A Boolean value.
	void		SetTransparent(const BOOL &bTransparent);

	// Get line width
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Width, Returns the specified value.
	//		Returns a int type value.
	int			GetLineWidth() const				{ return m_nLineWidth; }

	// Change line width
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Width, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&nWidth---&nWidth, Specifies A integer value.
	void		SetLineWidth(const int &nWidth);

	// Get line color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Line Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetLineColor() const				{ return m_crLine; }

	// Change line color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Line Color, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void		SetLineColor(const COLORREF &crColor);
	
	// Is current pen null
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Null Pen, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsNullPen() const;

	// Change to null pen.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Null Pen, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&bNull---&bNull, Specifies A Boolean value.
	void		SetNullPen(const BOOL &bNull);
	
	// Obtain the pen style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pen Style, Returns the specified value.
	//		Returns a int type value.
	int			GetPenStyle() const;

	// Change the pen style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pen Style, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&nPenStyle---Pen Style, Specifies A integer value.
	void		SetPenStyle(const int &nPenStyle);
	
	// Obtain the brush pattern color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pattern Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetPatternColor() const;

	// Change the brush pattern color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Pattern Color, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&cr---Specifies A 32-bit COLORREF value used as a color value.
	void		SetPatternColor(const COLORREF &cr);

	// Save file to disk.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save File, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL SaveFile();

public:
	// Obtain the text horz alignment type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Text Horizontal Alignment, Returns the specified value.
	//		Returns a UINT type value.
	UINT		GetTextHorzAlignment() const;

	// Change the text horz alignment type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Text Horizontal Alignment, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&nT---&nT, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void		SetTextHorzAlignment(const UINT &nT);
	
	// Obtain the text vert alignment type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Text Vertical Alignment, Returns the specified value.
	//		Returns a UINT type value.
	UINT		GetTextVertAlignment() const;

	// Change the text vert alignment type
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Text Vertical Alignment, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&nT---&nT, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	void		SetTextVertAlignment(const UINT &nT);
	
	// Is current text multiple lines mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Multiple Line, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		IsMultiLine() const;

	// Change current text to be multiple lines mode
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Multiple Line, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&bMulti---&bMulti, Specifies A Boolean value.
	void		SetMultiLine(const BOOL &bMulti);
	
	// Obtain the page caption
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Object Caption, Returns the specified value.
	//		Returns a CString type value.
	CString		GetObjectCaption() const;

	// Change the page caption
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Object Caption, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&str---Specifies A CString type value.
	void		SetObjectCaption(const CString &str);


public:

	/*************************************************************************
	|*
	|* Below are the settings for page's titlebar's font.
	|*
	\************************************************************************/

	// Get font Face Name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Face Name, Returns the specified value.
	//		Returns a CString type value.
	CString		GetFaceName() const;

	// Change the font Face Name,
	// lpszFaceName -- standard font face name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Face Name, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		lpszFaceName---Face Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	void		SetFaceName(LPCTSTR lpszFaceName);

	// Get Point Size of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point Size, Returns the specified value.
	//		Returns a int type value.
	int			GetPointSize() const;

	// Change font Point Size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Point Size, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&nPointSize---Point Size, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void		SetPointSize(const int &nPointSize, CDC* pDC = NULL);

	// Get Height of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Height, Returns the specified value.
	//		Returns a int type value.
	int			GetHeight() const;

	// Change the font Height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Height, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&nHeight---&nHeight, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void		SetHeight(const int &nHeight, CDC* pDC = NULL);

	// Get Font Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetFontColor() const;

	// Change the Font Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Font Color, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void		SetFontColor(const COLORREF &crColor);

	// Get Weight
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Weight, Returns the specified value.
	//		Returns a int type value.
	int			GetWeight() const;

	// Change the font Weight,
	// nWeight -- 700 is Bold,500 is Normal and must be nWeight >= 0 && nWeight <= 1000
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Weight, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&nWeight---&nWeight, Specifies A integer value.
	void		SetWeight(const int &nWeight);

	// Is It Italic
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Italic, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetItalic() const;

	// Change the font italic property.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Italic, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&bItalic---&bItalic, Specifies A Boolean value.
	void		SetItalic(const BOOL &bItalic);

	// Is It  Underline
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Underline, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetUnderline() const;

	// Change the font underline property.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Underline, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&bUnderline---&bUnderline, Specifies A Boolean value.
	void		SetUnderline(const BOOL &bUnderline);

	// Is It Strikeout
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Strikeout, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetStrikeout() const;

	// Change the font strikeout property.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Strikeout, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&bStrikeout---&bStrikeout, Specifies A Boolean value.
	void		SetStrikeout(const BOOL &bStrikeout);

	// Load resource file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Resource File, Call this function to read a specified number of bytes from the archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CWnd  or NULL if the call failed.  
	//		strFile---strFile, Specifies A CString type value.
	virtual BOOL LoadResFile(CWnd *pWnd,CString strFile);

	// Save resource file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Resource File, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		strFile---strFile, Specifies A CString type value.
	virtual BOOL SaveResFile(CString strFile);

	// Get item count
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Count, Returns the specified value.
	//		Returns a int type value.
	int GetItemCount();

	// first time after construct
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Data, Call InitData after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pWnd---*pWnd, A pointer to the CWnd  or NULL if the call failed.  
	//		strResFile---Resource File, Specifies A CString type value.
	virtual void InitData(CWnd *pWnd,CString strResFile = _T(""));

public:

	/*************************************************************************
	|*
	|* Below are the setting properties for the page window showing.
	|*
	\************************************************************************/

	// Obtaint the page background color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Background Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetPageBkColor() const							{ return m_crBackColor; }

	// Change the page backgroud color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Background Color, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void		SetPageBkColor(const COLORREF &crColor)			{ m_crBackColor = crColor; }

	// Get xp first color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get First Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetFirstColor() const { return m_crXPFirst; }

	// Change xp first color.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set First Color, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&cr---Specifies A 32-bit COLORREF value used as a color value.
	void		SetFirstColor(const COLORREF &cr) { m_crXPFirst = cr; }

	// Get font Face Name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Face Name, Returns the specified value.
	//		Returns a CString type value.
	CString		GetPageFaceName() const;

	// Change the font Face Name,
	// lpszFaceName -- standard font face name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Face Name, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		lpszFaceName---Face Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	void		SetPageFaceName(LPCTSTR lpszFaceName);

	// Get Point Size of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Point Size, Returns the specified value.
	//		Returns a int type value.
	int			GetPagePointSize() const;

	// Change font Point Size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Point Size, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&nPointSize---Point Size, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void		SetPagePointSize(const int &nPointSize, CDC* pDC = NULL);

	// Get Height of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Height, Returns the specified value.
	//		Returns a int type value.
	int			GetPageHeight() const;

	// Change the font Height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Height, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&nHeight---&nHeight, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void		SetPageHeight(const int &nHeight, CDC* pDC = NULL);

	// Get Font Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Font Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetPageFontColor() const;

	// Change the Font Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Font Color, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void		SetPageFontColor(const COLORREF &crColor);

	// Get Weight
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Weight, Returns the specified value.
	//		Returns a int type value.
	int			GetPageWeight() const;

	// Change the font Weight,
	// nWeight -- 700 is Bold,500 is Normal and must be nWeight >= 0 && nWeight <= 1000
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Weight, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&nWeight---&nWeight, Specifies A integer value.
	void		SetPageWeight(const int &nWeight);

	// Is It Italic
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Italic, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetPageItalic() const;

	// Change the font italic property.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Italic, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&bItalic---&bItalic, Specifies A Boolean value.
	void		SetPageItalic(const BOOL &bItalic);

	// Is It  Underline
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Underline, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetPageUnderline() const;

	// Change the font underline property.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Underline, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&bUnderline---&bUnderline, Specifies A Boolean value.
	void		SetPageUnderline(const BOOL &bUnderline);

	// Is It Strikeout
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Strikeout, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetPageStrikeout() const;

	// Change the font strikeout property.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Page Strikeout, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&bStrikeout---&bStrikeout, Specifies A Boolean value.
	void		SetPageStrikeout(const BOOL &bStrikeout);

	// Creates a GDI font object. The caller is responsible for freeing this memory!
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Page Font, You construct a CFOToolBoxPage object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CFont,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CFont*		CreatePageFont(CDC* pDC = NULL);

	
	// Returns a pointer to the cached GDI font object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Page Font, Returns the specified value.
	//		Returns a pointer to the object CFont,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CFont*		GetPageFont(CDC* pDC = NULL);

	// Releases the cached font object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Page Font Object, .

	void		ReleasePageFontObject();

public:
	
	/*************************************************************************
	|*
	|* Below are the settings for page's details.
	|*
	\************************************************************************/

	// Return Subject value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Subject, Returns the specified value.
	//		Returns a CString type value.
	CString GetSubject() const { return m_strSubject;}

	// Change Subject value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Subject, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&strValue---&strValue, Specifies A CString type value.
	void SetSubject( const CString &strValue ) {m_strSubject = strValue; }

	// Return Author value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Author, Returns the specified value.
	//		Returns a CString type value.
	CString GetAuthor() const { return m_strAuthor;}

	// Change Author value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Author, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&strValue---&strValue, Specifies A CString type value.
	void SetAuthor( const CString &strValue ) {m_strAuthor = strValue; }

	// Return Company value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Company, Returns the specified value.
	//		Returns a CString type value.
	CString GetCompany() const { return m_strCompany;}

	// Change Company value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Company, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&strValue---&strValue, Specifies A CString type value.
	void SetCompany( const CString &strValue ) {m_strCompany = strValue; }

	// Return Description value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Description, Returns the specified value.
	//		Returns a CString type value.
	CString GetDescription() const { return m_strDescription;}

	// Change Description value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Description, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&strValue---&strValue, Specifies A CString type value.
	void SetDescription( const CString &strValue ) {m_strDescription = strValue; }

public:

	// Get handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Icon, Returns the specified value.
	//		Returns A HICON value (Object).
	HICON GetIcon() const;
	
	// Set icon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Icon, Sets a specify value to current class CFOToolBoxPage
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		hIcon---hIcon, Specifies a HICON hIcon object(Value).
	virtual void SetIcon( HICON hIcon );
	
	// Set icon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Icon, Sets a specify value to current class CFOToolBoxPage
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpszRes---lpszRes, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nHeight---nHeight, Specifies A integer value.  
	//		nWidth---nWidth, Specifies A integer value.
	virtual void SetIcon( LPCTSTR lpszRes, int nHeight = 16, int nWidth = 16 );
	
	// Set icon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Icon, Sets a specify value to current class CFOToolBoxPage
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nHeight---nHeight, Specifies A integer value.  
	//		nWidth---nWidth, Specifies A integer value.
	virtual void SetIcon( UINT nID, int nHeight = 16, int nWidth = 16 );

	// get or set itme data
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Data, Returns the specified value.
	//		Returns a pointer to the object void,or NULL if the call failed
	void* GetItemData() const;

	//
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Data, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		pData---pData, A pointer to the const void or NULL if the call failed.
	void SetItemData( const void* const pData );
 
	// Re update all item's image.
	void UpdateAllImages();

	// get selected flag
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Selected, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsSelected() const;
	
	// Set selected flag.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Selected, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		bSelect---bSelect, Specifies A Boolean value.
	void SetSelected( BOOL bSelect = TRUE );
 
	// get or set flag of auto delete
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Automatic Delete, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAutoDelete() const;
	
	// Set auto delete mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Automatic Delete, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		bAuto---bAuto, Specifies A Boolean value.
	void SetAutoDelete( BOOL bAuto = TRUE );

	// Hit test.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptPoint---ptPoint, Specifies A CPoint type value.
	virtual BOOL HitTest( const CPoint& ptPoint ) const;

	// Hit test icon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test Icon, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		ptPoint---ptPoint, Specifies A CPoint type value.
	virtual BOOL HitTestIcon( const CPoint& ptPoint ) const;

	// get or set color of focus
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Focus Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF GetFocusColor() const;
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Focus Color, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		color---Specifies A 32-bit COLORREF value used as a color value.
	void SetFocusColor( COLORREF color );

	// get or set style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Style, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit long signed integer.
	virtual long GetStyle() const;
	
	// Set style.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Style, Sets a specify value to current class CFOToolBoxPage
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		sStyle---sStyle, Specifies A 32-bit long signed integer.
	virtual void SetStyle( long sStyle );


	// Get icon rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Icon Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect GetIconRect() const { return m_rcIcon; }

	// Is mouse over title bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Mouse Over, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsMouseOver() const { return m_bMouseOver; }

	// Set mouse over.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Mouse Over, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&bOver---&bOver, Specifies A Boolean value.
	void SetMouseOver(const BOOL &bOver) { m_bMouseOver = bOver; }

	// Is mouse left button clicked on the title bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Pushed, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsPushed() const { return m_bPushed; }

	// Set mouse pushed on the title bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Mouse Pushed, Sets a specify value to current class CFOToolBoxPage
	// Parameters:
	//		&bPush---&bPush, Specifies A Boolean value.
	void SetMousePushed(const BOOL &bPush) { m_bPushed = bPush; }

	// Is hmi child window mode.
	BOOL			m_bHMIChildWnd;

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serializes the data.
	virtual void Serialize(CArchive &ar);
	
	// Save document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Save Document, Call this function to save the specify data to a file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL SaveDocument(LPCTSTR lpszPathName);

	// Open document.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Open Document, Open document from specify file.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszPathName---Path Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	virtual BOOL OpenDocument(LPCTSTR lpszPathName);
	
	// Get file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get File, Returns the specified value.
	//		Returns a pointer to the object CFile ,or NULL if the call failed  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.  
	//		nOpenFlags---Open Flags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pError---pError, A pointer to the CFileException or NULL if the call failed.
	CFile *GetFile(LPCTSTR lpszFileName, UINT nOpenFlags,CFileException* pError);
	
	// Release file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release File, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.  
	//		bAbort---bAbort, Specifies A Boolean value.
	virtual void ReleaseFile(CFile* pFile, BOOL bAbort);

	void ExportToSvg(const CString &strFile);

public:

	//Draw flat status.

	// Creates GDI objects and sets up the device context for drawing. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void PrepareDC(CDC* pDC);

	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Line, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		bVert---bVert, Specifies A Boolean value.
	virtual void OnDrawLine(CDC *pDC, BOOL bVert);

	// Draws the 3D status of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		bVert---bVert, Specifies A Boolean value.
	virtual void OnDraw(CDC *pDC, BOOL bVert);

	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void ClearDC(CDC* pDC);

	// Draw button.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Button, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		bPressed---bPressed, Specifies A Boolean value.
	virtual void OnDrawButton( CDC& dc, BOOL bPressed );
	
	// Draw icon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Icon, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		bPressed---bPressed, Specifies A Boolean value.  
	//		bVert---bVert, Specifies A Boolean value.
	virtual void OnDrawIcon(   CDC& dc, BOOL bPressed, BOOL bVert );
	
	// Draw text.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Text, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		bPressed---bPressed, Specifies A Boolean value.  
	//		bVert---bVert, Specifies A Boolean value.
	virtual void OnDrawText(  CDC& dc, BOOL bPressed, BOOL bVert );

	// Compute rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Compute Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDC& dc object(Value).  
	//		bVert---bVert, Specifies A Boolean value.
	virtual void ComputeRect( CDC& dc, BOOL bVert );
protected:

	//Define for brush.

	// Creates a GDI brush object. The caller is responsible for freeing this memory! 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Brush, You construct a CFOToolBoxPage object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CBrush,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CBrush* CreateBrush(CDC* pDC = NULL);

	//Define for font.

	// Returns a pointer to the cached GDI brush object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Brush, Returns the specified value.
	//		Returns a pointer to the object CBrush,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CBrush* GetBrush(CDC* pDC = NULL);

	// Releases the cached brush object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Brush Object, .

	void ReleaseBrushObject();

	//Define for brush.
	// Creates a GDI pen object. The caller is responsible for freeing this memory! 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Pen, You construct a CFOToolBoxPage object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CPen,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CPen* CreatePen(CDC* pDC = NULL);

	// Returns a pointer to the cached GDI pen object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Pen, Returns the specified value.
	//		Returns a pointer to the object CPen,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CPen* GetPen(CDC* pDC = NULL);

	// Releases the cached pen object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Pen Object, .

	void ReleasePenObject();

	//Define for font.
	// Creates a GDI font object. The caller is responsible for freeing this memory!
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Font, You construct a CFOToolBoxPage object in two steps. First call the constructor, then call Create, which creates the object.
	//		Returns a pointer to the object CFont,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CFont* CreateFont(CDC* pDC = NULL);

	// Returns a pointer to the cached GDI font object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font, Returns the specified value.
	//		Returns a pointer to the object CFont,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CFont* GetFont(CDC* pDC = NULL);

	// Releases the cached font object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Font Object, .

	void ReleaseFontObject();

protected:
	
	// Convert point to log.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Logical Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&nPoints---&nPoints, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual int GetLogPoint(const int &nPoints, CDC* pDC = NULL, BOOL bVertical = TRUE);

	// Get point from log.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point From Logical, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&nLog---&nLog, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual int GetPointFromLog(const int &nLog, CDC* pDC = NULL, BOOL bVertical = TRUE);

	// Create validate brush.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Validate Brush, You construct a CFOToolBoxPage object in two steps. First call the constructor, then call Create, which creates the object.

	void		CreateValidateBrush();

	// Do draw gipper.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Gipper, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		rectGripper---rectGripper, Specifies A CRect type value.
	virtual void DoDrawGipper(CDC* pDC, CRect rectGripper);

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Set the properties of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Text Edit Properties, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnTextEditProperties();


protected:

	// FODO:Add your properties items below.
	// Subject value.
 
	// Subject, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString          m_strSubject;

	// Author value.
 
	// Author, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString          m_strAuthor;

	// Company value.
 
	// Company, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString          m_strCompany;

	// Description value.
 
	// Description, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString          m_strDescription;

public:

	// List of the all the toolbox items.
 
	// Item List, This member specify E-XD++ CFOToolBoxItemSet object.  
	CFOToolBoxItemSet	m_ItemList;

	// Cached GDI brush. 
 
	// Brush, The CBrush class encapsulates a Windows graphics device interface (GDI) brush.  
	CBrush*			m_pBrush;

	// The line width.
 
	// Line Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nLineWidth;

	// The line color.
 
	// Line, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crLine;
	
	// Transparent pen.
 
	// Null Pen, This member sets TRUE if it is right.  
	BOOL			m_bNullPen;

	// Pen style.
 
	// Pen Style, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nPenStyle;

	// Pen.
 
	// Pen, This member specify E-XD++ CFOPenObjData object.  
	CPen*	m_pPen;

	// The background color. 
 
	// Background Color, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crBkColor;

	// The transparent brush.
 
	// Transparent, This member sets TRUE if it is right.  
	BOOL			m_bTransparent;

	// The brush type.
 
	// Brush Type, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nBrushType;

	// The brush hatch type.
 
	// Hatch, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nHatch;

	// Hatch color.
 
	// Hatch, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crHatch;

	// Caption of Shape.
 
	// Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strCaption;

	// The name of the font. 
 
	// Face Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strFaceName;
	
	// The point size of the font. 
 
	// Point Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nPointSize;
	
	// Height of the font in logical units. 
 
	// Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nHeight;
	
	// The font color. 
 
	// Color, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crColor;
	
	// The weight of the font (normal, bold, etc.) 
 
	// Weight, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nWeight;
	
	// The italic setting of the font. 
 
	// Italic, This member sets TRUE if it is right.  
	BOOL			m_bItalic;
	
	// The underline setting of the font. 
 
	// Underline, This member sets TRUE if it is right.  
	BOOL			m_bUnderline;
	
	// The strike out setting of the font. 
 
	// Strikeout, This member sets TRUE if it is right.  
	BOOL			m_bStrikeout;

	// Define for win 9x only.
 
	// New Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont			*m_pNewFont;

	// Text alignment.
 
	// Text Horizontal Alignment, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nTextHorzAlignment;

	// Vert text alignment.
 
	// Text Vertical Alignment, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT			m_nTextVertAlignment;

	// Multi lines
 
	// Multiple Line, This member sets TRUE if it is right.  
	BOOL			m_bMultiLine;

	// Title bar position.
 
	// Title Page, This member sets a CRect value.  
	CRect			m_rectTitlePage;

	// Page client position.
 
	// Page Client, This member sets a CRect value.  
	CRect			m_rcPageClient;

	// Title bar size.
 
	// Title Page Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nTitlePageSize;

	// page client size.
 
	// Page Client Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nPageClientSize;

	// Handle icon.
 
	// Icon, This member specify HICON object.  
	HICON			m_hIcon;

	// Handle icon for showing modified flags.
 
	// Icon Modify, This member specify HICON object.  
	HICON			m_hIconModify;

	// Icon width.
 
	// Width, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_cxWidth;

	// Icon height.
 
	// Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_cyHeight;

	// 
 
	// Void, This member maintains a pointer to the object void.  
	void*			m_pVoid;

	// Is or not selected.
 
	// Selected, This member sets TRUE if it is right.  
	BOOL			m_bSelected;

	// Auto delete data.
 
	// Automatic Delete, This member sets TRUE if it is right.  
	BOOL			m_bAutoDelete;	

	// Disabled color.
 
	// Disabled, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crDisabled;

	// Focus color.
 
	// Focus, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crFocus;

	// Button style.
 
	// Button Style, Specify a A 32-bit signed integer.  
	long			m_sButtonStyle;

	// Current resource file name.
 
	// File Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_strFileName;

	// Page font.

	// The name of the font. 
 
	// Face Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString			m_pagestrFaceName;
	
	// The point size of the font. 
 
	// Point Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_pagenPointSize;
	
	// Height of the font in logical units. 
 
	// Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_pagenHeight;
	
	// The font color. 
 
	// Color, This member sets A 32-bit value used as a color value.  
	COLORREF		m_pagecrColor;
	
	// The weight of the font (normal, bold, etc.) 
 
	// Weight, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_pagenWeight;
	
	// The italic setting of the font. 
 
	// Italic, This member sets TRUE if it is right.  
	BOOL			m_pagebItalic;
	
	// The underline setting of the font. 
 
	// Underline, This member sets TRUE if it is right.  
	BOOL			m_pagebUnderline;
	
	// The strike out setting of the font. 
 
	// Strikeout, This member sets TRUE if it is right.  
	BOOL			m_pagebStrikeout;
	
	// Cached GDI font. 
 
	// Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont*			m_pagepFont;

	// Page back color
 
	// Back Color, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crBackColor;	
	
	// flag of modified.
 
	// Modified, This member sets TRUE if it is right.  
	BOOL			bModified;

	// XP mode gradient color first color.
 
	// X P First, This member sets A 32-bit value used as a color value.  
	COLORREF		m_crXPFirst;

	// Icon position.
 
	// Icon, This member sets a CRect value.  
	CRect			m_rcIcon;

	// Mouse over state.
 
	// Mouse Over, This member sets TRUE if it is right.  
	BOOL			m_bMouseOver;

	// Mouse push state.
 
	// Pushed, This member sets TRUE if it is right.  
	BOOL			m_bPushed;
	
};

////////////////////////////////////////////////////////////////////////////////
//

_FOLIB_INLINE int CFOToolBoxPage::GetBrushHatch() const
{
	return m_nHatch;
}

_FOLIB_INLINE int CFOToolBoxPage::GetBrushType() const
{
	return m_nBrushType;
}

_FOLIB_INLINE BOOL CFOToolBoxPage::GetTransparent() const
{
	return m_bTransparent;
}

_FOLIB_INLINE void CFOToolBoxPage::SetTransparent(const BOOL &bTransparent)
{
	ReleaseBrushObject();
	m_bTransparent = bTransparent;
}

_FOLIB_INLINE BOOL CFOToolBoxPage::IsNullPen() const
{
	return m_bNullPen;
}

_FOLIB_INLINE void CFOToolBoxPage::SetNullPen(const BOOL &bNull)
{
	ReleasePenObject();
	m_bNullPen = bNull;
}

_FOLIB_INLINE int CFOToolBoxPage::GetPenStyle() const
{
	return m_nPenStyle;
}

_FOLIB_INLINE	COLORREF CFOToolBoxPage::GetBkColor() const					
{ 
	return m_crBkColor; 
}

_FOLIB_INLINE	void CFOToolBoxPage::SetBkColor(const COLORREF &crBkColor)	
{	
	ReleaseBrushObject();
	m_crBkColor = crBkColor;
}

_FOLIB_INLINE	void CFOToolBoxPage::SetPatternColor(const COLORREF &cr)	
{	
	ReleaseBrushObject();
	m_crHatch = cr;
}

_FOLIB_INLINE COLORREF CFOToolBoxPage::GetPatternColor() const
{
	return m_crHatch;
}

_FOLIB_INLINE	UINT CFOToolBoxPage::GetTextHorzAlignment()	const
{ 
	return m_nTextHorzAlignment;
}

_FOLIB_INLINE void CFOToolBoxPage::SetTextHorzAlignment(const UINT &nT)	
{ 
	m_nTextHorzAlignment = nT;
}

_FOLIB_INLINE	BOOL CFOToolBoxPage::IsMultiLine() const
{
	return m_bMultiLine;
}

_FOLIB_INLINE	void CFOToolBoxPage::SetMultiLine(const BOOL &bMulti)
{
	m_bMultiLine = bMulti;
}

_FOLIB_INLINE	UINT CFOToolBoxPage::GetTextVertAlignment()	const
{ 
	return m_nTextVertAlignment;
}

_FOLIB_INLINE void CFOToolBoxPage::SetTextVertAlignment(const UINT &nT)	
{ 
	m_nTextVertAlignment = nT;
}

_FOLIB_INLINE	CString CFOToolBoxPage::GetObjectCaption() const		
{ 
	return m_strCaption; 
}

_FOLIB_INLINE	void CFOToolBoxPage::SetObjectCaption(const CString &str)	
{ 
	m_strCaption = str; 
}

_FOLIB_INLINE CString CFOToolBoxPage::GetFaceName() const
{
	return m_strFaceName;
}

_FOLIB_INLINE int CFOToolBoxPage::GetPointSize() const
{
	return m_nPointSize;
}

_FOLIB_INLINE int CFOToolBoxPage::GetHeight() const
{
	return m_nHeight;
}

_FOLIB_INLINE COLORREF CFOToolBoxPage::GetFontColor() const
{
	return m_crColor;
}

_FOLIB_INLINE int CFOToolBoxPage::GetWeight() const
{
	return m_nWeight;
}

_FOLIB_INLINE BOOL CFOToolBoxPage::GetItalic() const
{
	return m_bItalic;
}

_FOLIB_INLINE void CFOToolBoxPage::SetItalic(const BOOL &bItalic)
{
	m_bItalic = bItalic;
}

_FOLIB_INLINE BOOL CFOToolBoxPage::GetUnderline() const
{
	return m_bUnderline;
}

_FOLIB_INLINE void CFOToolBoxPage::SetUnderline(const BOOL &bUnderline)
{
	m_bUnderline = bUnderline;
}

_FOLIB_INLINE BOOL CFOToolBoxPage::GetStrikeout() const
{
	return m_bStrikeout;
}

_FOLIB_INLINE void CFOToolBoxPage::SetStrikeout(const BOOL &bStrikeout)
{
	m_bStrikeout = bStrikeout;
}

	_FOLIB_INLINE CString CFOToolBoxPage::GetPageFaceName() const
{
	return m_pagestrFaceName;
}

_FOLIB_INLINE int CFOToolBoxPage::GetPagePointSize() const
{
	return m_pagenPointSize;
}

_FOLIB_INLINE int CFOToolBoxPage::GetPageHeight() const
{
	return m_pagenHeight;
}

_FOLIB_INLINE COLORREF CFOToolBoxPage::GetPageFontColor() const
{
	return m_pagecrColor;
}

_FOLIB_INLINE int CFOToolBoxPage::GetPageWeight() const
{
	return m_pagenWeight;
}

_FOLIB_INLINE BOOL CFOToolBoxPage::GetPageItalic() const
{
	return m_pagebItalic;
}

_FOLIB_INLINE void CFOToolBoxPage::SetPageItalic(const BOOL &bItalic)
{
	m_pagebItalic = bItalic;
}

_FOLIB_INLINE BOOL CFOToolBoxPage::GetPageUnderline() const
{
	return m_pagebUnderline;
}

_FOLIB_INLINE void CFOToolBoxPage::SetPageUnderline(const BOOL &bUnderline)
{
	m_pagebUnderline = bUnderline;
}

_FOLIB_INLINE BOOL CFOToolBoxPage::GetPageStrikeout() const
{
	return m_pagebStrikeout;
}

_FOLIB_INLINE void CFOToolBoxPage::SetPageStrikeout(const BOOL &bStrikeout)
{
	m_pagebStrikeout = bStrikeout;
}
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOTOOLBOXPAGE_H__BC45D795_E140_11D5_A4B1_525400EA266C__INCLUDED_)
