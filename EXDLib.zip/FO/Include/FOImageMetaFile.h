//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOImageMetaFile.h: interface for the CFOImageMetaFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOIMAGEMETAFILE_H__5CDAC323_F388_11DD_A437_525400EA266C__INCLUDED_)
#define AFX_FOIMAGEMETAFILE_H__5CDAC323_F388_11DD_A437_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// include head file

// Placeable metafile data definitions 
typedef struct tagFOP_RECT
{
    short left;					 // left
    short top;					 // top
    short right;				 // right.
    short bottom;				 // bottom.
} FOP_RECT;

// Placeable metafile header 
typedef struct 
{
     DWORD		key;
     WORD		hmf;
     FOP_RECT	bbox;
     WORD		inch;
     DWORD		reserved;
     WORD		checksum;
} FOP_ALDUSMFHEADER;

// XAlignment types
typedef enum 
{
	XAlignNone = -1,
	XAlignDefault,
	XAlignTopLeft,
	XAlignTopCentre,
	XAlignTopRight,
	XAlignMiddleLeft,
	XAlignMiddleCentre,
	XAlignMiddleRight,
	XAlignBottomLeft,
	XAlignBottomCentre,
	XAlignBottomRight,
	XAlignStretch,
	XAlignFit,
} FOP_METAALIGNMENT;

////////////////////////////////////////////////////////////////////////////
// CFOImageMetaFile -- loading or saving meta file.
//

 
//===========================================================================
// Summary:
//     The CFOImageMetaFile class derived from CMetaFileDC
//      F O Image Meta File
//===========================================================================

class FO_EXT_CLASS CFOImageMetaFile : public CMetaFileDC 
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOImageMetaFile---F O Image Meta File, Specifies a E-XD++ CFOImageMetaFile object (Value).
	DECLARE_SERIAL(CFOImageMetaFile)
public:

	// decide if being metafile
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Metafile, Determines if the given value is correct or exist.
	// This member function is a static function.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pFile---pFile, A pointer to the CFile or NULL if the call failed.
	static BOOL  IsMetafile(CFile* pFile);

	// constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Image Meta File, Constructs a CFOImageMetaFile object.
	//		Returns A  value (Object).
	CFOImageMetaFile();

	// destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Image Meta File, Destructor of class CFOImageMetaFile
	//		Returns A  value (Object).
	~CFOImageMetaFile();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Display, .
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		r---Specifies A CRect type value.  
	//		align---Specifies a FOP_METAALIGNMENT align = XAlignDefault object(Value).
	// display
	void Display(CDC* pDC, CRect& r, FOP_METAALIGNMENT align = XAlignDefault);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Read, Call this function to read the specify data from an archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		*file---A pointer to the CFile  or NULL if the call failed.
	//read file
	BOOL Read(CFile *file);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Read, Call this function to read the specify data from an archive.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		lpszFileName---File Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	// Read from file.
	// lpszFileName -- the file name.
	BOOL Read(LPCTSTR lpszFileName);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// Parameters:
	//		archive---Specifies a CArchive& archive object(Value).
	// serialize
	void Serialize(CArchive& archive);

	// Obtain the image size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Image Size, Returns the specified value.
	//		Returns a CSize type value.
	CSize GetImageSize() const { return m_szImage; }

	// Gen the image size from the header
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Image Size, .
	// Parameters:
	//		dwIsAldus---Is Aldus, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	void GenImageSize(DWORD  dwIsAldus);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear, Remove the specify data from the list.

	// clear
	void Clear();

	// decide if being empty
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Empty, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL  IsEmpty();

	// fit picture to region
	
	//-----------------------------------------------------------------------
	// Summary:
	// Fit Picture, .
	// Parameters:
	//		r---Specifies A CRect type value.  
	//		size---Specifies A CSize type value.  
	//		align---Specifies a FOP_METAALIGNMENT align object(Value).
	void FitPicture(CRect& r, CSize& size, FOP_METAALIGNMENT align);

	// Meta header.
 
	// M F Header, This member specify FOP_ALDUSMFHEADER object.  
	FOP_ALDUSMFHEADER	m_aldusMFHeader;

	// Meta data.
 
	// This member specify HENHMETAFILE object.  
	HENHMETAFILE	m_emf;

	// 
 
	// Image, This member sets a CSize value.  
	CSize			m_szImage;
};

#endif // !defined(AFX_OFIMAGEMETAFILE_H__5CDAC323_F388_11DD_A437_525400EA266C__INCLUDED_)
