//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPSIMPLEPOLYGON_H__3FFA81CA_C4D5_488A_9DD1_E8482BD16437__INCLUDED_)
#define AFX_FOPSIMPLEPOLYGON_H__3FFA81CA_C4D5_488A_9DD1_E8482BD16437__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPSimplePolygon.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// FOPSimplePolygon object

#include "FOPCollect.h"
#include "FOPPolygon.h"

///////////////////////////////////////////////////////////////////////////
// FOPSegment -- line segment object.

 
//===========================================================================
// Summary:
//      To use a FOPSegment object, just call the constructor.
//      O P Segment
//===========================================================================

class FO_EXT_CLASS FOPSegment
{	
public:
    /// Type enum
    enum FOP_SEG_TYPE
    {
        Line = 0,
        Curve = 1
    };

    /// Default constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Segment, Constructs a FOPSegment object.
	//		Returns A  value (Object).
    FOPSegment();

    // Constructor
    // path--is a pointer to the path shape this point is used in
    // point--the position relative to the shape origin
    // m_nSegType--describing the point
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Segment, Constructs a FOPSegment object.
	//		Returns A  value (Object).  
	// Parameters:
	//		point---Specifies A integer value.  
	//		&ptEnd---&ptEnd, Specifies A integer value.  
	//		m_nSegType---Seg Type, Specifies a FOP_SEG_TYPE m_nSegType = Line object(Value).
    FOPSegment(const FOPPoint & point, const FOPPoint &ptEnd, FOP_SEG_TYPE m_nSegType = Line );

    // Copy Constructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Segment, Constructs a FOPSegment object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pathPoint---pathPoint, Specifies A integer value.
    FOPSegment( const FOPSegment & pathPoint );
  
     // Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Segment, Destructor of class FOPSegment
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
    virtual ~FOPSegment();

public:

	// Assignment operator.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPSegment& value (Object).  
	// Parameters:
	//		&rhs---Specifies a const FOPSegment &rhs object(Value).
    FOPSegment& operator=( const FOPSegment &rhs );

    // return the position relative to the shape origin
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point, Returns the specified value.
	//		Returns a int type value.
    FOPPoint GetPoint() const;

	// Obtain end point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get End Point, Returns the specified value.
	//		Returns a int type value.
	FOPPoint GetEndPoint() const { return m_ptEnd; }

    // get the control point 1
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get  Point1, Returns the specified value.
	//		Returns a int type value.
    FOPPoint GetControlPoint1() const;

    // get the second control point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get  Point2, Returns the specified value.
	//		Returns a int type value.
    FOPPoint GetControlPoint2() const;

    // alter the point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Point, Sets a specify value to current class FOPSegment
	// Parameters:
	//		point---Specifies A integer value.
    void SetPoint( const FOPPoint & point );

	// Set end point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set End Point, Sets a specify value to current class FOPSegment
	// Parameters:
	//		&ptEnd---&ptEnd, Specifies A integer value.
	void SetEndPoint(const FOPPoint &ptEnd) { m_ptEnd = ptEnd; }

    // Set the control point 1
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set  Point1, Sets a specify value to current class FOPSegment
	// Parameters:
	//		point---Specifies A integer value.
    void SetControlPoint1( const FOPPoint & point );

    // Set the control point 2
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set  Point2, Sets a specify value to current class FOPSegment
	// Parameters:
	//		point---Specifies A integer value.
    void SetControlPoint2( const FOPPoint & point );

    // Get the m_nSegType of a point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Seg Type, Returns the specified value.
	//		Returns A FOP_SEG_TYPE value (Object).
    FOP_SEG_TYPE GetSegType() const { return m_nSegType; }

    // Set the m_nSegType of a point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Seg Type, Sets a specify value to current class FOPSegment
	// Parameters:
	//		nSegType---Seg Type, Specifies a FOP_SEG_TYPE nSegType object(Value).
    void SetSegType( FOP_SEG_TYPE nSegType );
  
protected:
	// Vector point
 
	// Vector, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPPoint m_ptVector;

	// control point 1
 
	// Point1, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    FOPPoint controlPoint1;

	// Control point 2
 
	// Point2, This variable specifies a 32-bit signed integer on 32-bit platforms.  
    FOPPoint controlPoint2;

	// End point
 
	// End, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPPoint m_ptEnd;

	// Segment type.
 
	// Seg Type, This member specify FOP_SEG_TYPE object.  
    FOP_SEG_TYPE m_nSegType;
};

//////////////////////////////////////////////////////////
// FOPSimplePolygonData -- simple polygon data.

 
//===========================================================================
// Summary:
//     The FOPSimplePolygonData class derived from CObject
//      O P Simple Polygon Data
//===========================================================================

class FO_EXT_CLASS FOPSimplePolygonData : public CObject
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		FOPSimplePolygonData---O P Simple Polygon Data, Specifies a FOPSimplePolygonData object(Value).
	DECLARE_SERIAL(FOPSimplePolygonData);

public:
	// Points of array
 
	// Point Array, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPPoint*		m_aPointAry;

	// Flags of array
 
	// Flag Array, This member maintains a pointer to the object BYTE.  
	BYTE*			m_aFlagAry;

	// Points of old array
 
	// Old Point Array, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPPoint*		m_aOldPointAry;

	// Delete old point
 
	// Delete Old, This member sets TRUE if it is right.  
	BOOL			m_bDeleteOld;

	// Current size.
 
	// Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nSize;

	// Resize
 
	// Resize, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nResize;

	// Points of count
 
	// Points, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nPoints;

	// Reference count.
 
	// Reference Count, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nRefCount;

public:

	// Constructor.
	// nSize -- normal size
	// nResize -- resize size
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Simple Polygon Data, Constructs a FOPSimplePolygonData object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nSize---nSize, Specifies A integer value.  
	//		nResize---nResize, Specifies A integer value.
	FOPSimplePolygonData(int nSize = 16, int nResize = 16);

	// Constructor.
	// aData -- target data object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Simple Polygon Data, Constructs a FOPSimplePolygonData object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aData---aData, Specifies a const FOPSimplePolygonData& aData object(Value).
	FOPSimplePolygonData(const FOPSimplePolygonData& aData);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Simple Polygon Data, Destructor of class FOPSimplePolygonData
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPSimplePolygonData();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data to file.
	virtual void Serialize(CArchive &ar);

	// Operator == .
	// aData -- target compare data object
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aData---aData, Specifies a const FOPSimplePolygonData& aData object(Value).
	BOOL operator==(const FOPSimplePolygonData& aData) const;

	// Operator != .
	// aData -- target compare data object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aData---aData, Specifies a const FOPSimplePolygonData& aData object(Value).
	BOOL operator!=(const FOPSimplePolygonData& aData) const	{	return !operator == (aData);	}

	// Check point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Check Point Delete, .

	void CheckPointDelete();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Resize, .
	// Parameters:
	//		nNewSize---New Size, Specifies A integer value.  
	//		bDelete---bDelete, Specifies A Boolean value.
	// Resize the data to new size.
	// nNewSize -- new size of points.
	// bDelete -- delete the exist points
	void Resize(int nNewSize, BOOL bDelete = TRUE);

	// Insert space.
	// nPos -- position to be inserted.
	// nCount -- total space to be inserted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Resize Space, .
	// Parameters:
	//		nPos---nPos, Specifies A integer value.  
	//		nCount---nCount, Specifies A integer value.
	void ResizeSpace(int nPos, int nCount);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		nPos---nPos, Specifies A integer value.  
	//		nCount---nCount, Specifies A integer value.
	// Remove point.
	// nPos -- position to be removed.
	// nCount -- total space to be removed.
	void Remove(int nPos, int nCount);

	
public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

};

class FOPSimplePolygon;
FOP_DECLARE_LIST(FOPSimplePolygonList, FOPSimplePolygon*);

/////////////////////////////////////////////////////////////////////////////
// FOPSimpleCompositePolygonData -- simple composite polygon data.

 
//===========================================================================
// Summary:
//     The FOPSimpleCompositePolygonData class derived from CObject
//      O P Simple Composite Polygon Data
//===========================================================================

class FO_EXT_CLASS FOPSimpleCompositePolygonData : public CObject
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		FOPSimpleCompositePolygonData---O P Simple Composite Polygon Data, Specifies a FOPSimpleCompositePolygonData object(Value).
	DECLARE_SERIAL(FOPSimpleCompositePolygonData);

public:
	// List of polygons.
 
	// Sim Polygon List, This member specify FOPSimplePolygonList object.  
	FOPSimplePolygonList aSimPolyList;

	// Reference count.
 
	// Reference Count, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nRefCount;

public:
	// Constructor.
	// nSize -- normal size.
	// nResize -- resize size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Simple Composite Polygon Data, Constructs a FOPSimpleCompositePolygonData object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nSize---nSize, Specifies A integer value.  
	//		nResize---nResize, Specifies A integer value.
	FOPSimpleCompositePolygonData(int nSize = 16, int nResize = 16);

	// Constructor.
	// aDataPoly -- target data object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Simple Composite Polygon Data, Constructs a FOPSimpleCompositePolygonData object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aDataPoly---Data Polygon, Specifies a const FOPSimpleCompositePolygonData& aDataPoly object(Value).
	FOPSimpleCompositePolygonData(const FOPSimpleCompositePolygonData& aDataPoly);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Simple Composite Polygon Data, Destructor of class FOPSimpleCompositePolygonData
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPSimpleCompositePolygonData();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data to file.
	virtual void Serialize(CArchive &ar);

	// Operator ==.
	// aDataPoly -- target compare object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aDataPoly---Data Polygon, Specifies a const FOPSimpleCompositePolygonData& aDataPoly object(Value).
	BOOL operator==(const FOPSimpleCompositePolygonData& aDataPoly) const;

	// Operator !=.
	// aDataPoly -- target compare object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aDataPoly---Data Polygon, Specifies a const FOPSimpleCompositePolygonData& aDataPoly object(Value).
	BOOL operator!=(const FOPSimpleCompositePolygonData& aDataPoly) const	
	{	return !operator == (aDataPoly);	}

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

};

// FOPSimplePolyFlags
enum FOPSimplePolyFlags
{
	FOP_SIM_POLY_NORMAL,
	FOP_SIM_POLY_SMOOTH,
	FOP_SIM_POLY_CONTROL,
	FOP_SIM_POLY_SYMMTR
};

/////////////////////////////////////////////////////////////////////////////
// FOPSimplePolygon -- simple polygon.

class FOPSimplePolygonData;
 
//===========================================================================
// Summary:
//     The FOPSimplePolygon class derived from CObject
//      O P Simple Polygon
//===========================================================================

class FO_EXT_CLASS FOPSimplePolygon : public CObject
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		FOPSimplePolygon---O P Simple Polygon, Specifies a FOPSimplePolygon object(Value).
	DECLARE_SERIAL(FOPSimplePolygon);

protected:
	
	// Pointer of polygon data.
 
	// Sim Polygon Data, This member maintains a pointer to the object FOPSimplePolygonData.  
	FOPSimplePolygonData* m_pSimPolygonData;

	// Check reference.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Correct Reference Count, .

	void CorrectRefCount();

	// Divide bezier
	// nPos -- divide index
	// bCalcFirst -- calculate at first or not.
	// dT -- divide value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Subdivide Bezier, .
	// Parameters:
	//		nPos---nPos, Specifies A integer value.  
	//		bCalcFirst---Calculate First, Specifies A Boolean value.  
	//		dT---dT, Specifies a double dT object(Value).
	void SubdivideBezier(int nPos, BOOL bCalcFirst, double dT);

	// Generate bezier arc
	// ptCenter -- Center point.
	// nRx -- x radius.
	// nRy -- y radius.
	// nXHdl -- x handle.
	// nYHdl -- y handle.
	// nStart -- start angle.
	// nEnd -- end angle.
	// nQuad -- quad
	// nFirst -- first
	
	//-----------------------------------------------------------------------
	// Summary:
	// Generate Bez Arc, .
	// Parameters:
	//		ptCenter---ptCenter, Specifies A integer value.  
	//		nRx---nRx, Specifies A 32-bit long signed integer.  
	//		nRy---nRy, Specifies A 32-bit long signed integer.  
	//		nXHdl---X Handle, Specifies A 32-bit long signed integer.  
	//		nYHdl---Y Handle, Specifies A 32-bit long signed integer.  
	//		nStart---nStart, Specifies A integer value.  
	//		nEnd---nEnd, Specifies A integer value.  
	//		nQuad---nQuad, Specifies A integer value.  
	//		nFirst---nFirst, Specifies A integer value.
	void GenBezArc(const FOPPoint& ptCenter, long nRx, long nRy, 
		long nXHdl, long nYHdl, int nStart, 
		int nEnd, int nQuad, int nFirst);

	// Check angles
	
	//-----------------------------------------------------------------------
	// Summary:
	// Check Angles, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nStart---nStart, Specifies A integer value.  
	//		nEnd---nEnd, Specifies A integer value.  
	//		nA1---nA1, Specifies A integer value.  
	//		nA2---nA2, Specifies A integer value.
	BOOL CheckAngles(int& nStart, int nEnd, int& nA1, int& nA2);

public:

	// Constructor.
	// nSize -- normal size.
	// nResize -- resize size
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Simple Polygon, Constructs a FOPSimplePolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		&ptMoveTo---Move To, Specifies A integer value.
	FOPSimplePolygon(const FOPPoint &ptMoveTo);

	// Constructor.
	// nSize -- normal size.
	// nResize -- resize size
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Simple Polygon, Constructs a FOPSimplePolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nSize---nSize, Specifies A integer value.  
	//		nResize---nResize, Specifies A integer value.
	FOPSimplePolygon(int nSize = 16, int nResize = 16);

	// Constructor.
	// aSimPoly -- target object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Simple Polygon, Constructs a FOPSimplePolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aSimPoly---Sim Polygon, Specifies a const FOPSimplePolygon& aSimPoly object(Value).
	FOPSimplePolygon(const FOPSimplePolygon& aSimPoly);

	// Constructor.
	// aPoly -- target object
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Simple Polygon, Constructs a FOPSimplePolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aPoly---aPoly, Specifies a const FOPPolygon& aPoly object(Value).
	FOPSimplePolygon(const FOPPolygon& aPoly);

	// Constructor,create round rectangle.
	// rcRect -- bounding rectangle.
	// nRx -- x value of radius.
	// nRy -- y value of radius.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Simple Polygon, Constructs a FOPSimplePolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		rcRect---rcRect, Specifies a const FOPRect& rcRect object(Value).  
	//		nRx---nRx, Specifies A 32-bit long signed integer.  
	//		nRy---nRy, Specifies A 32-bit long signed integer.
	FOPSimplePolygon(const FOPRect& rcRect, long nRx = 0, long nRy = 0);

	// Constructor,create ellipse shape with three points.
	// ptLineStart -- start point of the line.
	// ptLineEnd -- end point of the line.
	// ptAnchor -- anchor point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Simple Polygon, Constructs a FOPSimplePolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ptLineStart---Line Start, Specifies A CPoint type value.  
	//		&ptLineEnd---Line End, Specifies A CPoint type value.  
	//		&ptAnchor---&ptAnchor, Specifies A CPoint type value.
	FOPSimplePolygon(const CPoint& ptLineStart, const CPoint &ptLineEnd, const CPoint &ptAnchor);

	// Constructor.
	// lpPoints -- points.
	// nCount -- count of points.
	// bTotalBezier -- all are beziers or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Simple Polygon, Constructs a FOPSimplePolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		lpPoints---lpPoints, Specifies A LPPOINT Points array.  
	//		&nCount---&nCount, Specifies A integer value.  
	//		&bTotalBezier---Total Bezier, Specifies A Boolean value.
	FOPSimplePolygon(LPPOINT lpPoints, const int &nCount,const BOOL &bTotalBezier = TRUE, const BOOL &bClose = TRUE);

	// Constructor.
	// mpPoints -- points.
	// bClose -- is close or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Simple Polygon, Constructs a FOPSimplePolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		&mpPoints---&mpPoints, Specifies A CPoint type value.  
	//		&bClose---&bClose, Specifies A Boolean value.
	FOPSimplePolygon(const CArray<CPoint, CPoint> &mpPoints, const BOOL &bClose = FALSE);

	// Constructor
	// rcRect -- rectangle.
	// lpPoints -- points.
	// aFlagAry -- flags.
	// nCount -- count.
	// bClose -- close or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Simple Polygon, Constructs a FOPSimplePolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		rcRect---rcRect, Specifies a const FOPRect& rcRect object(Value).  
	//		lpPoints---lpPoints, Specifies A LPPOINT Points array.  
	//		aFlagAry---Flag Array, A pointer to the BYTE or NULL if the call failed.  
	//		&nCount---&nCount, Specifies A integer value.  
	//		&bClose---&bClose, Specifies A Boolean value.
	FOPSimplePolygon(const FOPRect& rcRect,LPPOINT lpPoints,BYTE* aFlagAry,const int &nCount,const BOOL &bClose = TRUE);

	// Constructor
	// lpPoints -- points.
	// aFlagAry -- point's flags.
	// nCount -- count of points.
	// bClose -- close or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Simple Polygon, Constructs a FOPSimplePolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		lpPoints---lpPoints, Specifies A LPPOINT Points array.  
	//		aFlagAry---Flag Array, A pointer to the BYTE or NULL if the call failed.  
	//		&nCount---&nCount, Specifies A integer value.  
	//		&bClose---&bClose, Specifies A Boolean value.
	FOPSimplePolygon(LPPOINT lpPoints,BYTE* aFlagAry,const int &nCount,const BOOL &bClose = TRUE);

	// Constructor
	// rcRect -- bounding rectangle.
	// lpPoints -- points.
	// nCount -- count of points.
	// bTotalBezier -- all are beziers or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Simple Polygon, Constructs a FOPSimplePolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		rcRect---rcRect, Specifies a const FOPRect& rcRect object(Value).  
	//		lpPoints---lpPoints, Specifies A LPPOINT Points array.  
	//		&nCount---&nCount, Specifies A integer value.  
	//		&bTotalBezier---Total Bezier, Specifies A Boolean value.
	FOPSimplePolygon(const FOPRect& rcRect,LPPOINT lpPoints, const int &nCount,const BOOL &bTotalBezier = TRUE);

	// Constructor,create round rectangle callout shape
	// rcRect -- bounding rectangle.
	// ptTail -- tail point
	// nRx -- x value of radius.
	// nRy -- y value of radius.
	// bRound -- round rectangle or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Simple Polygon, Constructs a FOPSimplePolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		rcRect---rcRect, Specifies a const FOPRect& rcRect object(Value).  
	//		&ptTail---&ptTail, Specifies A CPoint type value.  
	//		nRx---nRx, Specifies A 32-bit long signed integer.  
	//		nRy---nRy, Specifies A 32-bit long signed integer.  
	//		&bRound---&bRound, Specifies A Boolean value.
	FOPSimplePolygon(const FOPRect& rcRect,const CPoint &ptTail,long nRx = 0, long nRy = 0,const BOOL &bRound = TRUE);

	// Constructor,create arc.
	// ptCenter -- center point.
	// nRx -- x value of radius.
	// nRy -- y value of radius.
	// nStartAngle -- start angle value from 0 - 36000 Yes
	// nEndAngle -- end angle value from 0 - 36000 Yes
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Simple Polygon, Constructs a FOPSimplePolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		ptCenter---ptCenter, Specifies A integer value.  
	//		nRx---nRx, Specifies A 32-bit long signed integer.  
	//		nRy---nRy, Specifies A 32-bit long signed integer.  
	//		nStartAngle---Start Angle, Specifies A integer value.  
	//		nEndAngle---End Angle, Specifies A integer value.  
	//		bClose---bClose, Specifies A Boolean value.
	FOPSimplePolygon(const FOPPoint& ptCenter, long nRx, long nRy, int nStartAngle = 0, int nEndAngle = 3600, 
		BOOL bClose = TRUE);

	// Constructor, create arc.
	FOPSimplePolygon(const FOPSplineGeometry& spline);

	// Constructor, create arc.
	FOPSimplePolygon(const FOPComplexGeometry& geometry);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Simple Polygon, Destructor of class FOPSimplePolygon
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPSimplePolygon();

	// add a arc.
    int ConvertArcToCurve( double rx, double ry, double startAngle, 
		double sweepAngle, const FOPFloat & ptStart, FOPFloat * curvePoints ) const;

	void ConvertArc2(const FOPFloat& ptCenter, long nRx, long nRy, int nRingWidth, int nStartAngle = 0, int nEndAngle = 3600);
public:

	// Get point array.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Get Point Array, Do a event. 
	//		Returns a int type value.
    FOPPoint*           DoGetPointAry();

	// Get flag array.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Get Flag Array, Do a event. 
	//		Returns a pointer to the object BYTE,or NULL if the call failed
    BYTE*               DoGetFlagAry();

	// Check style.
	BOOL CheckStyle();

	// Obtain the points of the polygon
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Const Point Array, Returns the specified value.
	//		Returns a int type value.
	const FOPPoint*     GetConstPointAry() const;

	// Obtain the flags of the polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Const Flag Array, Returns the specified value.
	//		Returns a pointer to the object const BYTE,or NULL if the call failed
    const BYTE*         GetConstFlagAry() const;

	// Set
	void SetPointAndFlag(LPPOINT lpPoints,BYTE* aFlagAry,const int &nCount);

	// Generate GDI path flags.
	int GenGDIPts(LPPOINT &pptOut,LPBYTE &byteOut, BOOL &bLineOnly);

	//-----------------------------------------------------------------------
	// Summary:
	// Close, .
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	// Close the polygon.
	// nPos -- close index.
	void Close(const int& nPos);

	// Get valid segment of points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Segment, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&poly---Specifies a FOPSegment &poly object(Value).  
	//		&nPoint---&nPoint, Specifies A integer value.
	BOOL GetSegment(FOPSegment &poly, const int &nPoint);

	// Hit test on polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		&nHitPoint---Hit Point, Specifies A integer value.  
	//		nHitBorder---Hit Border, Specifies A integer value.
	BOOL HitTest(const CPoint &ptHit, int &nHitPoint, int nHitBorder);

	// Hit test on polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		&nHitPoint---Hit Point, Specifies A integer value.  
	//		nHitBorder---Hit Border, Specifies A integer value.
	BOOL HitTestRect(FOPRect &rcHit, CFOPathShape *pPath, int nPoly, CFOPMarkList &arPoints);

	//-----------------------------------------------------------------------
	// Summary:
	// Clear, Remove the specify data from the list.

	// Clear.
	void Clear();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data to file.
	virtual void Serialize(CArchive &ar);

	// Serialize data to file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize2, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void Serialize2(CArchive &ar);

	// Change size.
	// nSize -- new size of points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Size, Sets a specify value to current class FOPSimplePolygon
	// Parameters:
	//		nSize---nSize, Specifies A integer value.
	void SetSize(int nSize);

	// Get size.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Size, Returns the specified value.
	//		Returns a int type value.
	int GetSize() const;

	// Change point count.
	// nPoints -- new count of points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Point Count, Sets a specify value to current class FOPSimplePolygon
	// Parameters:
	//		nPoints---nPoints, Specifies A integer value.
	void SetPointCount(int nPoints);

	// Get point count.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point Count, Returns the specified value.
	//		Returns a int type value.
	int GetPointCount() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert, Inserts a child object at the given index..
	// Parameters:
	//		nPos---nPos, Specifies A integer value.  
	//		ptPt---ptPt, Specifies A integer value.  
	//		eFlags---eFlags, Specifies a FOPSimplePolyFlags eFlags object(Value).
	// Insert a specify point.
	// nPos -- position to be inserted.
	// ptPt -- insert point value.
	// eFlags -- polygon flag
	void Insert(int nPos, const FOPPoint& ptPt, FOPSimplePolyFlags eFlags);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert, Inserts a child object at the given index..
	// Parameters:
	//		nPos---nPos, Specifies A integer value.  
	//		aSimPoly---Sim Polygon, Specifies a const FOPSimplePolygon& aSimPoly object(Value).
	// Insert a specify polygon.
	// nPos -- position to be inserted.
	// aSimPoly -- polygon to be inserted.
	void Insert(int nPos, const FOPSimplePolygon& aSimPoly);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert, Inserts a child object at the given index..
	// Parameters:
	//		nPos---nPos, Specifies A integer value.  
	//		aPoly---aPoly, Specifies a const FOPPolygon& aPoly object(Value).
	// Insert a specify polygon.
	// nPos -- position to be inserted.
	// aPoly -- polygon to be inserted.
	void Insert(int nPos, const FOPPolygon& aPoly);


	// Obtain the length of all points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Length, Returns the specified value.
	//		Returns a int type value.
	long GetTotalLength() const;

	// Obtain point at specify percent.
	// fPercent -- from 0.0 to 1.0
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point At Percent, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		fPercent---fPercent, Specifies A float value.
	FOPPoint GetPointAtPercent(float fPercent) const;

	// Obtain angle at percent
	// fPercent -- percent value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Angle At Percent, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		fPercent---fPercent, Specifies A float value.
	int GetAngleAtPercent(const FOPPoint &pt0, const FOPPoint &pt1, const FOPPoint &pt2, const FOPPoint &pt3, float fPercent, long nTotal) const;

	// Obtain slope at percent.
	// fPercent -- percent value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Slope At Percent, Returns the specified value.
	//		Returns a float value.  
	// Parameters:
	//		fPercent---fPercent, Specifies A float value.
	float GetSlopeAtPercent(float fPercent) const;

public:
	/////////////////////////////////////////////////////////////////////////
	// The following codes are all done with FOPSimplePolygon(const FOPPoint &ptMoveTo);
	// Line to a new point.

	// Move to first point or move first point to a new position.
	// pt -- first point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move First To, .
	// Parameters:
	//		&pt---Specifies A integer value.
	void MoveFirstTo(const FOPPoint &pt);
	
	// Line to a new point.
	// pt -- point that lined to.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Line To, .
	// Parameters:
	//		&p---Specifies A integer value.
	void LineTo(const FOPPoint &p);

	// Line to a new point.
	// pt -- point that lined to.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Line To, .
	// Parameters:
	//		&p---Specifies A integer value.
	void LineTo(const int &x, const int & y) { LineTo(CPoint(x,y)); }

	// Bezier to.
	// control1 -- first control point.
	// control2 -- second control point
	// end -- end point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Bezier To, .
	// Parameters:
	//		&control1---Specifies A integer value.  
	//		&control2---Specifies A integer value.  
	//		&end---Specifies A integer value.
	void BezierTo(const FOPPoint &control1, const FOPPoint &control2, const FOPPoint &end);

	// New bezier to.
	// ctrlPt1x ctrlPt1y -- first control point.
	// ctrlPt2x ctrlPt2y -- second control point
	// endPtx endPty -- end point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Bezier To, .
	// Parameters:
	//		ctrlPt1x---ctrlPt1x, Specifies A integer value.  
	//		ctrlPt1y---ctrlPt1y, Specifies A integer value.  
	//		ctrlPt2x---ctrlPt2x, Specifies A integer value.  
	//		ctrlPt2y---ctrlPt2y, Specifies A integer value.  
	//		endPtx---endPtx, Specifies A integer value.  
	//		endPty---endPty, Specifies A integer value.
	inline void BezierTo(int ctrlPt1x, int ctrlPt1y, int ctrlPt2x, int ctrlPt2y,
                        int endPtx, int endPty);

	// Quad to.
	// control -- control point
	// end -- end point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Quad To, .
	// Parameters:
	//		&control---Specifies A integer value.  
	//		&end---Specifies A integer value.
	void QuadTo(const FOPPoint &control, const FOPPoint &end);

	// New quad to
	// ctrlPtx ctrlPty -- control point
	// endPtx endPty -- end point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Quad To, .
	// Parameters:
	//		ctrlPtx---ctrlPtx, Specifies A integer value.  
	//		ctrlPty---ctrlPty, Specifies A integer value.  
	//		endPtx---endPtx, Specifies A integer value.  
	//		endPty---endPty, Specifies A integer value.
	inline void QuadTo(int ctrlPtx, int ctrlPty, int endPtx, int endPty);

	// Arc to, start angle and sweep length is based -180-180
	// rect -- rectangle.
	// startAngle -- start angle
	// sweepLength -- sweep angle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Arc To, .
	// Parameters:
	//		&rect---Specifies a const FOPRect &rect object(Value).  
	//		startAngle---startAngle, Specifies A integer value.  
	//		sweepLength---sweepLength, Specifies A integer value.
	void ArcTo(const FOPRect &rect, int startAngle, int sweepLength);

	// New arc to, start angle and sweep length is based -180 -180
	// x -- start point x
	// y -- start point y
	// w -- width
	// h -- height
	// startAngle -- start angle.
	// arcLength -- length of angle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Arc To, .
	// Parameters:
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		w---Specifies A integer value.  
	//		h---Specifies A integer value.  
	//		startAngle---startAngle, Specifies A integer value.  
	//		arcLength---arcLength, Specifies A integer value.
	void ArcTo(int x, int y, int w, int h, int startAngle, int arcLength);

	// New arc to
	// rx -- x radius
	// ry -- y radius
	// startAngle -- start angle
	// sweepAngle -- sweep angle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Arc To, .
	// Parameters:
	//		rx---Specifies a double rx object(Value).  
	//		ry---Specifies a double ry object(Value).  
	//		startAngle---startAngle, Specifies a double startAngle object(Value).  
	//		sweepAngle---sweepAngle, Specifies a double sweepAngle object(Value).
	void ArcTo( double rx, double ry, double startAngle, double sweepAngle );

	// Arc to.
	// center -- center point of arc segment line.
	// end -- end point of arc segment line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Arc To, .
	// Parameters:
	//		&center---Specifies A integer value.  
	//		&end---Specifies A integer value.
	void ArcTo(const FOPPoint &center, const FOPPoint &end);

	// Creates an arc from its start point, endpoint and bulge.
	// end -- end point of arc segment.
	// dBulge -- bulge length.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Arc To, .
	// Parameters:
	//		&end---Specifies A integer value.  
	//		&dBulge---&dBulge, Specifies a const double &dBulge object(Value).
	void ArcTo(const FOPPoint &end, const double &dBulge);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Close, .

	// Close the polygon.
	void Close();

	// Is path closed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Closed, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsClosed();

	//////////////////////////////////////////////////////////////////////////////////
	
	//-----------------------------------------------------------------------
	// Summary:
	// Parse Path Svg, .
	// Parameters:
	//		&s---Specifies A CString type value.  
	//		process---Specifies A Boolean value.
	void ParsePathSvg( const CString &s, bool process );

	
	//-----------------------------------------------------------------------
	// Summary:
	// Parse GDI+ Path, .
	void ParsePath( POINT* lppt, BYTE* pTypes, int nCount, const BOOL &bClose = FALSE);

	//-----------------------------------------------------------------------
	// Summary:
	// Parse GDI Path, .
	void ParseGDIPath( POINT* lppt, BYTE* pTypes, int nCount, const BOOL &bClose = FALSE);

	// parse polygon svg data.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Parse Polygon Svg, .
	// Parameters:
	//		&s---Specifies A CString type value.  
	//		&bClose---&bClose, Specifies A Boolean value.
	void ParsePolygonSvg( const CString &s, const BOOL &bClose = TRUE);

	// Is flag support or not.
	BOOL IsFlagSupport() const;

public:

	// Connect a line.
	// ptLineStart -- start point of line.
	// ptLineEnd -- end point of line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Connect Line, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptLineStart---Line Start, Specifies A integer value.  
	//		&ptLineEnd---Line End, Specifies A integer value.
	BOOL ConnectLine(const FOPPoint &ptLineStart,const FOPPoint &ptLineEnd);

	// Connect a lines.
	// pptPoints -- points
	// nCount -- count of points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Connect Lines, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pptPoints---pptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	BOOL ConnectLines(LPPOINT pptPoints, int nCount);

	// Connect a lines.
	// ptArray -- points array.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Connect Lines, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		ptArray---ptArray, A pointer to the CPoint> or NULL if the call failed.
	BOOL ConnectLines(CArray<CPoint,CPoint>* ptArray);

	// Connect a new bezier or arc,etc.
	// poly -- polygon object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Connect Polygon, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&poly---Specifies a const FOPSimplePolygon &poly object(Value).
	BOOL ConnectPolygon(const FOPSimplePolygon &poly);

	// .Connect the bezier line shape from points.
	// pptPoints -- points of shape border.
	// nCount -- total of points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Connect Bezier Line, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		mptPoints---mptPoints, Specifies A LPPOINT Points array.  
	//		nCount---nCount, Specifies A integer value.
	BOOL ConnectBezierLine(LPPOINT mptPoints, int nCount);

	// .Connect the bezier line from points.
	// ptArray -- array of points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Connect Bezier Line, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		CArray<CPoint---Array< C Point, Specifies A CArray array.  
	//		ptArray---ptArray, A pointer to the CPoint> or NULL if the call failed.
	BOOL ConnectBezierLine(CArray<CPoint,CPoint>* ptArray);

	// Connect arc line
	// ptStart -- start point.
	// ptEnd -- end point
	// nWidth -- width
	
	//-----------------------------------------------------------------------
	// Summary:
	// Connect Arc Line, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.  
	//		nWidth---nWidth, Specifies A 32-bit long signed integer.
	BOOL ConnectArcLine(const CPoint &ptStart,const CPoint &ptEnd,long nWidth);

	// Connect arc extend line
	// rcPos -- position of arc.
	// ptStart -- start point of arc line.
	// ptEnd -- end point of arc line
	
	//-----------------------------------------------------------------------
	// Summary:
	// Connect Arc2 Line, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.
	BOOL ConnectArc2Line(const CRect &rcPos,const CPoint &ptStart,const CPoint &ptEnd);

	// Is close possible.
	// ptStart -- start point for checking
	// ptEnd -- end point for checking.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Close Possible, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptStart---&ptStart, Specifies A CPoint type value.  
	//		&ptEnd---&ptEnd, Specifies A CPoint type value.
	BOOL IsClosePossible(const CPoint &ptStart,const CPoint &ptEnd);

	// Is connect possible.
	// ptHit -- hit point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Connect Possible, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.
	BOOL IsConnectPossible(const CPoint &ptHit);

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove, Call this function to remove a specify value from the specify object.
	// Parameters:
	//		nPos---nPos, Specifies A integer value.  
	//		nCount---nCount, Specifies A integer value.
	// Remove point.
	// nPos -- start position to be removed.
	// nCount -- total points to be removed.
	void Remove(int nPos, int nCount);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Move, .
	// Parameters:
	//		xOffset---xOffset, Specifies A 32-bit long signed integer.  
	//		yOffset---yOffset, Specifies A 32-bit long signed integer.
	// Move
	// xOffset -- offset x value.
	// yOffset -- offset y value.
	void Move(long xOffset, long yOffset);

	// Obtain the bounding rectangle of the polygon
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bound Rectangle, Returns the specified value.
	//		Returns A FOPRect value (Object).
	FOPRect GetBoundRect() const;

	// Draw path text.
	void DrawPathText(CDC *pDC, const CString &strText);

	// Draw
	// pDC -- pointer of DC
	
	//-----------------------------------------------------------------------
	// Summary:
	// Build G D I Path, .
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.
	void BuildGDIPath(CDC *pDC);

	// Change point.
	// nPos - change point index of the polygon.
	// pt -- new point value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Change Point, .
	// Parameters:
	//		nPos---nPos, Specifies A integer value.  
	//		&pt---Specifies A integer value.
	void ChangePoint(int nPos,const FOPPoint &pt);

	// Operator []
	// nPos -- index of the point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	const FOPPoint& operator[](int nPos) const;

	// Operator []
	// nPos -- index of the point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns a int type value.  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	FOPPoint& operator[](int nPos);

	// Operator =
	// aSimPoly -- data object that to be used for copying data from.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPSimplePolygon& value (Object).  
	// Parameters:
	//		aSimPoly---Sim Polygon, Specifies a const FOPSimplePolygon& aSimPoly object(Value).
	FOPSimplePolygon& operator=(const FOPSimplePolygon& aSimPoly);

	// Operator ==
	// aSimPoly -- target compare object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aSimPoly---Sim Polygon, Specifies a const FOPSimplePolygon& aSimPoly object(Value).
	BOOL operator==(const FOPSimplePolygon& aSimPoly) const;

	// Is clock wise or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Clockwise, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsClockwise();

	// Operator !=
	// aSimPoly -- target compare object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aSimPoly---Sim Polygon, Specifies a const FOPSimplePolygon& aSimPoly object(Value).
	BOOL operator!=(const FOPSimplePolygon& aSimPoly) const;

	// Add arc to polygon
	// rRect -- rectangle of this arc.
	// rStart -- start point
	// rEnd -- end point
	// bClockwise -- clock wise
	// rPoly -- poly object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Append Arc, .
	// Parameters:
	//		rRect---rRect, Specifies a const FOPRect& rRect object(Value).  
	//		rStart---rStart, Specifies A integer value.  
	//		rEnd---rEnd, Specifies A integer value.  
	//		bClockwise---bClockwise, Specifies A Boolean value.  
	//		rPoly---rPoly, Specifies a FOPSimplePolygon& rPoly object(Value).
	void AppendArc( const FOPRect& rRect, const FOPPoint& rStart, const FOPPoint& rEnd, 
		const BOOL bClockwise, FOPSimplePolygon& rPoly );

	// for N-Polygons
	// rcBound -- bounding rectangle.
	// nPtCount -- vector point.
	// bInner -- innner or not.
	// factor -- from -1.0 to 1.0
	void RegularPolygon(FOPRect &rcBound, int nPtCount, BOOL bInner, double factor, double dAngle = 0, double factor2 = 0);

	// Append a three points circle to the polygon.
	// pt1 -- first point of this circle.
	// pt2 -- the second point of this circle.
	// pt3 -- the third point of this circle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Append Circle, .
	// Parameters:
	//		pt1---Specifies A integer value.  
	//		pt2---Specifies A integer value.  
	//		pt3---Specifies A integer value.
	void AppendCircle(const FOPPoint& pt1, const FOPPoint& pt2, const FOPPoint& pt3);

	// Get poly flags.
	// nPos -- index of point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Polygon Flags, Returns the specified value.
	//		Returns A FOPSimplePolyFlags value (Object).  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	FOPSimplePolyFlags GetPolyFlags(int nPos) const;

	// Change polygon flags.
	// nPos -- index of point.
	// eFlags -- new flag
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Polygon Flags, Sets a specify value to current class FOPSimplePolygon
	// Parameters:
	//		nPos---nPos, Specifies A integer value.  
	//		eFlags---eFlags, Specifies a FOPSimplePolyFlags eFlags object(Value).
	void SetPolyFlags(int nPos, FOPSimplePolyFlags eFlags);

	// Is control
	// nPos -- index of point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is , Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	BOOL IsControl(int nPos) const;

	// Is smooth
	// nPos -- index of point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Smooth, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	BOOL IsSmooth(int nPos) const;

	// calculate distance of two points.
	// nP1 -- start position to calculate.
	// nP2 -- end position to calculate.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Distance, .
	//		Returns A double value (Object).  
	// Parameters:
	//		nP1---nP1, Specifies A integer value.  
	//		nP2---nP2, Specifies A integer value.
	double CalcDistance(int nP1, int nP2);

	// Helpful methods.
	// nCenter -- join center point index.
	// nDrag -- index of point that dragged.
	// nPnt -- current point index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Smooth Join, .
	// Parameters:
	//		nCenter---nCenter, Specifies A integer value.  
	//		nDrag---nDrag, Specifies A integer value.  
	//		nPnt---nPnt, Specifies A integer value.
	void CalcSmoothJoin(int nCenter, int nDrag, int nPnt);

	// calculate tangent.
	// nCenter -- join center point index.
	// nPrev -- index of previous point.
	// nNext -- index of next point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Tangent, .
	// Parameters:
	//		nCenter---nCenter, Specifies A integer value.  
	//		nPrev---nPrev, Specifies A integer value.  
	//		nNext---nNext, Specifies A integer value.
	void CalcTangent(int nCenter, int nPrev, int nNext);

	// Convert points to bezier.
	// nFirst -- the first point index that to be converted.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Points To Bezier, .
	// Parameters:
	//		nFirst---nFirst, Specifies A integer value.
	void PointsToBezier(int nFirst);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Translate, .
	// Parameters:
	//		ptOffset---ptOffset, Specifies A integer value.
	// Translate.
	// ptOffset -- translate point.
	void Translate(const FOPPoint& ptOffset);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate, .
	// Parameters:
	//		ptCenter---ptCenter, Specifies A integer value.  
	//		dSin---dSin, Specifies a double dSin object(Value).  
	//		dCos---dCos, Specifies a double dCos object(Value).
	// Rotate polygon.
	// ptCenter -- rotating center.
	// dSin -- sin angle value.
	// dCos -- cos angle value.
	void Rotate(const FOPPoint& ptCenter, double dSin, double dCos);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate, .
	// Parameters:
	//		ptCenter---ptCenter, Specifies A integer value.  
	//		nAngle---nAngle, Specifies A integer value.
	// Rotate polygon.
	// ptCenter -- rotating center
	// nAngle -- 0 - 3600 angle value.
	void Rotate(const FOPPoint& ptCenter, int nAngle);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale, .
	// Parameters:
	//		dSx---dSx, Specifies a double dSx object(Value).  
	//		dSy---dSy, Specifies a double dSy object(Value).
	// Scale polygon.
	// dSx -- horizontal scale value.
	// dSy -- vertical scale value.
	void Scale(double dSx, double dSy);

	// Slant x.
	// nYRef -- y reference value.
	// dSin -- sin angle value.
	// dCos -- cos angle value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Slant X, .
	// Parameters:
	//		nYRef---Y Reference, Specifies A 32-bit long signed integer.  
	//		dSin---dSin, Specifies a double dSin object(Value).  
	//		dCos---dCos, Specifies a double dCos object(Value).
	void SlantX(long nYRef, double dSin, double dCos);

	// Slant y
	// nXRef -- x reference value.
	// dSin -- sin angle value.
	// dCos -- cos angle value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Slant Y, .
	// Parameters:
	//		nXRef---X Reference, Specifies A 32-bit long signed integer.  
	//		dSin---dSin, Specifies a double dSin object(Value).  
	//		dCos---dCos, Specifies a double dCos object(Value).
	void SlantY(long nXRef, double dSin, double dCos);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Distort, .
	// Parameters:
	//		rcRefRect---Reference Rectangle, Specifies a const FOPRect& rcRefRect object(Value).  
	//		rDistortedRect---Distorted Rectangle, Specifies a const FOPSimplePolygon& rDistortedRect object(Value).
	// Distort polygon.
	// rcRef -- reference rectangle.
	// aDistorted -- distort rectangle.
	void Distort(const FOPRect& rcRefRect, const FOPSimplePolygon& rDistortedRect);

	// Rotate Small.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Small, .

	void RotateSmall();

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Arc, .
	// Parameters:
	//		relative---Specifies A Boolean value.  
	//		&curx---Specifies a double &curx object(Value).  
	//		&cury---Specifies a double &cury object(Value).  
	//		angle---Specifies a double angle object(Value).  
	//		x---Specifies a double x object(Value).  
	//		y---Specifies a double y object(Value).  
	//		r1---Specifies a double r1 object(Value).  
	//		r2---Specifies a double r2 object(Value).  
	//		largeArcFlag---Arc Flag, Specifies A Boolean value.  
	//		sweepFlag---sweepFlag, Specifies A Boolean value.
	void CalculateArc( bool relative, double &curx, double &cury, double angle, double x, double y, double r1, double r2, bool largeArcFlag, bool sweepFlag );
	
	// Path start point.
 
	// Position Start, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	FOPPoint m_ptPositionStart;
};

inline void FOPSimplePolygon::BezierTo(int ctrlPt1x, int ctrlPt1y, int ctrlPt2x, int ctrlPt2y,
                                   int endPtx, int endPty)
{
    BezierTo(FOPPoint(ctrlPt1x, ctrlPt1y), FOPPoint(ctrlPt2x, ctrlPt2y),
            FOPPoint(endPtx, endPty));
}

inline void FOPSimplePolygon::QuadTo(int ctrlPtx, int ctrlPty, int endPtx, int endPty)
{
    QuadTo(FOPPoint(ctrlPtx, ctrlPty), FOPPoint(endPtx, endPty));
}

inline void FOPSimplePolygon::ArcTo(int x, int y, int w, int h, int startAngle, int arcLenght)
{
    ArcTo(FOPRect(x, y, w, h), startAngle, arcLenght);
}

/////////////////////////////////////////////////////////////////////////////
// FOPSimpleCompositePolygon,this class is defined for grouping a list of multiple polygons.
//

class FOPSimpleCompositePolygonData;
 
//===========================================================================
// Summary:
//     The FOPSimpleCompositePolygon class derived from CObject
//      O P Simple Composite Polygon
//===========================================================================

class FO_EXT_CLASS FOPSimpleCompositePolygon : public CObject
{
protected:
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ S E R I A L, .
	//		Returns A  value (Object).  
	// Parameters:
	//		FOPSimpleCompositePolygon---O P Simple Composite Polygon, Specifies a FOPSimpleCompositePolygon object(Value).
	DECLARE_SERIAL(FOPSimpleCompositePolygon);

protected:
	// Pointer of polypolygon data.
 
	// Sim Polygon Polygon Data, This member maintains a pointer to the object FOPSimpleCompositePolygonData.  
	FOPSimpleCompositePolygonData* pSimPolyPolygonData;

	// Check reference.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Correct Reference Count, .

	void CorrectRefCount();

public:

	// Constructor.
	// nInitSize -- init size
	// nResize -- resize value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Simple Composite Polygon, Constructs a FOPSimpleCompositePolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		nInitSize---Initial Size, Specifies A integer value.  
	//		nResize---nResize, Specifies A integer value.
	FOPSimpleCompositePolygon(int nInitSize = 16, int nResize = 16);

	// Constructor.
	// aSimPoly -- target polygon object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Simple Composite Polygon, Constructs a FOPSimpleCompositePolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aSimPoly---Sim Polygon, Specifies a const FOPSimplePolygon& aSimPoly object(Value).
	FOPSimpleCompositePolygon(const FOPSimplePolygon& aSimPoly);

	// Constructor.
	// aSimCompPoly -- target simple composite polygon object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Simple Composite Polygon, Constructs a FOPSimpleCompositePolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aSimCompPoly---Sim Component Polygon, Specifies a const FOPSimpleCompositePolygon& aSimCompPoly object(Value).
	FOPSimpleCompositePolygon(const FOPSimpleCompositePolygon& aSimCompPoly);

	// Constructor.
	// aCompPoly -- target composite polygon object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// O P Simple Composite Polygon, Constructs a FOPSimpleCompositePolygon object.
	//		Returns A  value (Object).  
	// Parameters:
	//		aCompPoly---Component Polygon, Specifies a const FOPPolyPolygon& aCompPoly object(Value).
	FOPSimpleCompositePolygon(const FOPPolyPolygon& aCompPoly);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Simple Composite Polygon, Destructor of class FOPSimpleCompositePolygon
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~FOPSimpleCompositePolygon();

public:
	/////////////////////////////////////////////////////////////////////////
	
	//-----------------------------------------------------------------------
	// Summary:
	// Move To, .
	// Parameters:
	//		&pt---Specifies A integer value.
	// The following codes are all done with FOPSimplePolygon(const FOPPoint &ptMoveTo);
	// Line to a new point.

	// Move to first point or move first point to a new position.
	// pt -- first point.
	void MoveTo(const FOPPoint &pt);

	// Line to a new point.
	// pt -- point that lined to.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Line To, .
	// Parameters:
	//		&pt---Specifies A integer value.
	void LineTo(const FOPPoint &pt);

	// Bezier to.
	// control1 -- first control point.
	// control2 -- second control point
	// end -- end point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Bezier To, .
	// Parameters:
	//		&control1---Specifies A integer value.  
	//		&control2---Specifies A integer value.  
	//		&end---Specifies A integer value.
	void BezierTo(const FOPPoint &control1, const FOPPoint &control2, const FOPPoint &end);

	// Quad to.
	// control -- control point
	// end -- end point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Quad To, .
	// Parameters:
	//		&control---Specifies A integer value.  
	//		&end---Specifies A integer value.
	void QuadTo(const FOPPoint &control, const FOPPoint &end);

	// Arc to, start angle and sweep length is based -180-180
	// rect -- rectangle.
	// startAngle -- start angle
	// sweepLength -- sweep angle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Arc To, .
	// Parameters:
	//		&rect---Specifies a const FOPRect &rect object(Value).  
	//		startAngle---startAngle, Specifies A integer value.  
	//		sweepLength---sweepLength, Specifies A integer value.
	void ArcTo(const FOPRect &rect, int startAngle, int sweepLength);

	// New arc to, start angle and sweep length is based -180 -180
	// x -- start point x
	// y -- start point y
	// w -- width
	// h -- height
	// startAngle -- start angle.
	// arcLength -- length of angle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Arc To, .
	// Parameters:
	//		x---Specifies A integer value.  
	//		y---Specifies A integer value.  
	//		w---Specifies A integer value.  
	//		h---Specifies A integer value.  
	//		startAngle---startAngle, Specifies A integer value.  
	//		arcLength---arcLength, Specifies A integer value.
	void ArcTo(int x, int y, int w, int h, int startAngle, int arcLength);

	// New arc to
	// rx -- x radius
	// ry -- y radius
	// startAngle -- start angle
	// sweepAngle -- sweep angle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Arc To, .
	// Parameters:
	//		rx---Specifies a double rx object(Value).  
	//		ry---Specifies a double ry object(Value).  
	//		startAngle---startAngle, Specifies a double startAngle object(Value).  
	//		sweepAngle---sweepAngle, Specifies a double sweepAngle object(Value).
	void ArcTo( double rx, double ry, double startAngle, double sweepAngle );

	// Arc to.
	// center -- center point of arc segment line.
	// end -- end point of arc segment line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Arc To, .
	// Parameters:
	//		&center---Specifies A integer value.  
	//		&end---Specifies A integer value.
	void ArcTo(const FOPPoint &center, const FOPPoint &end);

	// Creates an arc from its start point, endpoint and bulge.
	// end -- end point of arc segment.
	// dBulge -- bulge length.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Arc To, .
	// Parameters:
	//		&end---Specifies A integer value.  
	//		&dBulge---&dBulge, Specifies a const double &dBulge object(Value).
	void ArcTo(const FOPPoint &end, const double &dBulge);

	// Close the polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Close Child Path, .

	void CloseSubPath();

public:
	// Add simple polygon.
	// lpPoints -- points for adding.
	// aFlagAry -- flags of polygon.
	// nCount -- count of points.
	// bClose -- close or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Simple, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		lpPoints---lpPoints, Specifies A LPPOINT Points array.  
	//		aFlagAry---Flag Array, A pointer to the BYTE or NULL if the call failed.  
	//		&nCount---&nCount, Specifies A integer value.  
	//		&bClose---&bClose, Specifies A Boolean value.
	virtual void AddSimple(LPPOINT lpPoints,BYTE* aFlagAry,const int &nCount,const BOOL &bClose = TRUE);

	// Add Line.
	// ptStart -- start point of line.
	// ptEnd -- end point of line.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Line, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ptStart---&ptStart, Specifies A integer value.  
	//		&ptEnd---&ptEnd, Specifies A integer value.
	virtual void AddLine(const FOPPoint &ptStart,const FOPPoint &ptEnd);

	// Add lines.
	// points -- points of lines.
	// count -- count of points.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Lines, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		points---A pointer to the const FOPPoint or NULL if the call failed.  
	//		count---Specifies A integer value.
	virtual void AddLines(const FOPPoint* points,int count);

	// Add polygon to area.
	// points -- points of polygon.
	// count -- count of points
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Polygon, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		points---A pointer to the const FOPPoint or NULL if the call failed.  
	//		count---Specifies A integer value.
	virtual void AddPolygon(const FOPPoint* points,int count);

	// Add Arc area.
	// ptCenter -- center of arc bounding rectangle.
	// nRx -- x radius.
	// nRy -- y radius.
	// nStartAngle -- start angle
	// nEndAngle -- end angle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Arc, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptCenter---ptCenter, Specifies A integer value.  
	//		nRx---nRx, Specifies A 32-bit long signed integer.  
	//		nRy---nRy, Specifies A 32-bit long signed integer.  
	//		nStartAngle---Start Angle, Specifies A integer value.  
	//		nEndAngle---End Angle, Specifies A integer value.
	virtual void AddArc(const FOPPoint& ptCenter, long nRx, long nRy, int nStartAngle = 0, int nEndAngle = 3600);

	// Add pie area.
	// ptCenter -- center of pie bounding rectangle.
	// nRx -- x radius.
	// nRy -- y radius.
	// nStartAngle -- start angle
	// nEndAngle -- end angle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Pie, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		ptCenter---ptCenter, Specifies A integer value.  
	//		nRx---nRx, Specifies A 32-bit long signed integer.  
	//		nRy---nRy, Specifies A 32-bit long signed integer.  
	//		nStartAngle---Start Angle, Specifies A integer value.  
	//		nEndAngle---End Angle, Specifies A integer value.
	virtual void AddPie(const FOPPoint& ptCenter, long nRx, long nRy, int nStartAngle = 0, int nEndAngle = 3600);

	// Add Arc area.
	// rcPos -- arc bounding rectangle.
	// nStartAngle -- start angle
	// nEndAngle -- end angle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Arc, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		nStartAngle---Start Angle, Specifies A integer value.  
	//		nEndAngle---End Angle, Specifies A integer value.
	virtual void AddArc(const CRect &rcPos, int nStartAngle = 0, int nEndAngle = 3600);

	// Add pie area.
	// rcPos -- pie bounding rectangle.
	// nStartAngle -- start angle
	// nEndAngle -- end angle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Pie, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&rcPos---&rcPos, Specifies A CRect type value.  
	//		nStartAngle---Start Angle, Specifies A integer value.  
	//		nEndAngle---End Angle, Specifies A integer value.
	virtual void AddPie(const CRect &rcPos, int nStartAngle = 0, int nEndAngle = 3600);

	// Add Bezier area.
	// pt1 -- first point of bezier.
	// pt2 -- second point of bezier.
	// pt3 -- third point of bezier
	// pt4 -- four point of bezier.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Bezier, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pt1---Specifies A integer value.  
	//		pt2---Specifies A integer value.  
	//		pt3---Specifies A integer value.  
	//		pt4---Specifies A integer value.
	virtual void AddBezier(const FOPPoint& pt1,const FOPPoint& pt2,const FOPPoint& pt3,const FOPPoint& pt4);

	// Add Beizers
	// points -- points of beziers
	// count -- count of points
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Beziers, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		points---A pointer to the const FOPPoint or NULL if the call failed.  
	//		count---Specifies A integer value.
	virtual void AddBeziers(const FOPPoint* points,int count);

	// Add rectangle to area
	// rect -- rectangle for adding
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Rectangle, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rect---Specifies A CRect type value.
	virtual void AddRect(const CRect& rect);

	// Add rectangles to area
	// rects -- rectangles for adding
	// count -- count of rectangles.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Rects, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rects---A pointer to the const FOPRect or NULL if the call failed.  
	//		count---Specifies A integer value.
	virtual void AddRects(const FOPRect* rects, int count);

	// Add ellipse to area
	// rect -- rectangle for ellipse.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Ellipse, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rect---Specifies a const FOPRect& rect object(Value).
	virtual void AddEllipse(const FOPRect& rect);

	// Add round rectangle to polygon
	// rect -- rectangle for round rectangle.
	// nRx -- x radius
	// nRy -- y radius.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Round Rectangle, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rect---Specifies a const FOPRect& rect object(Value).  
	//		nRx---nRx, Specifies A 32-bit long signed integer.  
	//		nRy---nRy, Specifies A 32-bit long signed integer.
	virtual void AddRoundRect(const FOPRect& rect, long nRx = 0, long nRy = 0);

	// Hit test on polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&ptHit---&ptHit, Specifies A CPoint type value.  
	//		&nPoly---&nPoly, Specifies A integer value.  
	//		&nHitPoint---Hit Point, Specifies A integer value.  
	//		nHitBorder---Hit Border, Specifies A integer value.
	BOOL HitTest(const CPoint &ptHit, int &nPoly, int &nHitPoint, int nHitBorder);

public:

	// Obtain points count.
	int GetPointCountExt();

	// Obtain all points.
	void GetPoints(CArray<CPoint, CPoint> *m_Points);

	//-----------------------------------------------------------------------
	// Summary:
	// Serialize, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	// Serialize data to file.
	virtual void Serialize(CArchive &ar);

	// Serialize data to file.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Serialize2, Reads or writes this object from or to an archive.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&ar---Specifies a CArchive &ar object(Value).
	virtual void Serialize2(CArchive &ar);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert, Inserts a child object at the given index..
	// Parameters:
	//		aSimPoly---Sim Polygon, Specifies a const FOPSimplePolygon& aSimPoly object(Value).  
	//		nPos---nPos, Specifies A integer value.
	// Insert new polygon.
	// aSimPoly -- insert polygon value.
	// nPos -- insert at position.
	void Insert(const FOPSimplePolygon& aSimPoly, int nPos = 0xFFFF);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Insert, Inserts a child object at the given index..
	// Parameters:
	//		aSimPoly---Sim Polygon, Specifies a const FOPSimpleCompositePolygon& aSimPoly object(Value).  
	//		nPos---nPos, Specifies A integer value.
	// Insert new polypolygon.
	// aSimPoly -- insert polygons.
	// nPos -- insert at position
	void Insert(const FOPSimpleCompositePolygon& aSimPoly, int nPos = 0xFFFF);

	// Get valid segment of points.
	// poly -- polygon index that find.
	// nPoly -- polygon index for searching
	// nPoint -- point index for searching
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Segment, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		&poly---Specifies a FOPSegment &poly object(Value).  
	//		&nPoly---&nPoly, Specifies A integer value.  
	//		&nPoint---&nPoint, Specifies A integer value.
	BOOL GetSegment(FOPSegment &poly, const int &nPoly, const int &nPoint);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove, Call this function to remove a specify value from the specify object.
	//		Returns A FOPSimplePolygon value (Object).  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	// Remove polygon.
	// nPos -- remove at position.
	FOPSimplePolygon Remove(int nPos);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Replace, .
	//		Returns A FOPSimplePolygon value (Object).  
	// Parameters:
	//		aSimPoly---Sim Polygon, Specifies a const FOPSimplePolygon& aSimPoly object(Value).  
	//		nPos---nPos, Specifies A integer value.
	// Replace specify polygon.
	// aSimPoly -- replace polygon value.
	// nPos -- replaced position
	FOPSimplePolygon Replace(const FOPSimplePolygon& aSimPoly, int nPos);

	// Get specify polygon.
	// nPos -- position to find.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Object, Returns the specified value.
	//		Returns A const FOPSimplePolygon& value (Object).  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	const FOPSimplePolygon& GetObject(int nPos) const;

	// Get last polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Last, Returns the specified value.
	//		Returns a pointer to the object FOPSimplePolygon ,or NULL if the call failed
	FOPSimplePolygon *GetLast();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear, Remove the specify data from the list.

	// Clear all the data.
	void Clear();

	
	//-----------------------------------------------------------------------
	// Summary:
	// Count, .
	//		Returns a int type value.
	// Count of polygon.
	int Count() const;

	
	//-----------------------------------------------------------------------
	// Summary:
	// Move, .
	// Parameters:
	//		xOffset---xOffset, Specifies A 32-bit long signed integer.  
	//		yOffset---yOffset, Specifies A 32-bit long signed integer.
	// Move specify position.
	// xOffset -- offset x value.
	// yOffset -- offset y value.
	void Move(long xOffset, long yOffset);

	// Get bound rectangle of the composite polygon.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Bound Rectangle, Returns the specified value.
	//		Returns A FOPRect value (Object).
	FOPRect GetBoundRect() const;

	// Operator [].
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A const FOPSimplePolygon& value (Object).  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	const FOPSimplePolygon& operator[](int nPos) const	{	return GetObject(nPos);	}

	// Operator []
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPSimplePolygon& value (Object).  
	// Parameters:
	//		nPos---nPos, Specifies A integer value.
	FOPSimplePolygon& operator[](int nPos);

	// Operator =
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns A FOPSimpleCompositePolygon& value (Object).  
	// Parameters:
	//		aSimCompPoly---Sim Component Polygon, Specifies a const FOPSimpleCompositePolygon& aSimCompPoly object(Value).
	FOPSimpleCompositePolygon& operator=(const FOPSimpleCompositePolygon& aSimCompPoly);

	// Operator ==
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aSimCompPoly---Sim Component Polygon, Specifies a const FOPSimpleCompositePolygon& aSimCompPoly object(Value).
	BOOL operator==(const FOPSimpleCompositePolygon& aSimCompPoly) const;

	// Operator !=
	
	//-----------------------------------------------------------------------
	// Summary:
	// .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		aSimCompPoly---Sim Component Polygon, Specifies a const FOPSimpleCompositePolygon& aSimCompPoly object(Value).
	BOOL operator!=(const FOPSimpleCompositePolygon& aSimCompPoly) const;

	// Limit all points to a specify rectangle.
	// rcRect -- rectangle for limit.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Limit To Rectangle, .
	// Parameters:
	//		rcRect---rcRect, Specifies a const FOPRect& rcRect object(Value).
	void LimitToRect(const FOPRect& rcRect);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Translate, .
	// Parameters:
	//		ptOffset---ptOffset, Specifies A integer value.
	// Translate
	// ptOffset -- translate point.
	void Translate(const FOPPoint& ptOffset);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate, .
	// Parameters:
	//		ptCenter---ptCenter, Specifies A integer value.  
	//		dSin---dSin, Specifies a double dSin object(Value).  
	//		dCos---dCos, Specifies a double dCos object(Value).
	// Rotate
	// ptCenter -- rotating center.
	// dSin -- sin angle value.
	// dCos -- cos angle value.
	void Rotate(const FOPPoint& ptCenter, double dSin, double dCos);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate, .
	// Parameters:
	//		ptCenter---ptCenter, Specifies A integer value.  
	//		nAngle---nAngle, Specifies A integer value.
	// Rotate
	// ptCenter -- rotating center
	// nAngle -- 0 - 3600 angle value.
	void Rotate(const FOPPoint& ptCenter, int nAngle);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Scale, .
	// Parameters:
	//		dSx---dSx, Specifies a double dSx object(Value).  
	//		dSy---dSy, Specifies a double dSy object(Value).
	// Scale
	// dSx -- horizontal scale value.
	// dSy -- vertical scale value.
	void Scale(double dSx, double dSy);

	// Slant x.
	// nYRef -- y reference value.
	// dSin -- sin angle value.
	// dCos -- cos angle value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Slant X, .
	// Parameters:
	//		nYRef---Y Reference, Specifies A 32-bit long signed integer.  
	//		dSin---dSin, Specifies a double dSin object(Value).  
	//		dCos---dCos, Specifies a double dCos object(Value).
	void SlantX(long nYRef, double dSin, double dCos);

	// Slant y
	// nXRef -- x reference value.
	// dSin -- sin angle value.
	// dCos -- cos angle value.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Slant Y, .
	// Parameters:
	//		nXRef---X Reference, Specifies A 32-bit long signed integer.  
	//		dSin---dSin, Specifies a double dSin object(Value).  
	//		dCos---dCos, Specifies a double dCos object(Value).
	void SlantY(long nXRef, double dSin, double dCos);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Distort, .
	// Parameters:
	//		rcRef---rcRef, Specifies a const FOPRect& rcRef object(Value).  
	//		rDistorted---rDistorted, Specifies a const FOPSimplePolygon& rDistorted object(Value).
	// Distort.
	// rcRef -- reference rectangle.
	// aDistorted -- distort rectangle.
	void Distort(const FOPRect& rcRef, const FOPSimplePolygon& rDistorted);

	// Rotate small.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Rotate Small, .

	void RotateSmall();

	// Obtain all the points within a specify rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Points Within Rectangle, Returns the specified value.
	// Parameters:
	//		CArray<FOPPoint---Array< F O P Point, Specifies A CArray array.  
	//		&arPoints---&arPoints, Specifies A integer value.  
	//		&rc---Specifies a const FOPRect &rc object(Value).
	void GetPointsWithinRect(CArray<CPoint,CPoint> &arPoints, const FOPRect &rc );


	// Obtain all the points within a specify rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Points Within Rectangle, Returns the specified value.
	// Parameters:
	//		CFOPMarkList, Specifies A array.  
	//		&arPoints---&arPoints, Specifies A integer value.  
	//		&rc---Specifies a const FOPRect &rc object(Value).
	void GetMarksInRect(CFOPMarkList &arPoints, FOPRect &rc, CFOPathShape *pPath);

	// Obtain path string.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Path String, Returns the specified value.
	//		Returns a CString type value.  
	// Parameters:
	//		bLine---bLine, Specifies A Boolean value.
	CString	GetPathString(BOOL bLine );

	// Is all path closed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is All Closed, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllClosed();

	// Is all path closed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is All Opened, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllOpened();

	// Is all path closed.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is All Same, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsAllSame();

	// Is path line.
	BOOL IsPath();

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
	
};

/////////////////////////////////////////////////////////////////////////////
FO_API_DECL FOPPolygon AFX_API FOPCreatePolygon(const FOPSimplePolygon& aPoly,CDC *pDC,int nRough = 0);

/////////////////////////////////////////////////////////////////////////////
FO_API_DECL int AFX_API FOPGetIndexPolygon(const FOPSimplePolygon& aPoly,int &nInit,const int &nInput);

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPSIMPLEPOLYGON_H__3FFA81CA_C4D5_488A_9DD1_E8482BD16437__INCLUDED_)
