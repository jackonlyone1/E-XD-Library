//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOFILLEFFECTDLG_H__052BC6A3_FF1A_11D5_A509_525400EA266C__INCLUDED_)
#define AFX_FOFILLEFFECTDLG_H__052BC6A3_FF1A_11D5_A509_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOFillEffectDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOFillEffectDlg dialog
#include "FOPropertySheetCtrl.h"
#include "FOFillEffectPage0.h"
#include "FOFillEffectPage1.h"
#include "FOFillEffectPage2.h"
#include "FOFillSampleButton.h"
#include "FOImageButton.h"

#include "FOAngleWnd.h"
#include "FOAngleEditBox.h"
class CFOPropertySheetCtrl;
 
//===========================================================================
// Summary:
//     The CFOFillEffectDlg class derived from CDialog
//      F O Fill Effect Dialog
//===========================================================================

class FO_EXT_CLASS CFOFillEffectDlg : public CDialog
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Fill Effect Dialog, Constructs a CFOFillEffectDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFOFillEffectDlg(CWnd* pParent = NULL);   // standard constructor

	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Fill Effect Dialog, Destructor of class CFOFillEffectDlg
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOFillEffectDlg ();
// Dialog Data
	//{{AFX_DATA(CFOFillEffectDlg)
	enum { IDD = IDD_FO_FILL_DLG };
 
	// Slider Red, This member specify CSliderCtrl object.  
	CSliderCtrl	m_SliderRed;
 
	// Red, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nRed;
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

public:

 
	// Property Sheet, This member maintains a pointer to the object CFOPropertySheetCtrl.  
	CFOPropertySheetCtrl* m_pPropSheet;
 
	// Sheet0, This member maintains a pointer to the object CFOFillEffectPage0.  
	CFOFillEffectPage0* m_pSheet0;
 
	// Sheet1, This member maintains a pointer to the object CFOFillEffectPage1.  
	CFOFillEffectPage1* m_pSheet1;
 
	// Sheet2, This member maintains a pointer to the object CFOFillEffectPage2.  
	CFOFillEffectPage2* m_pSheet2;
 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

public:
	// Do end dialog.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On End Dialog, This member function is called by the framework to allow your application to handle a Windows message.

	void OnEndDialog();

	FOPGradient aGradient;

public:

 
	// Red Old, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nRedOld;

	// 
 
	// Not Show, This member sets TRUE if it is right.  
	BOOL m_bNotShow;

	// 
	BOOL m_bHideAllColor;

	// Color select button.
 
	// Fill Sample, This member specify E-XD++ CFOFillSampleButton object.  
	CFOFillSampleButton		m_btnFillSample;	

	// Pattern color.
 
	// F G, This member sets A 32-bit value used as a color value.  
	COLORREF m_crFG;

	// Background color.
 
	// B K, This member sets A 32-bit value used as a color value.  
	COLORREF m_crBK;

	//Brush Type
 
	// Brush Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nBrushType;


	// Pattern color.
 
	// Old F G, This member sets A 32-bit value used as a color value.  
	COLORREF m_crOldFG;

	// Background color.
 
	// Old B K, This member sets A 32-bit value used as a color value.  
	COLORREF m_crOldBK;

	//Brush Type
 
	// Old Brush Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nOldBrushType;

	// Modify flag.
 
	// Modify, This member sets TRUE if it is right.  
	BOOL	m_bModify;

	//
 
	// Is Axis Up, This member sets TRUE if it is right.  
	BOOL	m_bIsAxisUp;


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOFillEffectDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOFillEffectDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Activate, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.
	afx_msg BOOL OnNcActivate(BOOL bActive);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Fo Browse File, This member function is called by the framework to allow your application to handle a Windows message.
	
	afx_msg void OnFoBrowseFile();
	
	afx_msg void OnButtonHelp();
//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On H Scroll Slider, Called when the user clicks the horizontal scroll bar of CWnd.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnHScrollSlider(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CFOPGradientDlg dialog

class FO_EXT_CLASS CFOPGradientDlg : public CDialog
{
// Construction
public:
	CFOPGradientDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFOPGradientDlg)
	enum { IDD = IDD_FO_GRADIENT_SETDLG };
	// Angle, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int			m_nAngle;
	// Slider Red, This member specify CSliderCtrl object.  
	CSliderCtrl	m_SliderRed;
	
	// Slider Green, This member specify CSliderCtrl object.  
	CSliderCtrl	m_SliderGreen;
	// Slider Bright, This member specify CSliderCtrl object.  
	CSliderCtrl	m_SliderBright;
 
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

	// Angle Edit, This member specify E-XD++ CFOAngleEditBox object.  
	CFOAngleEditBox m_AngleEdit;
	
	// Angle , This member specify E-XD++ CFOAngleWnd object.  
	CFOAngleWnd		m_AngleCtrl;
	// Green, This variable specifies a 32-bit signed integer on 32-bit platforms.  

	int		m_nGreen;
	
	// Red, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nRed;

	// Bright, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nBright;
 
	// Saved green value
	
	// Old Green, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nOldGreen;
	
	// Saved red value.
	
	// Old Red, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nOldRed;
	// Saved bright value
	
	// Old Bright, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int		m_nOldBright;

	FOPGradient aGradient;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPGradientDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	// Color select button.
	
	// Fill Sample, This member specify E-XD++ CFOFillSampleButton object.  
	CFOFillSampleButton		m_btnFillSample;	
	// Pattern color.
	public:
	// F G, This member sets A 32-bit value used as a color value.  
	COLORREF m_crFG;
	
	// Background color.
	
	// B K, This member sets A 32-bit value used as a color value.  
	COLORREF m_crBK;
	
	//Brush Type
	
	// Brush Type, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int m_nBrushType;

	void UpdateGradient();

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOPGradientDlg)
	virtual BOOL OnInitDialog();
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.
	
	afx_msg void OnButtonHelp();
	//-----------------------------------------------------------------------
	// Summary:
	// On Releasedcapture Fo Image Bright, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg void OnReleasedcaptureFoImageBright(NMHDR* pNMHDR, LRESULT* pResult);

	//-----------------------------------------------------------------------
	// Summary:
	// On Releasedcapture Fo Image Green, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg void OnReleasedcaptureFoImageGreen(NMHDR* pNMHDR, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Releasedcapture Fo Image Red, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNMHDR---N M H D R, A pointer to the NMHDR or NULL if the call failed.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	afx_msg void OnReleasedcaptureFoImageRed(NMHDR* pNMHDR, LRESULT* pResult);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On O K, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnOK();
	afx_msg void OnSelchangeListStyle();
	afx_msg void OnDblclkFoListStyle();
	//}}AFX_MSG
	//-----------------------------------------------------------------------
	// Summary:
	// On H Scroll Slider, Called when the user clicks the horizontal scroll bar of CWnd.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnHScrollSlider(WPARAM wParam, LPARAM lParam);

	//-----------------------------------------------------------------------
	// Summary:
	// On H Scroll Slider, Called when the user clicks the horizontal scroll bar of CWnd.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnxAngle(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOFILLEFFECTDLG_H__052BC6A3_FF1A_11D5_A509_525400EA266C__INCLUDED_)
