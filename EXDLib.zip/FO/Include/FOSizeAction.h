//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOSizeAction.h: interface for the CFOSizeAction class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOSIZEACTION_H__5D3EDD14_F259_11DD_A433_525400EA266C__INCLUDED_)
#define AFX_FOSIZEACTION_H__5D3EDD14_F259_11DD_A433_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOActionMacro.h"

///////////////////////////////////////////////////////////////////
// Shape Sizement type.
// Define for CFOSizeShape
///////////////////////////////////////////////////////////////////
enum SizementFlag
{
	SizeNone,			// Size none.
	SizeHor,			// Make the width as the same size. <--->
	SizeVer,			// Make the height as the same size.
	SizeAll				// Make all size as the same.
};

///////////////////////////////////////////////////////////////////////////////////
// CFOSizeAction -- action that make size of selection shapes.

 
//===========================================================================
// Summary:
//     The CFOSizeAction class derived from CFOActionMacro
//      F O Size Action
//===========================================================================

class FO_EXT_CLASS CFOSizeAction : public CFOActionMacro
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOSizeAction---F O Size Action, Specifies a E-XD++ CFOSizeAction object (Value).
	DECLARE_ACTION(CFOSizeAction)

public:

	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Size Action, Constructs a CFOSizeAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.
	CFOSizeAction(CFODataModel* pModel);
	// Attributes

	// The Sizement type used to reposition shapes. 
 
	// Sizement, This member specify SizementFlag object.  
	SizementFlag m_nSizement;

	// Get the main shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Main Shape, Returns the specified value.
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	CFODrawShape *GetMainShape();

	// Set the main shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Main Shape, Sets a specify value to current class CFOSizeAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetMainShape(CFODrawShape *pShape);

	// Find the correct action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Scale Action, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	CFOBaseAction *FindScaleAction(CFODrawShape *pShape);

	// Get max position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

// Overrides
public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetUndoAction() const;

	// Return a copy of this action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetRedoAction() const;

	// Get the name of the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual void Sprint(CString& strLabel) const;

public:

	// Add shapes to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).
	virtual void AddShapes(CFODrawShapeList &list);

	// Add shapes to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeSet &list object (Value).
	virtual void AddShapes(CFODrawShapeSet &list);

	// Get sizement type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Size Type, Returns the specified value.
	// Parameters:
	//		nSizement---nSizement, Specifies a SizementFlag& nSizement object(Value).
	void GetSizeType(SizementFlag& nSizement) const;

	// Set sizement type.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Size Type, Sets a specify value to current class CFOSizeAction
	// Parameters:
	//		nSizement---nSizement, Specifies a SizementFlag nSizement object(Value).
	void SetSizeType(SizementFlag nSizement);

	// Attributes
protected:

	// the list of shapes.
 
	// Shapes, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList m_listShapes;

	// The auchor shape.
 
	// Main Component, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *m_pMainComp;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE void CFOSizeAction::GetSizeType(SizementFlag& nSize) const
{
	nSize = m_nSizement;
}

_FOLIB_INLINE void CFOSizeAction::SetSizeType(SizementFlag nSize)
{
	m_nSizement = nSize;
}

#endif // !defined(AFX_FOSIZEACTION_H__5D3EDD14_F259_11DD_A433_525400EA266C__INCLUDED_)
