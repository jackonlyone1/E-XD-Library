//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOADDSPOTACTION_H__5ABCA954_57E1_11D6_A57B_525400EA266C__INCLUDED_)
#define AFC_FOADDSPOTACTION_H__5ABCA954_57E1_11D6_A57B_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

///////////////////////////////////////
// Description
// Author: Author Name
///////////////////////////////////////

#include "FOAction.h"
//////////////////////////////////////////////////////////////////////////////////
// CFOAddSpotAction -- action that insert a new spot within one shape.

 
//===========================================================================
// Summary:
//     The CFOAddSpotAction class derived from CFOAction
//      F O Add Spot Action
//===========================================================================

class FO_EXT_CLASS CFOAddSpotAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOAddSpotAction---F O Add Spot Action, Specifies a E-XD++ CFOAddSpotAction object (Value).
	DECLARE_ACTION(CFOAddSpotAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Add Spot Action, Constructs a CFOAddSpotAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	CFOAddSpotAction(CFODataModel* pModel,CFODrawShape *pShape);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Add Spot Action, Destructor of class CFOAddSpotAction
	//		Returns A  value (Object).
	~CFOAddSpotAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOAddSpotAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

	
	//TODO:Add your code here.

	// Get spot index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Spot Index, Returns the specified value.
	//		Returns a int type value.
	int GetSpotIndex() const { return m_nSpotIndex; }

	// Set spot index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Spot Index, Sets a specify value to current class CFOAddSpotAction
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.
	void SetSpotIndex(const int &nIndex) { m_nSpotIndex = nIndex; }

	// Get spot point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Spot Point, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetSpotPoint() const { return m_ptPoint; }

	// Set spot point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Spot Point, Sets a specify value to current class CFOAddSpotAction
	// Parameters:
	//		&pt---Specifies A CPoint type value.
	void SetSpotPoint(const CPoint &pt) { m_ptPoint = pt; }

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// Pointer of the shape.
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *	m_pShape;

	// Add spot index.
 
	// Spot Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nSpotIndex;

	// Add new point.
 
	// Point, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptPoint;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE CFODrawShape *CFOAddSpotAction::GetShape()
{
	return m_pShape;
}

//===========================================================================
// Summary:
//     The CFOAddUserPointAction class derived from CFOAction
//      F O Add Spot Action
//===========================================================================

class FO_EXT_CLASS CFOAddUserPointAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOAddUserPointAction---F O Add Spot Action, Specifies a E-XD++ CFOAddUserPointAction object (Value).
	DECLARE_ACTION(CFOAddUserPointAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Add Spot Action, Constructs a CFOAddUserPointAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	CFOAddUserPointAction(CFODataModel* pModel,CFODrawShape *pShape);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Add Spot Action, Destructor of class CFOAddUserPointAction
	//		Returns A  value (Object).
	~CFOAddUserPointAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOAddUserPointAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFODrawShape  or NULL if the call failed.
	virtual void SetShape(CFODrawShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShape ,or NULL if the call failed
	virtual CFODrawShape *GetShape();

	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

	
	//TODO:Add your code here.

	// Get spot index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Spot Index, Returns the specified value.
	//		Returns a int type value.
	int GetSpotIndex() const { return m_nSpotIndex; }

	// Set spot index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Spot Index, Sets a specify value to current class CFOAddUserPointAction
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.
	void SetSpotIndex(const int &nIndex) { m_nSpotIndex = nIndex; }

	// Get spot point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Spot Point, Returns the specified value.
	//		Returns a CPoint type value.
	CPoint GetSpotPoint() const { return m_ptPoint; }

	// Set spot point.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Spot Point, Sets a specify value to current class CFOAddUserPointAction
	// Parameters:
	//		&pt---Specifies A CPoint type value.
	void SetSpotPoint(const CPoint &pt) { m_ptPoint = pt; }

public:

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// Pointer of shape.
 
	// Shape, This member maintains a pointer to the object CFODrawShape.  
	CFODrawShape *	m_pShape;

	// Add spot index.
 
	// Spot Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int				m_nSpotIndex;

	// Add new point.
 
	// Point, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint			m_ptPoint;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE CFODrawShape *CFOAddUserPointAction::GetShape()
{
	return m_pShape;
}

#endif // !defined(AFC_FOADDSPOTACTION_H__5ABCA954_57E1_11D6_A57B_525400EA266C__INCLUDED_)
