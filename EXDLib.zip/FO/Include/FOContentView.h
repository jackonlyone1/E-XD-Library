//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOContentView.h: interface for the CFOContentView class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOCONTENTVIEW_H__18CF5276_F709_11DD_A43D_525400EA266C__2027_INCLUDED_)
#define AFX_FOCONTENTVIEW_H__18CF5276_F709_11DD_A43D_525400EA266C__2027_INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOMultiPageModelManager.h"
#include "FOPreviewBitmap.h"

/////////////////////////////////////////////////////////////////////////////////
// CFOContentView
// 
// This class is defined for  Multiple DataModel's style application.
// Call SetItemSize(..) to change the size of the item,call SetItemSpace to change
// the space between items.
//
// Call GetSelected(..) to obtain the pointer of the item.
// Override CreateContextMenu method to change the context menu.
//
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOContentView class derived from CScrollView
//      F O Content View
//===========================================================================

class FO_EXT_CLASS CFOContentView : public CScrollView, public CFOObserver
{
protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOContentView---F O Content View, Specifies a E-XD++ CFOContentView object (Value).
	DECLARE_DYNCREATE(CFOContentView)

		//-----------------------------------------------------------------------
		// Summary:
	//Constructor
	// protected constructor used by dynamic creation
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Content View, Constructs a CFOContentView object.
	//		Returns A  value (Object).
	CFOContentView();           

protected:

	//-----------------------------------------------------------------------
	// Summary:
	// Current Data Model manager.
 
	// Current Data Manager, This member maintains a pointer to the object CFOMultiPageModelManager.  
	CFOMultiPageModelManager *m_pCurDataManager;

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Obtain the pointer of the data model manager
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Multiple Page Manager, Returns the specified value.
	//		Returns a pointer to the object CFOMultiPageModelManager ,or NULL if the call failed
	CFOMultiPageModelManager *GetMultiPageManager() const;

	//-----------------------------------------------------------------------
	// Summary:
	// Change the pointer of the data model manager
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Multiple Page Manager, Sets a specify value to current class CFOContentView
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pModelMgr---Model Mgr, A pointer to the CFOMultiPageModelManager  or NULL if the call failed.
	virtual void SetMultiPageManager(
		// Multi page data model manager.
		CFOMultiPageModelManager *pModelMgr
		);

	//-----------------------------------------------------------------------
	// Summary:
	// When data within the data model manager changed, this method will be called to notify these changes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update Observer, Call this member function to update the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pModel---pModel, A pointer to the CObject  or NULL if the call failed.  
	//		lHint---lHint, Specifies A LPARAM value.  
	//		CObject*pHint---Object*p Hint, A pointer to the CObject or NULL if the call failed.
	virtual BOOL UpdateObserver( 
		// Data model.
		CObject * pModel,
		// Hint value.
		LPARAM lHint, 
		// Extra data value.
		CObject*pHint);

// Attributes
public:

	// Obtain the list of models within the data model manager.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Model List, Returns the specified value.
	//		Returns a pointer to the object CFOMultiPageModelSet ,or NULL if the call failed
	CFOMultiPageModelSet *GetModelList() const					{ return pModelList; }

	// Change Model List
	// pList -- pointer of list
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Model List, Sets a specify value to current class CFOContentView
	// Parameters:
	//		*pList---*pList, A pointer to the CFOMultiPageModelSet  or NULL if the call failed.
	void			SetModelList(CFOMultiPageModelSet *pList)	{ pModelList = pList; }

	// determine row the page with the given number is in
	// nPageNum -- number of page
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Row Of Page, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nPageNum---Page Number, Specifies A integer value.
    int GetRowOfPage( int nPageNum ) const;

    // determine column the page with the given number is in
	// nPageNum -- number of page.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Column Of Page, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nPageNum---Page Number, Specifies A integer value.
    int GetColOfPage( int nPageNum ) const;

	// Is active or not.
 
	// Active, This member sets TRUE if it is right.  
	BOOL			m_bActive;

protected:

	// Get scroll position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Scroll Pos32, Returns the specified value.
	//		Returns a int type value.  
	// Parameters:
	//		nBar---nBar, Specifies A integer value.  
	//		bGetTrackPos---Get Track Position, Specifies A Boolean value.
	int GetScrollPos32(int nBar, BOOL bGetTrackPos = FALSE );
	
	// Set scroll position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Scroll Pos32, Sets a specify value to current class CFOContentView
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nBar---nBar, Specifies A integer value.  
	//		nPos---nPos, Specifies A integer value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	BOOL SetScrollPos32( int nBar, int nPos, BOOL bRedraw = TRUE );

	// Add page to cache
	// pPage -- pointer of the page data model
	// rBitmap -- bitmap object
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add To Cache, Adds an object to the specify list.
	// Parameters:
	//		pPage---pPage, A pointer to the CFOMultiPageModel or NULL if the call failed.  
	//		rBitmap---rBitmap, Specifies a E-XD++ CFOBitmap& rBitmap object (Value).
	void		  AddToCache( CFOMultiPageModel* pPage, CFOBitmap& rBitmap);

	// Obtain current cache.
	// pPage -- pointer of the page data model
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get From Cache, Returns the specified value.
	//		Returns a pointer to the object CFOBitmap,or NULL if the call failed  
	// Parameters:
	//		pPage---pPage, A pointer to the CFOMultiPageModel or NULL if the call failed.
	CFOBitmap*    GetFromCache( CFOMultiPageModel* pPage) const;

	// Select page
	// nNumber -- page number,this is the same with GetPageItemNumber
	
	//-----------------------------------------------------------------------
	// Summary:
	// Selected Page, Call this function to select the given item.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMultiPageModel ,or NULL if the call failed  
	// Parameters:
	//		&nNumber---&nNumber, Specifies A integer value.
	virtual CFOMultiPageModel *SelectedPage(const int &nNumber);

	// Do something when select page changed.
	// pNew -- pointer of the page data model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Page Changed, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pNew---*pNew, A pointer to the CFOMultiPageModel  or NULL if the call failed.
	virtual void DoPageChanged(CFOMultiPageModel *pNew);

public:

	// Obtain the Back Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Background Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF		GetBkColor() const							{ return m_crBackColor; }

	// Change the Back Color.
	// crColor -- color value of the background
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Background Color, Sets a specify value to current class CFOContentView
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void			SetBkColor(const COLORREF &crColor)			{ m_crBackColor = crColor; }

	// Obtain the Item Size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Size, Returns the specified value.
	//		Returns a CSize type value.
	CSize			GetItemSize() const							{ return CSize(nItemCX,nItemCY); }

	// Change the Item Size
	// szItem -- size of the item.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Size, Sets a specify value to current class CFOContentView
	// Parameters:
	//		&szItem---&szItem, Specifies A CSize type value.
	void			SetItemSize(const CSize &szItem)			{ nItemCX = szItem.cx,nItemCY = szItem.cy; }

	// Obtain the Item Space
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Item Space, Returns the specified value.
	//		Returns a int type value.
	int				GetItemSpace() const						{ return nItemSpace; }

	// Change the Item Space
	// nSpace -- space between items.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Space, Sets a specify value to current class CFOContentView
	// Parameters:
	//		&nSpace---&nSpace, Specifies A integer value.
	void			SetItemSpace(const int &nSpace)				{ nItemSpace = nSpace; }
	
public:
	// Define for font.
	/*************************************************************************
	|*
	|* Font properties
	|*
	\************************************************************************/

	// Get font Face Name
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Face Name, Returns the specified value.
	//		Returns a CString type value.
	CString		GetFaceName() const;

	// Change the font Face Name,
	// lpszFaceName -- standard font face name.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Face Name, Sets a specify value to current class CFOContentView
	// Parameters:
	//		lpszFaceName---Face Name, Specifies A 32-bit LPCTSTR pointer to a constant character string that is portable for Unicode and DBCS.
	void		SetFaceName(LPCTSTR lpszFaceName);

	// Get Point Size of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point Size, Returns the specified value.
	//		Returns a int type value.
	int			GetPointSize() const;

	// Change font Point Size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Point Size, Sets a specify value to current class CFOContentView
	// Parameters:
	//		&nPointSize---Point Size, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void		SetPointSize(const int &nPointSize, CDC* pDC = NULL);

	// Get Height of the font.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Height, Returns the specified value.
	//		Returns a int type value.
	int			GetHeight() const;

	// Change the font Height.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Height, Sets a specify value to current class CFOContentView
	// Parameters:
	//		&nHeight---&nHeight, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	void		SetHeight(const int &nHeight, CDC* pDC = NULL);

	// Get Font Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Text Color, Returns the specified value.
	//		Returns A 32-bit COLORREF value used as a color value.
	COLORREF	GetTextColor() const;

	// Change the Font Color
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Font Color, Sets a specify value to current class CFOContentView
	// Parameters:
	//		&crColor---&crColor, Specifies A 32-bit COLORREF value used as a color value.
	void		SetFontColor(const COLORREF &crColor);

	// Get Weight
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Weight, Returns the specified value.
	//		Returns a int type value.
	int			GetWeight() const;

	// Change the font Weight,
	// nWeight -- 700 is Bold,500 is Normal and must be nWeight >= 0 && nWeight <= 1000
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Weight, Sets a specify value to current class CFOContentView
	// Parameters:
	//		&nWeight---&nWeight, Specifies A integer value.
	void		SetWeight(const int &nWeight);

	// Is It Italic
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Italic, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetItalic() const;

	// Change the font italic property.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Italic, Sets a specify value to current class CFOContentView
	// Parameters:
	//		&bItalic---&bItalic, Specifies A Boolean value.
	void		SetItalic(const BOOL &bItalic);

	// Is It  Underline
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Underline, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetUnderline() const;

	// Change the font underline property.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Underline, Sets a specify value to current class CFOContentView
	// Parameters:
	//		&bUnderline---&bUnderline, Specifies A Boolean value.
	void		SetUnderline(const BOOL &bUnderline);

	// Is It Strikeout
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Strikeout, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL		GetStrikeout() const;

	// Change the font strikeout property.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Strikeout, Sets a specify value to current class CFOContentView
	// Parameters:
	//		&bStrikeout---&bStrikeout, Specifies A Boolean value.
	void		SetStrikeout(const BOOL &bStrikeout);

	// Creates a GDI font object. The caller is responsible for freeing this memory!
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Font, You construct a CFOContentView object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFont,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual CFont*	CreateFont(CDC* pDC = NULL);

	
	// Returns a pointer to the cached GDI font object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font, Returns the specified value.
	//		Returns a pointer to the object CFont,or NULL if the call failed  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	CFont*			GetFont(CDC* pDC = NULL);

	// Releases the cached font object. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// Release Font Object, .

	void			ReleaseFontObject();

	// Create memory dc.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Temp D C, You construct a CFOContentView object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		&pMemoryDC---Memory D C, A pointer to the CDC or NULL if the call failed.  
	//		rcPaint---rcPaint, Specifies A CRect type value.
	virtual BOOL CreateTempDC( CDC* pDC, CDC* &pMemoryDC, const CRect& rcPaint) const;

protected:

	// Change  Point To Logical
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Logical Point, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&nPoints---&nPoints, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual int GetLogPoint(const int &nPoints, CDC* pDC = NULL, BOOL bVertical = TRUE);

	// From Logical To Point
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Point From Logical, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.  
	// Parameters:
	//		&nLog---&nLog, Specifies A integer value.  
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		bVertical---bVertical, Specifies A Boolean value.
	virtual int GetPointFromLog(const int &nLog, CDC* pDC = NULL, BOOL bVertical = TRUE);

public:

	// Creates GDI objects and sets up the device context for drawing.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Prepare D C, Creates GDI objects and sets up the device context for drawing.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void	PrepareDC(CDC* pDC);
	
	// Frees GDI objects and restores the state of the device context.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Clear D C, Remove the specify data from the list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void	ClearDC(CDC* pDC);

	// Update all pages.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Update All Pages, Call this member function to update the object.

	void UpdateAllPages();

	// Get nearest page
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Nearest Page, Returns the specified value.
	//		Returns a pointer to the object CFOMultiPageModel,or NULL if the call failed  
	// Parameters:
	//		rPos---rPos, Specifies A integer value.
	CFOMultiPageModel* GetNearestPage( const FOPPoint& rPos ) const;

protected:

	// Create Context Menu
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create Context Menu, You construct a CFOContentView object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CMenu,or NULL if the call failed
	virtual CMenu*	CreateContextMenu();

	// Get Start Position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Start Position, Returns the specified value.
	// Parameters:
	//		&nStart---&nStart, Specifies A integer value.
	void			GetStartPos(int &nStart);

	
	//-----------------------------------------------------------------------
	// Summary:
	// Hit Test, Hit test on this object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMultiPageModel ,or NULL if the call failed  
	// Parameters:
	//		pt---Specifies A CPoint type value.
	// HitTest
	virtual CFOMultiPageModel *HitTest(
		// Mouse hit point.
		CPoint pt
		);

	// HitTest
	
	//-----------------------------------------------------------------------
	// Summary:
	// Hited, Determines if the mouse has been clicked on a component.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMultiPageModel ,or NULL if the call failed  
	// Parameters:
	//		pt---Specifies A CPoint type value.
	virtual CFOMultiPageModel *Hited(
		// Mouse hit point
		CPoint pt
		);

	// Get Selected
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Selected, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMultiPageModel ,or NULL if the call failed
	virtual CFOMultiPageModel *GetSelected();

	// Setup Scroll Bar
	
	//-----------------------------------------------------------------------
	// Summary:
	// Setup Scroll Bar, Sets a specify value to current class CFOContentView
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	SetupScrollBar();

	// Return Selected Item
	
	//-----------------------------------------------------------------------
	// Summary:
	// Selected Item, Call this function to select the given item.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMultiPageModel ,or NULL if the call failed  
	// Parameters:
	//		point---Specifies A CPoint type value.
	virtual CFOMultiPageModel *SelectedItem(CPoint point);

	// Invalidate Rectangle
	
	//-----------------------------------------------------------------------
	// Summary:
	// Invalidate Rectangle, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		rc---Specifies A CRect type value.
	virtual void	InvalRect(CRect rc);

	// Get Size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Size, Returns the specified value.
	//		Returns a int type value.
	int				GetSize();

	// Get Font Size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Font Size, Returns the specified value.
	//		Returns a CSize type value.
	CSize			GetFontSize();

	// Set Item Size
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Item Size, Sets a specify value to current class CFOContentView
	// Parameters:
	//		nx---Specifies A integer value.  
	//		ny---Specifies A integer value.
	void			SetItemSize(int nx,int ny);

	// Draw Items
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw Items, Called when a visual aspect of an owner-draw child button control, combo-box control, list-box control, or menu needs to be drawn.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		&rcView---&rcView, Specifies A CRect type value.
	virtual void	OnDrawItems(CDC *pDC,const CRect &rcView);

	// Initialize Update
	
	//-----------------------------------------------------------------------
	// Summary:
	// Initial Update, Call InitUpdate after creating a new object.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void	InitUpdate();

	// Calculate Item Position
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Item Position, .

	void			CalcItemPosition();

	// Document To Client
	
	//-----------------------------------------------------------------------
	// Summary:
	// Document To Client, Do a event. 
	// Parameters:
	//		rect---Specifies A CRect type value.
	void			DocToClient(CRect& rect);

	// Document To Client
	
	//-----------------------------------------------------------------------
	// Summary:
	// Document To Client, Do a event. 
	// Parameters:
	//		point---Specifies A CPoint type value.
	void			DocToClient(CPoint& point);

	// Client To Document  
	
	//-----------------------------------------------------------------------
	// Summary:
	// Client To Document, .
	// Parameters:
	//		point---Specifies A CPoint type value.
	void			ClientToDoc(CPoint& point);

	// Client To Document  
	
	//-----------------------------------------------------------------------
	// Summary:
	// Client To Document, .
	// Parameters:
	//		rect---Specifies A CRect type value.
	void			ClientToDoc(CRect& rect);

	// Set new scrollbar position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set New Scroll Bar Position, Sets a specify value to current class CFOContentView
	// Parameters:
	//		ptScrollPos---Scroll Position, Specifies A CPoint type value.  
	//		bRedraw---bRedraw, Specifies A Boolean value.
	void			SetNewScrollBarPos(CPoint ptScrollPos,BOOL bRedraw);

	// Make sure item visible.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Ensure Visible, .
	// Parameters:
	//		pItem---pItem, A pointer to the CFOMultiPageModel or NULL if the call failed.
	void			EnsureVisible (CFOMultiPageModel* pItem);

// Operations
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void DoDraw(CDC* pDC);      // overridden to draw this view

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOContentView)
	public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Prepare D C, Called before the OnDraw member function is called for screen display or the OnPrint member function is called for printing or print preview.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnPrepareDC(CDC* pDC, CPrintInfo* pInfo = NULL);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Window Message, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.  
	//		pResult---pResult, A pointer to the LRESULT or NULL if the call failed.
	virtual BOOL OnWndMsg( UINT message, WPARAM wParam, LPARAM lParam, LRESULT* pResult );
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Update, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnInitialUpdate();     // first time after construct
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update, Called to notify a view that its document has been modified.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pSender---pSender, A pointer to the CView or NULL if the call failed.  
	//		lHint---lHint, Specifies A LPARAM value.  
	//		pHint---pHint, A pointer to the CObject or NULL if the call failed.
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate View, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bActivate---bActivate, Specifies A Boolean value.  
	//		pActivateView---Activate View, A pointer to the CView or NULL if the call failed.  
	//		pDeactiveView---Deactive View, A pointer to the CView or NULL if the call failed.
	virtual void OnActivateView(BOOL bActivate, CView* pActivateView, CView* pDeactiveView);
	//}}AFX_VIRTUAL

// Implementation
protected:

	//Destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Content View, Destructor of class CFOContentView
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOContentView();
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CFOContentView)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On V Scroll, Called when the user clicks the window's vertical scroll bar.
	// Parameters:
	//		nSBCode---S B Code, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nPos---nPos, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pScrollBar---Scroll Bar, A pointer to the CScrollBar or NULL if the call failed.
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Down, Called when the user presses the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Up, Called when the user releases the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On L Button Double click Clk, Called when the user double-clicks the left mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Size, Called after the size of CWnd has changed.
	// Parameters:
	//		nType---nType, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		cx---Specifies A integer value.  
	//		cy---Specifies A integer value.
	afx_msg void OnSize(UINT nType, int cx, int cy);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Erase Background, Called when the window background needs erasing.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Add Newpage, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnAddNewpage();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Add Newpage, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateAddNewpage(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Remove Page, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnRemovePage();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Remove Page, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdateRemovePage(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Page Caption, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnPageCaption();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Page Caption, Called to notify a view that its document has been modified.
	// Parameters:
	//		pCmdUI---Cmd U I, A pointer to the CCmdUI or NULL if the call failed.
	afx_msg void OnUpdatePageCaption(CCmdUI* pCmdUI);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Down, Called when the user presses the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Context Menu, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pWnd---pWnd, A pointer to the CWnd or NULL if the call failed.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On R Button Up, Called when the user releases the right mouse button.
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		point---Specifies A CPoint type value.
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Key Down, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nChar---nChar, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nRepCnt---Rep Count, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Mouse Wheel, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nFlags---nFlags, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		zDelta---zDelta, Specifies a short zDelta object(Value).  
	//		pt---Specifies A CPoint type value.
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Kill Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pNewWnd---New Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Focus, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		pOldWnd---Old Window, A pointer to the CWnd or NULL if the call failed.
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
protected:

	// Model List
 
	// Model List, This member maintains a pointer to the object CFOMultiPageModelSet.  
	CFOMultiPageModelSet*	pModelList;

	// Small font
 
	// Small, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont					m_fntSmall;

	// Section size
 
	// Section, This member sets a CSize value.  
	CSize					m_sizSection;

	// Sections Per Row
 
	// Sections Per Row, This member can be sets with A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	UINT					m_uSectionsPerRow;

	// Caption string
 
	// Caption, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString					strCaption;

	// Back Color
 
	// Back Color, This member sets A 32-bit value used as a color value.  
	COLORREF				crBackColor;

	// The Pointer to  ContextMenu
 
	// Context Menu, This member maintains a pointer to the object CMenu.  
	CMenu*					m_pContextMenu;

	// Item X coordinates
 
	// Item C X, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						nItemCX;

	// Item Y coordinates
 
	// Item C Y, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						nItemCY;

	// Item Space
 
	// Item Space, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						nItemSpace;

	// The name of the font. 
 
	// Face Name, You can freely substitute CString objects for const char* and LPCTSTR function arguments.  
	CString					m_strFaceName;
	
	// The point size of the font. 
 
	// Point Size, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						m_nPointSize;
	
	// Height of the font in logical units. 
 
	// Height, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						m_nHeight;
	
	// The font color. 
 
	// Color, This member sets A 32-bit value used as a color value.  
	COLORREF				m_crColor;
	
	// The weight of the font (normal, bold, etc.) 
 
	// Weight, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int						m_nWeight;
	
	// The italic setting of the font. 
 
	// Italic, This member sets TRUE if it is right.  
	BOOL					m_bItalic;
	
	// The underline setting of the font. 
 
	// Underline, This member sets TRUE if it is right.  
	BOOL					m_bUnderline;
	
	// The strike out setting of the font. 
 
	// Strikeout, This member sets TRUE if it is right.  
	BOOL					m_bStrikeout;
	
	// Cached GDI font. 
 
	// Font, The CFont class encapsulates a Windows graphics device interface (GDI) font and provides member functions for manipulating the font.  
	CFont*					m_pFont;

	// Back Color
 
	// Back Color, This member sets A 32-bit value used as a color value.  
	COLORREF				m_crBackColor;

	// Images area
 
	// List, This member sets a CRect value.  
	CRect					m_rectList;

	// Bitmap cache
 
	// Cache, This member maintains a pointer to the object CFOPBitmapCache.  
	CFOPBitmapCache*		pCache;

	// Control has focus
 
	// Focused, This member sets TRUE if it is right.  
	BOOL					m_bFocused;				

};
/////////////////////////////////////////////////////////////////////////////

// Get Face Name
_FOLIB_INLINE CString CFOContentView::GetFaceName() const
{
	return m_strFaceName;
}

// Get Point Size
_FOLIB_INLINE int CFOContentView::GetPointSize() const
{
	return m_nPointSize;
}

// Get Height
_FOLIB_INLINE int CFOContentView::GetHeight() const
{
	return m_nHeight;
}

// Set Text Color
_FOLIB_INLINE COLORREF CFOContentView::GetTextColor() const
{
	return m_crColor;
}

// Get Weight
_FOLIB_INLINE int CFOContentView::GetWeight() const
{
	return m_nWeight;
}

// Is It Italic
_FOLIB_INLINE BOOL CFOContentView::GetItalic() const
{
	return m_bItalic;
}

// GetItalic
_FOLIB_INLINE void CFOContentView::SetItalic(const BOOL &bItalic)
{
	m_bItalic = bItalic;
}

// Get Underline
_FOLIB_INLINE BOOL CFOContentView::GetUnderline() const
{
	return m_bUnderline;
}

// Set Underline
_FOLIB_INLINE void CFOContentView::SetUnderline(const BOOL &bUnderline)
{
	m_bUnderline = bUnderline;
}

// Get Strikeout
_FOLIB_INLINE BOOL CFOContentView::GetStrikeout() const
{
	return m_bStrikeout;
}

// set Strikeout
_FOLIB_INLINE void CFOContentView::SetStrikeout(const BOOL &bStrikeout)
{
	m_bStrikeout = bStrikeout;
}
#endif // !defined(AFX_FOCONTENTVIEW_H__18CF5276_F709_11DD_A43D_525400EA266C__2027_INCLUDED_)
