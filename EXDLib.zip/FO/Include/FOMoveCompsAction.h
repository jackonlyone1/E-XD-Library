//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOMoveCompsAction.h: interface for the CFOMoveCompsAction class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOMOVECOMPSACTION_H__5D3EDD11_F259_11DD_A433_525400EA266C__INCLUDED_)
#define AFX_FOMOVECOMPSACTION_H__5D3EDD11_F259_11DD_A433_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOAction.h"

//////////////////////////////////////////////////////////////////////////////////
// CFOMoveCompsAction -- action that moving components.

 
//===========================================================================
// Summary:
//     The CFOMoveCompsAction class derived from CFOAction
//      F O Move Components Action
//===========================================================================

class FO_EXT_CLASS CFOMoveCompsAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOMoveCompsAction---F O Move Components Action, Specifies a E-XD++ CFOMoveCompsAction object (Value).
	DECLARE_ACTION(CFOMoveCompsAction)

public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Move Components Action, Constructs a CFOMoveCompsAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		list---Specifies a const CFODrawShapeList& list object(Value).  
	//		sizeOffset---sizeOffset, Specifies A CSize type value.
	CFOMoveCompsAction(CFODataModel* pModel, const CFODrawShapeList& list,CSize sizeOffset);

	// Destructor. 
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Move Components Action, Destructor of class CFOMoveCompsAction
	//		Returns A  value (Object).
	~CFOMoveCompsAction();

// Overrides
public:
	
	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction,or NULL if the call failed
	virtual CFOBaseAction* GetRedoAction() const;

	// Get the name of the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		strLabel---strLabel, Specifies A CString type value.
	virtual void Sprint(CString& strLabel) const;

	// Get the list shapes.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape List, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODrawShapeList,or NULL if the call failed
	virtual CFODrawShapeList* GetShapeList();

	// Add new shape to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shape, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual void AddShape(CFODrawShape* pShape);

	// Add shapes to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeList &list object (Value).
	virtual void AddShapes(CFODrawShapeList &list);

	// Add shapes to the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Add Shapes, Adds an object to the specify list.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&list---Specifies a E-XD++ CFODrawShapeSet &list object (Value).
	virtual void AddShapes(CFODrawShapeSet &list);

	// Remove shape from the list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Remove Shape, Call this function to remove a specify value from the specify object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pShape---pShape, A pointer to the CFODrawShape or NULL if the call failed.
	virtual void RemoveShape(CFODrawShape* pShape);

	// Attributes
protected:

	// Get max position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

	// Shapes list.
 
	// Shapes, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList m_listShapes;

	// Size of offset.
 
	// Offset, This member sets a CSize value.  
	CSize			szOffset;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

_FOLIB_INLINE CFODrawShapeList* CFOMoveCompsAction::GetShapeList()
{
	return &m_listShapes;
}

#endif // !defined(AFX_FOMOVECOMPSACTION_H__5D3EDD11_F259_11DD_A433_525400EA266C__INCLUDED_)
