//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOPFRAMEWND_H__DBA663CE_675E_4326_BDC9_60332B8E767B__INCLUDED_)
#define AFX_FOPFRAMEWND_H__DBA663CE_675E_4326_BDC9_60332B8E767B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOPFrameWnd.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFOPFrameWnd frame

#include "FODefines.h"

class CDockBar;
class CFOPControlBar;
class CFOPMenuTheme;

/////////////////////////////////////////////////////////////////////////////
// CFOPFrameWnd frame

#include "FOPFullScreenImpl.h"

 
//===========================================================================
// Summary:
//     The CFOPFrameWnd class derived from CFrameWnd
//      F O P Frame Window
//===========================================================================

class FO_EXT_CLASS CFOPFrameWnd : public CFrameWnd
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPFrameWnd---F O P Frame Window, Specifies a E-XD++ CFOPFrameWnd object (Value).
	DECLARE_DYNCREATE(CFOPFrameWnd)
		
protected:
	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Frame Window, Constructs a CFOPFrameWnd object.
	//		Returns A  value (Object).
	CFOPFrameWnd();

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Frame Window, Destructor of class CFOPFrameWnd
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOPFrameWnd();

public:

	// Get active state.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Active State, Returns the specified value.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL GetActiveState();

public:
	
	// Enable docking
	// dwDockStyle -- dock style
	// dwDockStyleEx -- extend dock style
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Docking, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		dwDockStyle---Dock Style, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		dwDockStyleEx---Dock Style Ex, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	void EnableDocking(DWORD dwDockStyle, DWORD dwDockStyleEx = 0);

	// Create new dock bar control
	
	//-----------------------------------------------------------------------
	// Summary:
	// Create New Dock Bar, You construct a CFOPFrameWnd object in two steps. First call the constructor, then call Create, which creates the object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CDockBar ,or NULL if the call failed
	virtual CDockBar * CreateNewDockBar();

	// Float control bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Float  Bar, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar  or NULL if the call failed.  
	//		point---Specifies A CPoint type value.  
	//		dwStyle---dwStyle, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.
	virtual void FloatControlBar(
		// Pointer of control bar.
		CControlBar * pBar, 
		// Float start point.
		CPoint point,
		// Layout position.
		DWORD dwStyle = CBRS_ALIGN_TOP
		);

	// Dock control bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dock  Bar Ex, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar  or NULL if the call failed.  
	//		nDockBarID---Dock Bar I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		dPctWidth---Pct Width, Specifies a double dPctWidth = 1.0 object(Value).  
	//		nHeight---nHeight, Specifies A integer value.
	virtual void DockControlBarEx(
		// Pointer of control bar.
		CControlBar * pBar,
		// Dock bar id
		UINT nDockBarID = 0,
		// Width from 0.0 to 1.0
		double dPctWidth = 1.0,
		// Height.
		int nHeight = 150
		);

	// Dock control bar
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dock  Bar, Do a event. 
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar  or NULL if the call failed.  
	//		nDockBarID---Dock Bar I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.
	void DockControlBar(
		// Pointer of controlbar.
		CControlBar * pBar,
		// Dock bar id.
		UINT nDockBarID = 0, 
		// Position of layout.
		LPCRECT lpRect = NULL
		);

	// Dock control bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dock  Bar, Do a event. 
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar  or NULL if the call failed.  
	//		pDockBar---Dock Bar, A pointer to the CDockBar  or NULL if the call failed.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.
	void DockControlBar(
		CControlBar * pBar,
		CDockBar * pDockBar,
		LPCRECT lpRect = NULL
		);

	// Re dock control bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re Dock  Bar, .
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar  or NULL if the call failed.  
	//		pDockBar---Dock Bar, A pointer to the CDockBar  or NULL if the call failed.  
	//		lpRect---lpRect, Specifies A 32-bit LPCRECT pointer to a constant (nonmodifiable) RECT structure.
	void ReDockControlBar(
		// Pointer of control bar.
		CControlBar * pBar,
		// Dock bar.
		CDockBar * pDockBar,
		// Layout position.
		LPCRECT lpRect = NULL
		);


	// Show control bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show  Bar, Call this function to show the specify object.
	// Parameters:
	//		pBar---pBar, A pointer to the CControlBar  or NULL if the call failed.  
	//		bShow---bShow, Specifies A Boolean value.  
	//		bDelay---bDelay, Specifies A Boolean value.
	void ShowControlBar(
		// Pointer of controlbar.
		CControlBar * pBar, 
		// Show or hide.
		BOOL bShow, 
		// Delay show.
		BOOL bDelay
		);

	// Dock control bar left of a specify bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dock  Bar Left Of, Do a event. 
	// Parameters:
	//		Bar---Bar, A pointer to the CControlBar or NULL if the call failed.  
	//		LeftOf---Left Of, A pointer to the CControlBar or NULL if the call failed.
	void DockControlBarLeftOf(
		// Pointer of controlbar.
		CControlBar* Bar,
		// Pointer of controlbar
		CControlBar* LeftOf
		);

	// Dock control bar bottom of a specify bar.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dock  Bar Bottom Of, Do a event. 
	// Parameters:
	//		Bar---Bar, A pointer to the CControlBar or NULL if the call failed.  
	//		BottomOf---Bottom Of, A pointer to the CControlBar or NULL if the call failed.
	void DockControlBarBottomOf(
		// Pointer of controlbar
		CControlBar* Bar,
		// Pointer of controlbar
		CControlBar* BottomOf
		);

	// Show menu image.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Menu Image, Call this function to show the specify object.

	void ShowMenuImage();
	
	// Set menu image resource.
	// nIDStdBmp -- ID of the toolbar bitmap resource.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Menu Image Resource, Sets a specify value to current class CFOPFrameWnd
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIDStdBmp---I D Std Bitmap, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	BOOL SetMenuImageRes(UINT nIDStdBmp);

	// Do swap menu item.
	// bPreview -- preview or not.
	// pState -- pointer of the print preview state
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Set Preview Mode, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bPreview---bPreview, Specifies A Boolean value.  
	//		pState---pState, A pointer to the CPrintPreviewState  or NULL if the call failed.
	virtual void OnSetPreviewMode(BOOL bPreview, CPrintPreviewState * pState);

	// Is full screen mode.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Full Screen, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsFullScreen() const;

	// Show full screen.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Show Full Screen, Call this function to show the specify object.
	// Parameters:
	//		bWithMenu---With Menu, Specifies A Boolean value.
	void ShowFullScreen(BOOL bWithMenu = TRUE);

protected:
	
	// Dock bar.
 
	// Dock Bar[4][2], This member specify A 32-bit unsigned integer or the address of a segment and its associated offset.  
	static const DWORD dwValues1[4][2];

	// Get windows version.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Windows Version, Returns the specified value.

	void GetWindowsVersion();

	// Get menu from resource id.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Menu From Resource, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A HMENU value (Object).  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.
	virtual HMENU MenuFromResource(UINT nID);

public:

	// Get menu.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Menu, Returns the specified value.
	//		Returns a pointer to the object CMenu ,or NULL if the call failed
	CMenu * GetMenu() const;

	// Get default menu handle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Default Menu, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A HMENU value (Object).
	virtual HMENU GetDefaultMenu();

public:

	// Process help message.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Process Help Message, Call the Process member function to translate a caught exception.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		msg---Specifies a MSG & msg object(Value).  
	//		pContext---pContext, A pointer to the DWORD  or NULL if the call failed.
	BOOL ProcessHelpMsg(MSG & msg, DWORD * pContext);

#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext & dc object(Value).
	virtual void Dump(CDumpContext & dc) const;
#endif

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOPFrameWnd)
	
	//-----------------------------------------------------------------------
	// Summary:
	// Window Process Function, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		message---Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Translate Message, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pMsg---pMsg, A pointer to the MSG  or NULL if the call failed.
	virtual BOOL PreTranslateMessage(MSG * pMsg);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Load Frame, Call this function to read a specified number of bytes from the archive.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nIDResource---I D Resource, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		dwDefaultStyle---Default Style, Specifies A 32-bit DWORD unsigned integer or the address of a segment and its associated offset.  
	//		pParentWnd---Parent Window, A pointer to the CWnd  or NULL if the call failed.  
	//		pContext---pContext, A pointer to the CCreateContext  or NULL if the call failed.
	virtual BOOL LoadFrame(UINT nIDResource,DWORD dwDefaultStyle = WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE,CWnd * pParentWnd = NULL,CCreateContext * pContext = NULL);
	
	//-----------------------------------------------------------------------
	// Summary:
	// Re calculate Layout, Called by the framework when the standard control bars are toggled on or off or when the frame window is resized. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bNotify---bNotify, Specifies A Boolean value.
	virtual void RecalcLayout(BOOL bNotify = TRUE);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update Frame Menu, Called to notify a view that its document has been modified.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.  
	//		pActivateWnd---Activate Window, A pointer to the CWnd  or NULL if the call failed.  
	//		hMenuAlt---Menu Alt, Specifies a HMENU hMenuAlt object(Value).
	virtual void OnUpdateFrameMenu(BOOL bActive, CWnd * pActivateWnd,HMENU hMenuAlt);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Cmd Message, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		nID---I D, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		nCode---nCode, Specifies A integer value.  
	//		pExtra---pExtra, A pointer to the void  or NULL if the call failed.  
	//		pHandlerInfo---Handler Information, A pointer to the AFX_CMDHANDLERINFO  or NULL if the call failed.
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void * pExtra,AFX_CMDHANDLERINFO * pHandlerInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Enter Idle, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		nWhy---nWhy, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pWho---pWho, A pointer to the CWnd  or NULL if the call failed.
	virtual void OnEnterIdle(UINT nWhy, CWnd * pWho);
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFOPFrameWnd)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Create, Called as a part of window creation.
	//		Returns a int type value.  
	// Parameters:
	//		lpcs---Specifies a LPCREATESTRUCT lpcs object(Value).
	afx_msg int OnCreate(LPCREATESTRUCT lpcs);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Close, Called as a signal that CWnd should be closed.

	afx_msg void OnClose();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Ctx Menu, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A 32-bit LRESULT value returned from a window procedure or callback function.  
	// Parameters:
	//		wParam---wParam, Provides additional information used in processing the message. The parameter WPARAM value depends on the message.  
	//		lParam---lParam, Specifies A LPARAM value.
	afx_msg LRESULT OnCtxMenu(WPARAM wParam, LPARAM lParam);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		nState---nState, Specifies A 16-bit unsigned integer on Windows versions 3.0 and 3.1; a 32-bit unsigned integer on Win32.  
	//		pWndOther---Window Other, A pointer to the CWnd  or NULL if the call failed.  
	//		bMinimized---bMinimized, Specifies A Boolean value.
	afx_msg void OnActivate(UINT nState, CWnd * pWndOther, BOOL bMinimized);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Activate, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns afx_msg BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		bActive---bActive, Specifies A Boolean value.
	afx_msg BOOL OnNcActivate(BOOL bActive);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Enable, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		bEnable---bEnable, Specifies A Boolean value.
	afx_msg void OnEnable(BOOL bEnable);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Context Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnContextHelp();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On System Color Change, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnSysColorChange();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Get Minimize Maximize Information, This member function is called by the framework to allow your application to handle a Windows message.
	// Parameters:
	//		lpMMI---M M I, A pointer to the MINMAXINFO FAR or NULL if the call failed.
	afx_msg void OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI);
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Nc Hit Test, This member function is called by the framework to allow your application to handle a Windows message.
	//		Returns A afx_msg FOPNcHitTestType value (Object).  
	// Parameters:
	//		point---Specifies A CPoint type value.
	afx_msg FOPNcHitTestType OnNcHitTest(CPoint point);
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
private:
	
 
	// This member specify class object.  
    class Private;
 
	// This member maintains a pointer to the object Private.  
    Private * const m_d;

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOPFRAMEWND_H__DBA663CE_675E_4326_BDC9_60332B8E767B__INCLUDED_)
