//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOMultiPageView.h: interface for the CFOMultiPageView class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOMULTIPAGEVIEW_H__18CF5277_F709_11DD_A43D_525400EA266C__INCLUDED_)
#define AFX_FOMULTIPAGEVIEW_H__18CF5277_F709_11DD_A43D_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOMultiPageModelManager.h"
#include "FODrawView.h"

/////////////////////////////////////////////////////////////////////////////////
//
// CFOMultiPageView
//
// This class is defined for Multiple Pages style application,like sample CustomMSample,
// it is the view of this kind of application.
//
// Call GetCurrentModel() which is defined within the parent class CFODrawView to obtain the 
// pointer of the datamodel.All the datas of the canvas is included within class CFODataModel.
//
/////////////////////////////////////////////////////////////////////////////////

 
//===========================================================================
// Summary:
//     The CFOMultiPageView class derived from CFODrawView
//      F O Multiple Page View
//===========================================================================

class FO_EXT_CLASS CFOMultiPageView : public CFODrawView
{
protected: 
	//-----------------------------------------------------------------------
	// Summary:
	// create from serialization only
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ D Y N C R E A T E, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOMultiPageView---F O Multiple Page View, Specifies a E-XD++ CFOMultiPageView object (Value).
	DECLARE_DYNCREATE(CFOMultiPageView)

		//-----------------------------------------------------------------------
		// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Multiple Page View, Constructs a CFOMultiPageView object.
	//		Returns A  value (Object).
	CFOMultiPageView();

// Attributes

protected:

	// Pointer of data model.
 
	// Current Data Manager, This member maintains a pointer to the object CFOMultiPageModelManager.  
	CFOMultiPageModelManager *m_pCurDataManager;

public:

	// Is model manager null.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Is Model Manager Validate, Determines if the given value is correct or exist.
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL IsModelManagerValidate();

	// You must call this function in OnInitialUpdate.
	// Get multi page model pointer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Multiple Page Manager, Returns the specified value.
	//		Returns a pointer to the object CFOMultiPageModelManager ,or NULL if the call failed
	CFOMultiPageModelManager *GetMultiPageManager() const;

	// Set multi page model pointer.
	// pModelMgr -- pointer of the data model manager
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Multiple Page Manager, Sets a specify value to current class CFOMultiPageView
	// Parameters:
	//		*pModelMgr---Model Mgr, A pointer to the CFOMultiPageModelManager  or NULL if the call failed.
	void SetMultiPageManager(CFOMultiPageModelManager *pModelMgr);

	// Do model change.
	// pModelMgr -- pointer of the data model manager.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Change Model Mgr, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pModelMgr---Model Mgr, A pointer to the CFOMultiPageModelManager  or NULL if the call failed.
	virtual void	DoChangeModelMgr(CFOMultiPageModelManager *pModelMgr);

	// Update view with model change.
	// pSender -- pointer of the view.
	// lHint -- hint flag
	// pHint -- pointer of data object.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Update Model Change, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pSender---pSender, A pointer to the CView or NULL if the call failed.  
	//		lHint---lHint, Specifies A LPARAM value.  
	//		pHint---pHint, A pointer to the CObject or NULL if the call failed.
	virtual void DoUpdateModelChange(CView* pSender, LPARAM lHint, CObject* pHint);

public:
	// Allow multiple printing or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Allow Multiple Printing, .
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	BOOL AllowMultiPrinting() const { return m_bPrintWithMultiModel; }

	// Allow multiple model printing or not.
	// bMulti -- with multiple page printing support or not.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Enable Multipage Printing, Call this member function to enable or disable the specify object for this command.
	// Parameters:
	//		&bMulti---&bMulti, Specifies A Boolean value.
	void EnableMultipagePrinting(const BOOL &bMulti) { m_bPrintWithMultiModel = bMulti; }

	// Calculate the total print pages.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Calculate Total Print Pages, .
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a int type value.
	virtual int CalcTotalPrintPages();

	// Print direct without showing the print setting dialog.
	virtual void PrintDirect();

	// Do print a single model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Print One Page, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*pModel---*pModel, A pointer to the CFOMultiPageModel  or NULL if the call failed.  
	//		&nIndex---&nIndex, Specifies A integer value.  
	//		&bPreview---&bPreview, Specifies A Boolean value.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void DoPrintOnePage(CDC *pDC,CFOMultiPageModel *pModel,const int &nIndex,
		BOOL &bPreview, CPrintInfo* pInfo);

	// Find model by page index.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Find Page Model, Searches the list sequentially to find the first CObject pointer matching the specified CObject pointer. 
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOMultiPageModel ,or NULL if the call failed  
	// Parameters:
	//		&nIndex---&nIndex, Specifies A integer value.  
	//		&nCurPage---Current Page, Specifies A integer value.
	virtual CFOMultiPageModel *FindPageModel(const int &nIndex,int &nCurPage);

	// Get model print position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Current Single Model Print Position, Returns the specified value.
	//		Returns a CRect type value.  
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFOMultiPageModel  or NULL if the call failed.  
	//		&nPageNo---Page No, Specifies A integer value.
	CRect GetCurrentSingleModelPrintPosition(CFOMultiPageModel *pModel,const int &nPageNo);

	// Draw single model
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Draw Single Model Print Objects, Do a event. 
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*pModel---*pModel, A pointer to the CFOMultiPageModel  or NULL if the call failed.  
	//		&rcPrintPage---Print Page, Specifies A CRect type value.
	void DoDrawSingleModelPrintObjects(CDC *pDC,CFOMultiPageModel *pModel,const CRect &rcPrintPage);

	// Prepare header and footer DC
	
	//-----------------------------------------------------------------------
	// Summary:
	// Single Model Prepare Print Header Footer D C, .
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*pModel---*pModel, A pointer to the CFOMultiPageModel  or NULL if the call failed.
	void SingleModelPreparePrintHeaderFooterDC(CDC *pDC,CFOMultiPageModel *pModel);

	// Print header and footer.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Single Model Do Draw Print Header And Footer, .
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		*pModel---*pModel, A pointer to the CFOMultiPageModel  or NULL if the call failed.  
	//		nCurPage---Current Page, Specifies A integer value.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void SingleModelDoDrawPrintHeaderAndFooter(CDC* pDC,CFOMultiPageModel *pModel,
		const int& nCurPage, CPrintInfo* pInfo);

	// Clear header and footer DC.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Single Model Clear Print Header Footer D C, .
	// Parameters:
	//		*pDC---D C, A pointer to the CDC  or NULL if the call failed.  
	//		*pModel---*pModel, A pointer to the CFOMultiPageModel  or NULL if the call failed.
	void SingleModelClearPrintHeaderFooterDC(CDC *pDC,CFOMultiPageModel *pModel);
	
	// Operations
public:


	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFOMultiPageView)
	public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Draw, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Before Create Window, Called before the creation of the Windows window attached to this CWnd object.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		cs---Specifies a CREATESTRUCT& cs object(Value).
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Prepare D C, Called before the OnDraw member function is called for screen display or the OnPrint member function is called for printing or print preview.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnPrepareDC(CDC* pDC, CPrintInfo* pInfo = NULL);
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Update, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void OnInitialUpdate(); // called first time after construct
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Prepare Printing, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.  
	// Parameters:
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Begin Printing, Called when a print job begins; override to allocate graphics device interface (GDI) resources.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On End Printing, Called when a print job ends; override to deallocate GDI resources.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Print, Called to print or preview a page of the document.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDC---D C, A pointer to the CDC or NULL if the call failed.  
	//		pInfo---pInfo, A pointer to the CPrintInfo or NULL if the call failed.
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Update, Called to notify a view that its document has been modified.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pSender---pSender, A pointer to the CView or NULL if the call failed.  
	//		lHint---lHint, Specifies A LPARAM value.  
	//		pHint---pHint, A pointer to the CObject or NULL if the call failed.
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

	//Activate View
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Activate View, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		bActivate---bActivate, Specifies A Boolean value.  
	//		pActiveView---Active View, A pointer to the CView or NULL if the call failed.  
	//		pDeactiveView---Deactive View, A pointer to the CView or NULL if the call failed.
	virtual void OnActivateView(BOOL bActivate, CView* pActiveView, CView* pDeactiveView);

	// Update nav wnd.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Update Model List Box, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,
	virtual void DoUpdateModelListBox();

	// Implementation
public:
	// destructor
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Multiple Page View, Destructor of class CFOMultiPageView
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOMultiPageView();
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CFOMultiPageView)
	//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()

protected:

	// Enable print multiple models one time,all the data models within the data model manager
	// can be printed.
 
	// Print With Multiple Model, This member sets TRUE if it is right.  
	BOOL		m_bPrintWithMultiModel;
};

#endif // !defined(AFX_FOMULTIPAGEVIEW_H__18CF5277_F709_11DD_A43D_525400EA266C__INCLUDED_)
