//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(FO_FOPHITEXPANDACTION_H__6E70897F_89BE_4375_98FD_8AEE5269FF2E__INCLUDED_)
#define FO_FOPHITEXPANDACTION_H__6E70897F_89BE_4375_98FD_8AEE5269FF2E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

///////////////////////////////////////
// Description
// Author: Author
///////////////////////////////////////
#include "FOAction.h"
#include "FOPSubGraphShape.h"

///////////////////////////////////////////////////////////////////////////////////////
// CFOPHitExpandAction -- action that handle the sub - graph collect or expand event.
//

 
//===========================================================================
// Summary:
//     The CFOPHitExpandAction class derived from CFOAction
//      F O P Hit Expand Action
//===========================================================================

class FO_EXT_CLASS CFOPHitExpandAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPHitExpandAction---F O P Hit Expand Action, Specifies a E-XD++ CFOPHitExpandAction object (Value).
	DECLARE_ACTION(CFOPHitExpandAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Hit Expand Action, Constructs a CFOPHitExpandAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFOPSubGraphShape  or NULL if the call failed.
	CFOPHitExpandAction(CFODataModel* pModel,CFOPSubGraphShape *pShape);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Hit Expand Action, Destructor of class CFOPHitExpandAction
	//		Returns A  value (Object).
	~CFOPHitExpandAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOPHitExpandAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFOPSubGraphShape  or NULL if the call failed.
	virtual void SetShape(CFOPSubGraphShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPSubGraphShape ,or NULL if the call failed
	virtual CFOPSubGraphShape *GetShape();

	//TODO:Add your code here.
	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:
 
	// Shape, This member maintains a pointer to the object CFOPSubGraphShape.  
	CFOPSubGraphShape *m_pShape;

	//TODO:Add your code here.

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

inline void CFOPHitExpandAction::SetShape(CFOPSubGraphShape *pShape)
{
	m_pShape = pShape;
	pShape->AddRef();
}
	
inline CFOPSubGraphShape *CFOPHitExpandAction::GetShape()
{
	return m_pShape;
}


/////////////////////////////////////////////////////////////
// CFOPHitCollectAction.

 
//===========================================================================
// Summary:
//     The CFOPHitCollectAction class derived from CFOAction
//      F O P Hit Collect Action
//===========================================================================

class FO_EXT_CLASS CFOPHitCollectAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPHitCollectAction---F O P Hit Collect Action, Specifies a E-XD++ CFOPHitCollectAction object (Value).
	DECLARE_ACTION(CFOPHitCollectAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Hit Collect Action, Constructs a CFOPHitCollectAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFOPSubGraphShape  or NULL if the call failed.
	CFOPHitCollectAction(CFODataModel* pModel,CFOPSubGraphShape *pShape);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Hit Collect Action, Destructor of class CFOPHitCollectAction
	//		Returns A  value (Object).
	~CFOPHitCollectAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOPHitCollectAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFOPSubGraphShape  or NULL if the call failed.
	virtual void SetShape(CFOPSubGraphShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPSubGraphShape ,or NULL if the call failed
	virtual CFOPSubGraphShape *GetShape();

	//TODO:Add your code here.
	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:
 
	// Shape, This member maintains a pointer to the object CFOPSubGraphShape.  
	CFOPSubGraphShape *m_pShape;

	//TODO:Add your code here.

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

inline void CFOPHitCollectAction::SetShape(CFOPSubGraphShape *pShape)
{
	m_pShape = pShape;
	pShape->AddRef();
}
	
inline CFOPSubGraphShape *CFOPHitCollectAction::GetShape()
{
	return m_pShape;
}

//////////////////////////////////////////////
// CFOPHitExpandAllAction.

 
//===========================================================================
// Summary:
//     The CFOPHitExpandAllAction class derived from CFOAction
//      F O P Hit Expand All Action
//===========================================================================

class FO_EXT_CLASS CFOPHitExpandAllAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPHitExpandAllAction---F O P Hit Expand All Action, Specifies a E-XD++ CFOPHitExpandAllAction object (Value).
	DECLARE_ACTION(CFOPHitExpandAllAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Hit Expand All Action, Constructs a CFOPHitExpandAllAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFOPSubGraphShape  or NULL if the call failed.
	CFOPHitExpandAllAction(CFODataModel* pModel,CFOPSubGraphShape *pShape);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Hit Expand All Action, Destructor of class CFOPHitExpandAllAction
	//		Returns A  value (Object).
	~CFOPHitExpandAllAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOPHitExpandAllAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFOPSubGraphShape  or NULL if the call failed.
	virtual void SetShape(CFOPSubGraphShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPSubGraphShape ,or NULL if the call failed
	virtual CFOPSubGraphShape *GetShape();

	//TODO:Add your code here.
	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:
 
	// Shape, This member maintains a pointer to the object CFOPSubGraphShape.  
	CFOPSubGraphShape *m_pShape;

	//TODO:Add your code here.

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

inline void CFOPHitExpandAllAction::SetShape(CFOPSubGraphShape *pShape)
{
	m_pShape = pShape;
	pShape->AddRef();
}
	
inline CFOPSubGraphShape *CFOPHitExpandAllAction::GetShape()
{
	return m_pShape;
}


//////////////////////////////////////////////
// CFOPHitCollectAllAction.

 
//===========================================================================
// Summary:
//     The CFOPHitCollectAllAction class derived from CFOAction
//      F O P Hit Collect All Action
//===========================================================================

class FO_EXT_CLASS CFOPHitCollectAllAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOPHitCollectAllAction---F O P Hit Collect All Action, Specifies a E-XD++ CFOPHitCollectAllAction object (Value).
	DECLARE_ACTION(CFOPHitCollectAllAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O P Hit Collect All Action, Constructs a CFOPHitCollectAllAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		*pShape---*pShape, A pointer to the CFOPSubGraphShape  or NULL if the call failed.
	CFOPHitCollectAllAction(CFODataModel* pModel,CFOPSubGraphShape *pShape);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O P Hit Collect All Action, Destructor of class CFOPHitCollectAllAction
	//		Returns A  value (Object).
	~CFOPHitCollectAllAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Add new shape to the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Shape, Sets a specify value to current class CFOPHitCollectAllAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pShape---*pShape, A pointer to the CFOPSubGraphShape  or NULL if the call failed.
	virtual void SetShape(CFOPSubGraphShape *pShape);
	
	// Return the pointer of the shape.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Shape, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOPSubGraphShape ,or NULL if the call failed
	virtual CFOPSubGraphShape *GetShape();

	//TODO:Add your code here.
	// Obtain maximize position.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

public:
#ifdef _DEBUG
	
	//-----------------------------------------------------------------------
	// Summary:
	// Assert Valid, Assert performs a validity check on this object by checking its internal state.
	// This member function is also a virtual function, you can Override it if you need,
	virtual void AssertValid() const;
	
	//-----------------------------------------------------------------------
	// Summary:
	// Dump, Dumps the contents of your object to a CDumpContext object.
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		dc---Specifies a CDumpContext& dc object(Value).
	virtual void Dump(CDumpContext& dc) const;
#endif
protected:
 
	// Shape, This member maintains a pointer to the object CFOPSubGraphShape.  
	CFOPSubGraphShape *m_pShape;

	//TODO:Add your code here.

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

inline void CFOPHitCollectAllAction::SetShape(CFOPSubGraphShape *pShape)
{
	m_pShape = pShape;
	pShape->AddRef();
}
	
inline CFOPSubGraphShape *CFOPHitCollectAllAction::GetShape()
{
	return m_pShape;
}

#endif // !defined(FO_FOPHITEXPANDACTION_H__6E70897F_89BE_4375_98FD_8AEE5269FF2E__INCLUDED_)
