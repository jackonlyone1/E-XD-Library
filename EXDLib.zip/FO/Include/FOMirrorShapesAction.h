//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FOMIRRORSHAPESACTION_H__9034F75C_A484_405B_865B_954A96244F02__INCLUDED_)
#define AFX_FOMIRRORSHAPESACTION_H__9034F75C_A484_405B_865B_954A96244F02__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FOMirrorShapesAction.h : header file
//

#include "FOAction.h"

/////////////////////////////////////////////////////////////////////////////
// CFOMirrorShapesAction -- action that defined for doing mirror with selection shapes.

 
//===========================================================================
// Summary:
//     The CFOMirrorShapesAction class derived from CFOAction
//      F O Mirror Shapes Action
//===========================================================================

class FO_EXT_CLASS CFOMirrorShapesAction : public CFOAction
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOMirrorShapesAction---F O Mirror Shapes Action, Specifies a E-XD++ CFOMirrorShapesAction object (Value).
	DECLARE_ACTION(CFOMirrorShapesAction)
public:
	
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Mirror Shapes Action, Constructs a CFOMirrorShapesAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.  
	//		list---Specifies a const CFODrawShapeList& list object(Value).  
	//		listCenter---listCenter, Specifies a const CFODrawShapeList& listCenter object(Value).  
	//		&ptRef1---&ptRef1, Specifies A CPoint type value.  
	//		&ptRef2---&ptRef2, Specifies A CPoint type value.
	CFOMirrorShapesAction(CFODataModel* pModel,const CFODrawShapeList& list,
		const CFODrawShapeList& listCenter,
	const CPoint &ptRef1,const CPoint &ptRef2);

	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Mirror Shapes Action, Destructor of class CFOMirrorShapesAction
	//		Returns A  value (Object).
	~CFOMirrorShapesAction();

public:

	
	//-----------------------------------------------------------------------
	// Summary:
	// Execute, Executes the action.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	// Execute the action.
	virtual BOOL Execute();

	// Return the inverse action of this one.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Undo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetUndoAction() const;

	// Return a copy of this action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Redo Action, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFOBaseAction ,or NULL if the call failed
	virtual CFOBaseAction *GetRedoAction() const;

	// Get the name of the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Sprint, .
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		&strLabel---&strLabel, Specifies A CString type value.
	virtual void Sprint(CString &strLabel) const;

	// Get max position of list.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Maximize Position, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a CRect type value.
	virtual CRect GetMaxPosition();

	// Get total bounding rectangle.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Total Snap Rectangle, Returns the specified value.
	//		Returns a CRect type value.
	CRect GetTotalSnapRect() const;

protected:

	// a list of shape
 
	// Shapes, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList	m_listShapes;

	// a list of shape
 
	// Center Shapes, This member specify E-XD++ CFODrawShapeList object.  
	CFODrawShapeList	m_listCenterShapes;

	// X start point.
 
	// Ref1, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint				m_ptRef1;

	// Y start point.
 
	// Ref2, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	CPoint				m_ptRef2;

 
	// F O P Canvas Core, This member specify friend class object.  
	friend class CFOPCanvasCore;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FOMIRRORSHAPESACTION_H__9034F75C_A484_405B_865B_954A96244F02__INCLUDED_)
