//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.
// ONLY. THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF ucancode.net SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// ucancode.net Software
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
#if !defined(AFX_FODISTRIBUTIONDLG_H__C6D7E12E_071F_43BF_9102_3F49714B7248__INCLUDED_)
#define AFX_FODISTRIBUTIONDLG_H__C6D7E12E_071F_43BF_9102_3F49714B7248__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FODistributionDlg.h : header file
//

#include "FOPDropDownBitmapPickerButton.h"
#include "FOImageButton.h"

/////////////////////////////////////////////////////////////////////////////
// CFODistributionDlg dialog

 
//===========================================================================
// Summary:
//     The CFODistributionDlg class derived from CDialog
//      F O Distribution Dialog
//===========================================================================

class CFODistributionDlg : public CDialog
{
// Construction
public:
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Distribution Dialog, Constructs a CFODistributionDlg object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pParent---pParent, A pointer to the CWnd or NULL if the call failed.
	CFODistributionDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFODistributionDlg)
	enum { IDD = IDD_FO_DISTRIBUTION_DLG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

 
	// Button Help, This member specify E-XD++ CFOImageButton object.  
	CFOImageButton	m_ButtonHelp;

	// horz image picker button.
 
	// Drop Horizontal Button, This member specify FOPDropDownBitmapPickerButton object.  
	FOPDropDownBitmapPickerButton	DropHorzButton;

	// index of the image item that saved
 
	// Horizontal Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int savedHorzIndex;

	// Vert image picker button
 
	// Drop Vertical Button, This member specify FOPDropDownBitmapPickerButton object.  
	FOPDropDownBitmapPickerButton	DropVertButton;

	// index of the image item that saved.
 
	// Vertical Index, This variable specifies a 32-bit signed integer on 32-bit platforms.  
	int savedVertIndex;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFODistributionDlg)
	protected:
	
	//-----------------------------------------------------------------------
	// Summary:
	// Do Data Exchange, Do a event. 
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		pDX---D X, A pointer to the CDataExchange or NULL if the call failed.
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFODistributionDlg)
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Initial Dialog, This member function is called by the framework to allow your application to handle a Windows message.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns BOOLvalue, TRUE on success; FALSE otherwise.
	virtual BOOL OnInitDialog();
	
	//-----------------------------------------------------------------------
	// Summary:
	// On Button Help, This member function is called by the framework to allow your application to handle a Windows message.

	afx_msg void OnButtonHelp();
//}}AFX_MSG
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ M E S S A G E_ M A P, .
	//		Returns A  value (Object).
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FODISTRIBUTIONDLG_H__C6D7E12E_071F_43BF_9102_3F49714B7248__INCLUDED_)
