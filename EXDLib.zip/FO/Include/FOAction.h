//////////////////////////////////////////////////////////////////////
/*****************************************************************/
// This file is a part of the E-XD++ MFC Extension Class.
// 2001-200? ucancode.net Software, All Rights Reserved.
// This is only define for UCanCode Software E-XD++ Library.
//
// UCanCode SOFTWARE GRANTS TO YOU (ONE SOFTWARE PROGRAMMER) THE
// LIMITED RIGHT TO USE THIS SOFTWARE ON A SINGLE COMPUTER.  
//  THESE SOURCE FILE ARE CONSIDERED CONFIDENTIONAL AND ARE 
// THE PROPERTY OF UCanCode SOFTWARE AND ARE NOT TO BE RE-DISTRIBUTED
// BY ANY MEANS WHATSOEVER WITHOUT THE EXPRESSED WRITTEN CONSENT OF 
// UCanCode SOFTWARE.
//
// You can contact us.
// Support@ucancode.net
// http://www.ucancode.net
/********************************************************************/
// FOAction.h: interface for the CFOAction class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOACTION_H__2EEABBF8_F19E_11DD_A432_525400EA266C__INCLUDED_)
#define AFX_FOACTION_H__2EEABBF8_F19E_11DD_A432_525400EA266C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FOBaseAction.h"
#include "FODrawShape.h"
#include "FOGlobals.h"

////////////////////////////////////////////////////////////////////////
// CFOAction.
//
// This class is defined to be as the base class of single action,
// each action has its own execute method.
//

class CFODataModel;
 
//===========================================================================
// Summary:
//     The CFOAction class derived from CFOBaseAction
//      F O Action
//===========================================================================

class FO_EXT_CLASS CFOAction : public CFOBaseAction  
{
	
	//-----------------------------------------------------------------------
	// Summary:
	// E C L A R E_ A C T I O N_ N O I D, .
	//		Returns A  value (Object).  
	// Parameters:
	//		CFOAction---F O Action, Specifies a E-XD++ CFOAction object (Value).
	DECLARE_ACTION_NOID(CFOAction)

public:

	//-----------------------------------------------------------------------
	// Summary:
	// Constructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// F O Action, Constructs a CFOAction object.
	//		Returns A  value (Object).  
	// Parameters:
	//		pModel---pModel, A pointer to the CFODataModel or NULL if the call failed.
	CFOAction(CFODataModel* pModel);

	//-----------------------------------------------------------------------
	// Summary:
	// Destructor.
	
	//-----------------------------------------------------------------------
	// Summary:
	// C F O Action, Destructor of class CFOAction
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns A  value (Object).
	virtual ~CFOAction();

public:
	
	// Set the model of the action.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Set Model, Sets a specify value to current class CFOAction
	// This member function is also a virtual function, you can Override it if you need,  
	// Parameters:
	//		*pModel---*pModel, A pointer to the CFODataModel  or NULL if the call failed.
	virtual void SetModel(
		// Pointer of data model.
		CFODataModel *pModel
		);

	// Get the pointer of the model.
	
	//-----------------------------------------------------------------------
	// Summary:
	// Get Model, Returns the specified value.
	// This member function is also a virtual function, you can Override it if you need,  
	//		Returns a pointer to the object CFODataModel ,or NULL if the call failed
	virtual CFODataModel *GetModel();

	
protected:

	// The pointer to Model
 
	// Model, This member maintains a pointer to the object CFODataModel.  
	CFODataModel*	m_pModel;

	
};

//Gets the model that the shapes are in.
//A pointer to the model.
_FOLIB_INLINE CFODataModel* CFOAction::GetModel()
{
	return m_pModel;
}

// Set the model of the action.
_FOLIB_INLINE void CFOAction::SetModel(CFODataModel *pModel)
{
	m_pModel = pModel;
}
#endif // !defined(AFX_FOACTION_H__2EEABBF8_F19E_11DD_A432_525400EA266C__INCLUDED_)
